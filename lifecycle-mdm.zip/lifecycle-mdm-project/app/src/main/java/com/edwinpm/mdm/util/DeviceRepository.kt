package com.edwinpm.mdm.util

import android.content.Context
import android.os.Build
import android.provider.Settings
import android.util.Log
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.messaging.FirebaseMessaging

/**
 * DeviceRepository centralizes all Firebase synchronization for this device.
 *
 * Data structure in Firestore:
 *   devices/{deviceId}/
 *     deviceId        : String  — stable ID derived from ANDROID_ID + Serial + Model
 *     fcmToken        : String  — current FCM push token
 *     deviceModel     : String  — e.g. "Xiaomi Redmi Note 12"
 *     androidVersion  : String  — e.g. "14"
 *     sdkVersion      : Int     — e.g. 34
 *     paymentStatus   : String  — "active" | "suspended" | "revoked"
 *     registeredAt    : Timestamp
 *     lastSeen        : Timestamp — updated every 15 minutes by WatchdogWorker
 */
object DeviceRepository {

    private const val TAG = "DeviceRepository"
    private const val COLLECTION = "devices"

    // ─── Device ID ────────────────────────────────────────────────────────────

    /**
     * Returns a stable, unique device identifier.
     *
     * Composed of ANDROID_ID + hardware serial (if available under MDM permissions)
     * + sanitised model name. Result is cached in SharedPreferences after first call.
     *
     * Format: {androidId}[_{serial}]_{model}  (max 64 chars)
     */
    fun getOrCreateDeviceId(context: Context): String {
        val prefs = MdmPrefs(context)
        prefs.getDeviceId()?.let { return it }

        val androidId = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ANDROID_ID
        )?.takeIf { it.isNotBlank() } ?: "unknown"

        val serial: String = try {
            // Build.getSerial() requires READ_PHONE_STATE on API 26+.
            // As Device Owner the DPM grants this implicitly; still wrap in try-catch.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Build.getSerial().takeIf { it != Build.UNKNOWN } ?: ""
            } else {
                @Suppress("DEPRECATION")
                Build.SERIAL.takeIf { it != Build.UNKNOWN } ?: ""
            }
        } catch (_: SecurityException) {
            ""
        }

        val model = Build.MODEL
            .replace(" ", "_")
            .replace(Regex("[^a-zA-Z0-9_\\-]"), "")

        val serialPart = if (serial.isNotBlank()) "_$serial" else ""
        val deviceId = "${androidId}${serialPart}_${model}".take(64)

        prefs.setDeviceId(deviceId)
        Log.i(TAG, "Generated DeviceID: $deviceId")
        return deviceId
    }

    // ─── Firebase Firestore ────────────────────────────────────────────────────

    private fun db(): FirebaseFirestore = FirebaseFirestore.getInstance()

    /**
     * Called once on first launch (and on reinstall).
     *
     * Fetches the current FCM token, then writes the full device record to Firestore.
     * Uses SetOptions.merge() so subsequent calls only update what changes.
     */
    fun registerDevice(context: Context) {
        val deviceId = getOrCreateDeviceId(context)
        val prefs = MdmPrefs(context)

        FirebaseMessaging.getInstance().token
            .addOnSuccessListener { token ->
                prefs.setFcmToken(token)

                val data = hashMapOf(
                    "deviceId"       to deviceId,
                    "fcmToken"       to token,
                    "deviceModel"    to "${Build.MANUFACTURER} ${Build.MODEL}",
                    "androidVersion" to Build.VERSION.RELEASE,
                    "sdkVersion"     to Build.VERSION.SDK_INT,
                    "paymentStatus"  to (prefs.getPaymentStatus() ?: "active"),
                    "registeredAt"   to FieldValue.serverTimestamp(),
                    "lastSeen"       to FieldValue.serverTimestamp()
                )

                db().collection(COLLECTION)
                    .document(deviceId)
                    .set(data, SetOptions.merge())
                    .addOnSuccessListener {
                        Log.i(TAG, "Device registered in Firestore: $deviceId")
                    }
                    .addOnFailureListener { e ->
                        Log.e(TAG, "Failed to register device: ${e.message}")
                    }
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Failed to get FCM token during registration: ${e.message}")
            }
    }

    /**
     * Called by [MdmFcmService.onNewToken] whenever Firebase rotates the push token.
     * Updates only the token and lastSeen fields — does not overwrite paymentStatus etc.
     */
    fun syncToken(context: Context, token: String) {
        val deviceId = getOrCreateDeviceId(context)
        MdmPrefs(context).setFcmToken(token)

        db().collection(COLLECTION)
            .document(deviceId)
            .set(
                mapOf(
                    "fcmToken" to token,
                    "lastSeen" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            )
            .addOnSuccessListener { Log.i(TAG, "FCM token synced for $deviceId") }
            .addOnFailureListener { e -> Log.e(TAG, "Token sync failed: ${e.message}") }
    }

    /**
     * Called by [WatchdogWorker] every 15 minutes.
     * Touches the lastSeen field so the console can detect offline devices.
     */
    fun updateHeartbeat(context: Context) {
        val deviceId = getOrCreateDeviceId(context)

        db().collection(COLLECTION)
            .document(deviceId)
            .set(
                mapOf("lastSeen" to FieldValue.serverTimestamp()),
                SetOptions.merge()
            )
            .addOnSuccessListener { Log.i(TAG, "Heartbeat updated for $deviceId") }
            .addOnFailureListener { e -> Log.e(TAG, "Heartbeat failed: ${e.message}") }
    }
}
