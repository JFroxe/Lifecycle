package com.edwinpm.mdm.service

import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import com.edwinpm.mdm.LifecycleApp
import com.edwinpm.mdm.R
import com.edwinpm.mdm.admin.DeviceOwnerHelper
import com.edwinpm.mdm.kiosk.KioskLockActivity
import com.edwinpm.mdm.ui.MainActivity
import com.edwinpm.mdm.util.MdmPrefs
import com.edwinpm.mdm.worker.WatchdogWorker

/**
 * MdmWatchdogService is a sticky foreground service that:
 * 1. Keeps the MDM agent alive with a persistent notification
 * 2. Re-applies Device Owner policies on every start (uninstall block, lock task, etc.)
 * 3. Handles Lock/Unlock/Wipe commands from FCM or internal callers
 * 4. Auto-restarts via START_STICKY
 */
class MdmWatchdogService : LifecycleService() {

    companion object {
        private const val TAG = "MdmWatchdogService"

        const val CMD_LOCK = "ACTION_LOCK"
        const val CMD_UNLOCK = "ACTION_UNLOCK"
        const val CMD_WIPE = "ACTION_WIPE"

        fun sendCommand(context: Context, command: String, reason: String = "") {
            val intent = Intent(context, MdmWatchdogService::class.java).apply {
                action = command
                putExtra("reason", reason)
            }
            context.startForegroundService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "WatchdogService created")
        startForeground(
            LifecycleApp.NOTIFICATION_ID_WATCHDOG,
            buildWatchdogNotification()
        )

        // Re-apply all Device Owner policies every time the service starts.
        // This is a second enforcement point after LifecycleApp.onCreate().
        DeviceOwnerHelper.applyAllPolicies(this)

        // Ensure WorkManager job is enqueued
        WatchdogWorker.enqueue(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)

        val action = intent?.action
        val reason = intent?.getStringExtra("reason") ?: ""

        Log.i(TAG, "onStartCommand: action=$action, reason=$reason")

        when (action) {
            CMD_LOCK -> handleLock(reason)
            CMD_UNLOCK -> handleUnlock(reason)
            CMD_WIPE -> handleWipe(reason)
            else -> {
                // Service restarted (no command) — re-apply policies and re-lock if needed
                DeviceOwnerHelper.applyAllPolicies(this)
                if (MdmPrefs(this).isLocked()) {
                    Log.i(TAG, "Device was locked — re-enforcing lock after restart")
                    handleLock("Re-enforcing lock after restart")
                }
            }
        }

        // START_STICKY: system restarts this service automatically if killed
        return START_STICKY
    }

    private fun handleLock(reason: String) {
        Log.w(TAG, "LOCK command — Reason: $reason")
        MdmPrefs(this).setLocked(true)

        // Re-apply lock task policy before launching the kiosk screen
        DeviceOwnerHelper.applyAllPolicies(this)
        DeviceOwnerHelper.lockDeviceNow(this)

        val lockIntent = Intent(this, KioskLockActivity::class.java).apply {
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_CLEAR_TOP or
                Intent.FLAG_ACTIVITY_SINGLE_TOP
            )
            putExtra(KioskLockActivity.EXTRA_REASON, reason.ifEmpty { "Device locked by MDM" })
        }
        startActivity(lockIntent)
    }

    private fun handleUnlock(reason: String) {
        Log.i(TAG, "UNLOCK command — Reason: $reason")
        MdmPrefs(this).setLocked(false)

        // Send broadcast to dismiss the kiosk activity cleanly
        val unlockBroadcast = Intent(KioskLockActivity.ACTION_UNLOCK)
        sendBroadcast(unlockBroadcast)

        val mainIntent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        startActivity(mainIntent)
    }

    private fun handleWipe(reason: String) {
        Log.w(TAG, "WIPE command — Reason: $reason")
        DeviceOwnerHelper.wipeDevice(this, reason)
    }

    private fun buildWatchdogNotification(): Notification {
        val contentIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, LifecycleApp.CHANNEL_WATCHDOG)
            .setContentTitle("Lifecycle MDM Active")
            .setContentText("Device management is running")
            .setSmallIcon(R.drawable.ic_shield)
            .setOngoing(true)
            .setContentIntent(contentIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.w(TAG, "WatchdogService destroyed — START_STICKY will restart it")
    }
}
