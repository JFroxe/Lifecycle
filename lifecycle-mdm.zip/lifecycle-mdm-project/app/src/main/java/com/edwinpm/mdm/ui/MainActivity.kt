package com.edwinpm.mdm.ui

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.edwinpm.mdm.admin.DeviceOwnerHelper
import com.edwinpm.mdm.admin.MdmDeviceAdminReceiver
import com.edwinpm.mdm.kiosk.KioskLockActivity
import com.edwinpm.mdm.service.MdmWatchdogService
import com.edwinpm.mdm.ui.theme.LifecycleTheme
import com.edwinpm.mdm.util.MdmPrefs
import com.edwinpm.mdm.worker.WatchdogWorker

class MainActivity : ComponentActivity() {

    // Compose-observable state — changes here automatically trigger UI recomposition.
    // Updated on every onResume() so the display always reflects the real device status.
    private var isAdmin by mutableStateOf(false)
    private var isDeviceOwner by mutableStateOf(false)

    private val requestAdminLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        // Re-read status after the admin dialog closes (granted or denied)
        refreshStatus()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // If device is already in locked state, redirect to kiosk
        if (MdmPrefs(this).isLocked()) {
            startKioskActivity("Device is currently locked")
            finish()
            return
        }

        // Start watchdog service and WorkManager job
        startForegroundService(Intent(this, MdmWatchdogService::class.java))
        WatchdogWorker.enqueue(this)

        // setContent is called once — it will recompose whenever isAdmin / isDeviceOwner change
        setContent {
            LifecycleTheme {
                MainScreen(
                    isAdmin = isAdmin,
                    isDeviceOwner = isDeviceOwner,
                    onLock = { lockDevice() },
                    onWipe = { wipeDevice() },
                    onRequestAdmin = { requestDeviceAdmin() }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Re-read actual device status every time this screen becomes visible.
        // This is what fixes the "Inactive" display after ADB set-device-owner.
        refreshStatus()
    }

    /**
     * Re-reads the real device admin/owner status from DPM and updates the
     * Compose state variables. Because they are mutableStateOf, any change
     * automatically triggers a UI recomposition with no extra work needed.
     */
    private fun refreshStatus() {
        val adminNow = DeviceOwnerHelper.isDeviceAdmin(this)
        val ownerNow = DeviceOwnerHelper.isDeviceOwner(this)

        isAdmin = adminNow
        isDeviceOwner = ownerNow

        // If we weren't admin before but are now, apply all policies
        if (adminNow) {
            DeviceOwnerHelper.applyAllPolicies(this)
        }

        // If not yet admin, prompt for it
        if (!adminNow) {
            requestDeviceAdmin()
        }
    }

    private fun requestDeviceAdmin() {
        val adminComponent = ComponentName(this, MdmDeviceAdminReceiver::class.java)
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
            putExtra(
                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Lifecycle MDM requires Device Administrator privileges to manage this device."
            )
        }
        requestAdminLauncher.launch(intent)
    }

    private fun lockDevice() {
        MdmWatchdogService.sendCommand(this, MdmWatchdogService.CMD_LOCK, "Manual lock")
    }

    private fun wipeDevice() {
        MdmWatchdogService.sendCommand(this, MdmWatchdogService.CMD_WIPE, "Manual wipe")
    }

    private fun startKioskActivity(reason: String) {
        val intent = Intent(this, KioskLockActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra(KioskLockActivity.EXTRA_REASON, reason)
        }
        startActivity(intent)
    }
}
