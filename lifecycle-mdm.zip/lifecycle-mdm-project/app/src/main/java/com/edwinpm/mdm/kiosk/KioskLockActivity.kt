package com.edwinpm.mdm.kiosk

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.edwinpm.mdm.admin.DeviceOwnerHelper
import com.edwinpm.mdm.ui.theme.LifecycleTheme
import com.edwinpm.mdm.util.MdmPrefs

/**
 * KioskLockActivity — full-screen, unescapable lock overlay.
 *
 * Escape prevention layers (Defence in depth):
 *
 * Layer 1 — Device Owner lock task (strongest):
 *   setLockTaskPackages() + setLockTaskFeatures(LOCK_TASK_FEATURE_NONE) +
 *   startLockTask() → completely disables Back+Recents escape, status bar,
 *   notifications, and home button. User CANNOT exit.
 *
 * Layer 2 — onPause() re-launch:
 *   If somehow paused, immediately relaunches itself.
 *
 * Layer 3 — onUserLeaveHint():
 *   Fires when Home is pressed — relaunches immediately.
 *
 * Layer 4 — Key event blocking:
 *   Intercepts Home, Recents, Back, Menu at the key level.
 *
 * Layer 5 — Window flags:
 *   FLAG_KEEP_SCREEN_ON, FLAG_SHOW_WHEN_LOCKED, FLAG_TURN_SCREEN_ON.
 */
class KioskLockActivity : ComponentActivity() {

    companion object {
        const val EXTRA_REASON = "extra_reason"
        const val ACTION_UNLOCK = "com.edwinpm.mdm.ACTION_UNLOCK_KIOSK"
    }

    private var lockReason = "Device locked"

    private val unlockReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == ACTION_UNLOCK) {
                MdmPrefs(this@KioskLockActivity).setLocked(false)
                try { stopLockTask() } catch (_: Exception) {}
                finish()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        lockReason = intent.getStringExtra(EXTRA_REASON) ?: "Device locked"

        // Window flags — show above keyguard and keep screen on
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
        )
        setShowWhenLocked(true)
        setTurnScreenOn(true)

        enableEdgeToEdge()

        // Block back button at the dispatcher level (Layer 4 - software back)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { /* blocked */ }
        })

        setContent {
            LifecycleTheme {
                KioskLockScreen(lockReason = lockReason)
            }
        }
    }

    override fun onResume() {
        super.onResume()

        // Layer 1: Re-apply lock task policy and start lock task every resume.
        // setLockTaskFeatures(LOCK_TASK_FEATURE_NONE) MUST be set before startLockTask()
        // or the Back+Recents escape will still work.
        DeviceOwnerHelper.enableLockTaskMode(this)
        try {
            startLockTask()
        } catch (e: SecurityException) {
            // Not Device Owner — layers 2-4 still protect, but Back+Recents may work.
            // User should set DO via QR provisioning for full protection.
        }

        // Register unlock broadcast receiver
        val filter = IntentFilter(ACTION_UNLOCK)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(unlockReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(unlockReceiver, filter)
        }
    }

    override fun onPause() {
        super.onPause()
        try { unregisterReceiver(unlockReceiver) } catch (_: IllegalArgumentException) {}

        // Layer 2: If still locked, immediately relaunch ourselves.
        // This fires whenever anything tries to push us to the background.
        if (MdmPrefs(this).isLocked()) {
            relaunchSelf()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // If destroyed while locked (e.g. force-stopped via ADB), relaunch
        if (MdmPrefs(this).isLocked()) {
            relaunchSelf()
        }
        try { stopLockTask() } catch (_: Exception) {}
    }

    // Layer 3: Home button detection
    override fun onUserLeaveHint() {
        if (MdmPrefs(this).isLocked()) {
            relaunchSelf()
        }
    }

    // Layer 4: Key-level blocking
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        return when (keyCode) {
            KeyEvent.KEYCODE_HOME,
            KeyEvent.KEYCODE_APP_SWITCH,
            KeyEvent.KEYCODE_MENU,
            KeyEvent.KEYCODE_BACK,
            KeyEvent.KEYCODE_SEARCH,
            KeyEvent.KEYCODE_VOLUME_UP,
            KeyEvent.KEYCODE_VOLUME_DOWN -> true   // consume — do nothing
            else -> super.onKeyDown(keyCode, event)
        }
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        return when (keyCode) {
            KeyEvent.KEYCODE_HOME,
            KeyEvent.KEYCODE_APP_SWITCH,
            KeyEvent.KEYCODE_MENU,
            KeyEvent.KEYCODE_BACK,
            KeyEvent.KEYCODE_SEARCH -> true
            else -> super.onKeyUp(keyCode, event)
        }
    }

    private fun relaunchSelf() {
        val intent = Intent(this, KioskLockActivity::class.java).apply {
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_CLEAR_TOP or
                Intent.FLAG_ACTIVITY_SINGLE_TOP
            )
            putExtra(EXTRA_REASON, lockReason)
        }
        startActivity(intent)
    }
}
