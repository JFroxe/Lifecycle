package com.edwinpm.mdm.admin

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.edwinpm.mdm.service.MdmWatchdogService
import com.edwinpm.mdm.util.MdmPrefs
import com.edwinpm.mdm.worker.WatchdogWorker

/**
 * BootReceiver starts the MDM watchdog service and WorkManager job after device reboot.
 * Registered for BOOT_COMPLETED and LOCKED_BOOT_COMPLETED so it fires as early as possible.
 */
class BootReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "BootReceiver"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != "android.intent.action.LOCKED_BOOT_COMPLETED" &&
            action != "android.intent.action.QUICKBOOT_POWERON"
        ) return

        Log.i(TAG, "Boot completed — starting MDM watchdog")

        // Start foreground watchdog service
        val serviceIntent = Intent(context, MdmWatchdogService::class.java)
        context.startForegroundService(serviceIntent)

        // Enqueue persistent WorkManager job
        WatchdogWorker.enqueue(context)

        // If device was locked before reboot, re-apply lock
        val prefs = MdmPrefs(context)
        if (prefs.isLocked()) {
            Log.i(TAG, "Device was locked before reboot — re-applying lock")
            MdmWatchdogService.sendCommand(context, MdmWatchdogService.CMD_LOCK)
        }
    }
}
