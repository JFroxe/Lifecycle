package com.edwinpm.mdm.fcm

import android.util.Log
import com.edwinpm.mdm.service.MdmWatchdogService
import com.edwinpm.mdm.util.DeviceRepository
import com.edwinpm.mdm.util.MdmPrefs
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/**
 * MdmFcmService handles real-time FCM push commands from the MDM backend
 * and keeps the device's FCM token synced to Firestore.
 *
 * ── FCM Payload Format ───────────────────────────────────────────────────────
 * Send a DATA message (not a notification message) with one of these payloads:
 *
 *   Lock device:
 *     { "cmd": "lock",   "reason": "Payment overdue" }
 *
 *   Unlock device:
 *     { "cmd": "unlock", "reason": "Payment received" }
 *
 *   Factory wipe:
 *     { "cmd": "wipe",   "reason": "Device decommissioned" }
 *
 *   Ping (health check):
 *     { "cmd": "ping" }
 *
 * Both "cmd" and the legacy "command" key are accepted; values are
 * case-insensitive ("lock", "LOCK", and "Lock" all work).
 *
 * ── Send via Firebase Cloud Messaging REST API ───────────────────────────────
 * POST https://fcm.googleapis.com/v1/projects/{PROJECT_ID}/messages:send
 * Authorization: Bearer {ACCESS_TOKEN}
 * {
 *   "message": {
 *     "token": "{DEVICE_FCM_TOKEN}",
 *     "data": { "cmd": "lock", "reason": "Payment overdue" }
 *   }
 * }
 */
class MdmFcmService : FirebaseMessagingService() {

    companion object {
        private const val TAG = "MdmFcmService"

        const val CMD_LOCK   = "LOCK"
        const val CMD_UNLOCK = "UNLOCK"
        const val CMD_WIPE   = "WIPE"
        const val CMD_PING   = "PING"
    }

    /**
     * Called by Firebase whenever the FCM registration token is created or rotated.
     * Saves the new token locally and syncs it to Firestore so the backend always
     * has an up-to-date address to send commands to.
     */
    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.i(TAG, "FCM token refreshed")
        MdmPrefs(applicationContext).setFcmToken(token)
        DeviceRepository.syncToken(applicationContext, token)
    }

    /**
     * Dispatches incoming FCM data messages to the appropriate MDM action.
     *
     * Accepted payload keys (in order of priority):
     *   "cmd"     — preferred key  (e.g. "lock", "unlock", "wipe", "ping")
     *   "command" — legacy key     (e.g. "LOCK", "UNLOCK", "WIPE", "PING")
     * Both are matched case-insensitively.
     */
    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        Log.i(TAG, "FCM message received from: ${remoteMessage.from}")

        val data = remoteMessage.data
        if (data.isEmpty()) {
            Log.w(TAG, "FCM message has no data payload — ignoring")
            return
        }

        // Accept "cmd" (new) or "command" (legacy), case-insensitive
        val command = (data["cmd"] ?: data["command"])?.uppercase() ?: run {
            Log.w(TAG, "FCM message missing 'cmd' or 'command' key — ignoring")
            return
        }

        val reason = data["reason"] ?: "Remote MDM command"
        Log.i(TAG, "Processing FCM command: $command | Reason: $reason")

        when (command) {
            CMD_LOCK -> {
                MdmWatchdogService.sendCommand(
                    applicationContext, MdmWatchdogService.CMD_LOCK, reason
                )
            }
            CMD_UNLOCK -> {
                MdmWatchdogService.sendCommand(
                    applicationContext, MdmWatchdogService.CMD_UNLOCK, reason
                )
            }
            CMD_WIPE -> {
                Log.w(TAG, "WIPE command received — initiating factory reset")
                MdmWatchdogService.sendCommand(
                    applicationContext, MdmWatchdogService.CMD_WIPE, reason
                )
            }
            CMD_PING -> {
                val token = MdmPrefs(applicationContext).getFcmToken() ?: "unknown"
                Log.i(TAG, "PING — device alive. Token: $token")
                // Update heartbeat so the console sees the device is online
                DeviceRepository.updateHeartbeat(applicationContext)
            }
            else -> {
                Log.w(TAG, "Unknown FCM command: $command")
            }
        }
    }
}
