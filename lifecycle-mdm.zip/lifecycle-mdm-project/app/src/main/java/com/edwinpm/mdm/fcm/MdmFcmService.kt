package com.edwinpm.mdm.fcm

import android.util.Log
import com.edwinpm.mdm.service.MdmWatchdogService
import com.edwinpm.mdm.util.MdmPrefs
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/**
 * MdmFcmService handles real-time FCM push commands from the MDM backend.
 *
 * FCM Payload Format (data message, NOT notification message):
 * {
 *   "data": {
 *     "command": "LOCK" | "UNLOCK" | "WIPE" | "PING",
 *     "reason": "optional reason string"
 *   }
 * }
 *
 * Send via Firebase Console or REST API:
 * POST https://fcm.googleapis.com/v1/projects/{PROJECT_ID}/messages:send
 * Authorization: Bearer {ACCESS_TOKEN}
 * {
 *   "message": {
 *     "token": "{DEVICE_FCM_TOKEN}",
 *     "data": {
 *       "command": "LOCK",
 *       "reason": "Payment overdue"
 *     }
 *   }
 * }
 */
class MdmFcmService : FirebaseMessagingService() {

    companion object {
        private const val TAG = "MdmFcmService"

        const val CMD_LOCK = "LOCK"
        const val CMD_UNLOCK = "UNLOCK"
        const val CMD_WIPE = "WIPE"
        const val CMD_PING = "PING"

        const val KEY_COMMAND = "command"
        const val KEY_REASON = "reason"
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.i(TAG, "FCM token refreshed: $token")
        // TODO: Send this token to your MDM backend server
        // You can store it locally for now:
        MdmPrefs(applicationContext).setFcmToken(token)
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        Log.i(TAG, "FCM message received from: ${remoteMessage.from}")

        val data = remoteMessage.data
        if (data.isEmpty()) {
            Log.w(TAG, "FCM message has no data payload — ignoring")
            return
        }

        val command = data[KEY_COMMAND]?.uppercase() ?: run {
            Log.w(TAG, "FCM message missing 'command' key — ignoring")
            return
        }

        val reason = data[KEY_REASON] ?: "Remote MDM command"
        Log.i(TAG, "Processing FCM command: $command | Reason: $reason")

        when (command) {
            CMD_LOCK -> {
                MdmWatchdogService.sendCommand(applicationContext, MdmWatchdogService.CMD_LOCK, reason)
            }
            CMD_UNLOCK -> {
                MdmWatchdogService.sendCommand(applicationContext, MdmWatchdogService.CMD_UNLOCK, reason)
            }
            CMD_WIPE -> {
                Log.w(TAG, "WIPE command received — initiating after 5 second delay")
                MdmWatchdogService.sendCommand(applicationContext, MdmWatchdogService.CMD_WIPE, reason)
            }
            CMD_PING -> {
                Log.i(TAG, "PING received — device is alive. Token: ${MdmPrefs(applicationContext).getFcmToken()}")
            }
            else -> {
                Log.w(TAG, "Unknown FCM command: $command")
            }
        }
    }
}
