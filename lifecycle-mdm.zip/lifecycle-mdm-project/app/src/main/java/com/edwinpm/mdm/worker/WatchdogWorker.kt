package com.edwinpm.mdm.worker

import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.edwinpm.mdm.admin.DeviceOwnerHelper
import com.edwinpm.mdm.service.MdmWatchdogService
import com.edwinpm.mdm.util.MdmPrefs
import java.util.concurrent.TimeUnit

/**
 * WatchdogWorker runs every 15 minutes via WorkManager to:
 * 1. Re-apply all Device Owner policies (uninstall block, lock task features, etc.)
 * 2. Ensure the foreground service is alive
 * 3. Re-enforce the lock screen if the device was in a locked state
 *
 * WorkManager survives Doze mode and reboots (after BOOT_COMPLETED).
 */
class WatchdogWorker(
    context: Context,
    params: WorkerParameters
) : Worker(context, params) {

    companion object {
        private const val TAG = "WatchdogWorker"
        private const val WORK_NAME = "MdmWatchdogWork"

        fun enqueue(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.NOT_REQUIRED)
                .build()

            val request = PeriodicWorkRequestBuilder<WatchdogWorker>(
                15, TimeUnit.MINUTES
            )
                .setConstraints(constraints)
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
            Log.i(TAG, "WatchdogWorker enqueued (15-minute interval)")
        }
    }

    override fun doWork(): Result {
        Log.i(TAG, "WatchdogWorker running")
        val prefs = MdmPrefs(applicationContext)

        // Always re-apply Device Owner policies — this ensures that even if
        // something cleared them (e.g. system update, OTA), they come back.
        DeviceOwnerHelper.applyAllPolicies(applicationContext)

        // Ensure the foreground watchdog service is running
        try {
            val serviceIntent = Intent(applicationContext, MdmWatchdogService::class.java)
            applicationContext.startForegroundService(serviceIntent)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to restart watchdog service: ${e.message}")
        }

        // Re-enforce lock if the device is supposed to be locked
        if (prefs.isLocked()) {
            Log.w(TAG, "Device is locked — re-enforcing via service command")
            MdmWatchdogService.sendCommand(
                applicationContext,
                MdmWatchdogService.CMD_LOCK,
                "Watchdog lock enforcement"
            )
        }

        return Result.success()
    }
}
