package com.edwinpm.mdm.util

import android.content.Context
import android.content.SharedPreferences

/**
 * MdmPrefs is a lightweight SharedPreferences wrapper for persisting MDM state.
 */
class MdmPrefs(context: Context) {

    companion object {
        private const val PREFS_NAME = "mdm_prefs"
        private const val KEY_LOCKED = "is_locked"
        private const val KEY_ADMIN_ENABLED = "admin_enabled"
        private const val KEY_FCM_TOKEN = "fcm_token"
        private const val KEY_DEVICE_ID = "device_id"
    }

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun isLocked(): Boolean = prefs.getBoolean(KEY_LOCKED, false)

    fun setLocked(locked: Boolean) {
        prefs.edit().putBoolean(KEY_LOCKED, locked).apply()
    }

    fun isAdminEnabled(): Boolean = prefs.getBoolean(KEY_ADMIN_ENABLED, false)

    fun setAdminEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_ADMIN_ENABLED, enabled).apply()
    }

    fun getFcmToken(): String? = prefs.getString(KEY_FCM_TOKEN, null)

    fun setFcmToken(token: String) {
        prefs.edit().putString(KEY_FCM_TOKEN, token).apply()
    }

    fun getDeviceId(): String? = prefs.getString(KEY_DEVICE_ID, null)

    fun setDeviceId(deviceId: String) {
        prefs.edit().putString(KEY_DEVICE_ID, deviceId).apply()
    }
}
