package com.edwinpm.mdm.util

import android.content.Context
import android.content.SharedPreferences

/**
 * MdmPrefs is a lightweight SharedPreferences wrapper for persisting MDM state.
 *
 * The "is_locked" flag is written to BOTH credential-encrypted (CE) storage (normal operation)
 * and device-protected (DE) storage (available before the user unlocks after a reboot).
 * BootReceiver reads the DE copy via [isLockedDirectBoot] so the lock is restored even when
 * LOCKED_BOOT_COMPLETED fires before CE storage is decrypted.
 */
class MdmPrefs(context: Context) {

    companion object {
        private const val PREFS_NAME = "mdm_prefs"
        private const val KEY_LOCKED = "is_locked"
        private const val KEY_ADMIN_ENABLED = "admin_enabled"
        private const val KEY_FCM_TOKEN = "fcm_token"
        private const val KEY_DEVICE_ID = "device_id"
        private const val KEY_PAYMENT_STATUS = "payment_status"
    }

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    // Device-protected (DE) storage — readable before credential decryption on boot.
    private val dePrefs: SharedPreferences =
        context.createDeviceProtectedStorageContext()
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun isLocked(): Boolean = prefs.getBoolean(KEY_LOCKED, false)

    /** Read the lock flag from DE storage — safe to call during LOCKED_BOOT_COMPLETED. */
    fun isLockedDirectBoot(): Boolean = dePrefs.getBoolean(KEY_LOCKED, false)

    fun setLocked(locked: Boolean) {
        prefs.edit().putBoolean(KEY_LOCKED, locked).apply()
        // Mirror into DE storage so BootReceiver can read it before CE is available.
        dePrefs.edit().putBoolean(KEY_LOCKED, locked).apply()
    }

    fun isAdminEnabled(): Boolean = prefs.getBoolean(KEY_ADMIN_ENABLED, false)

    fun setAdminEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_ADMIN_ENABLED, enabled).apply()
    }

    fun getFcmToken(): String? = prefs.getString(KEY_FCM_TOKEN, null)

    fun setFcmToken(token: String) {
        prefs.edit().putString(KEY_FCM_TOKEN, token).apply()
    }

    fun getDeviceId(): String? = prefs.getString(KEY_DEVICE_ID, null)

    fun setDeviceId(deviceId: String) {
        prefs.edit().putString(KEY_DEVICE_ID, deviceId).apply()
    }

    /**
     * Payment status cached locally. Authoritative value lives in Firestore.
     * Possible values: "active" | "suspended" | "revoked"
     * Default is "active" — set server-side and synced down via FCM if needed.
     */
    fun getPaymentStatus(): String? = prefs.getString(KEY_PAYMENT_STATUS, "active")

    fun setPaymentStatus(status: String) {
        prefs.edit().putString(KEY_PAYMENT_STATUS, status).apply()
    }
}
