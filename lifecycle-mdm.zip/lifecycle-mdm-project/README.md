# Lifecycle MDM

**Package:** `com.edwinpm.mdm`  
**Android SDK:** 26+ (Target: 35)  
**Language:** Kotlin + Jetpack Compose  
**Build System:** Gradle Kotlin DSL (.gradle.kts)

---

## Project Structure

```
lifecycle-mdm-project/
├── app/
│   ├── build.gradle.kts               ← App-level Gradle config
│   ├── google-services.json           ← REPLACE with your Firebase config
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/edwinpm/mdm/
│       │   ├── LifecycleApp.kt                ← Application class, channels
│       │   ├── admin/
│       │   │   ├── MdmDeviceAdminReceiver.kt  ← Device Admin callbacks
│       │   │   ├── DeviceOwnerHelper.kt        ← DPM operations (lock/wipe/block)
│       │   │   └── BootReceiver.kt             ← Auto-start on boot
│       │   ├── fcm/
│       │   │   └── MdmFcmService.kt            ← Firebase push commands
│       │   ├── kiosk/
│       │   │   ├── KioskLockActivity.kt        ← Full-screen lock overlay
│       │   │   └── KioskLockScreen.kt          ← Compose UI for lock screen
│       │   ├── service/
│       │   │   └── MdmWatchdogService.kt       ← Sticky foreground service
│       │   ├── worker/
│       │   │   └── WatchdogWorker.kt           ← WorkManager periodic job
│       │   ├── ui/
│       │   │   ├── MainActivity.kt
│       │   │   ├── MainScreen.kt               ← Compose admin UI
│       │   │   └── theme/
│       │   │       ├── Theme.kt
│       │   │       └── Type.kt
│       │   └── util/
│       │       └── MdmPrefs.kt                 ← SharedPreferences wrapper
│       └── res/
│           ├── drawable/
│           │   ├── ic_shield.xml
│           │   └── ic_lock.xml
│           ├── xml/
│           │   └── device_admin_policies.xml   ← Admin policy declaration
│           └── values/
│               ├── strings.xml
│               └── themes.xml
├── gradle/
│   ├── libs.versions.toml              ← Version Catalog
│   └── wrapper/
│       └── gradle-wrapper.properties
├── build.gradle.kts                   ← Root Gradle config
└── settings.gradle.kts
```

---

## Setup Instructions

### 1. Open in Android Studio

Open the `lifecycle-mdm-project` folder in Android Studio (Electric Eel or newer).

### 2. Set Up Firebase

1. Go to [Firebase Console](https://console.firebase.google.com)
2. Create a project (or use existing)
3. Add Android app with package: `com.edwinpm.mdm`
4. Download `google-services.json`
5. Replace `app/google-services.json` with the downloaded file
6. Enable **Firebase Cloud Messaging** in your project

### 3. Activate Device Admin

The app will prompt for Device Administrator rights on first launch.  
Grant the permission to enable lock and wipe capabilities.

### 4. Set as Device Owner (Recommended for Full Kiosk Mode)

For maximum security (prevents uninstall, enables true kiosk mode, blocks factory reset):

```bash
# Requirements: USB debugging enabled, NO Google accounts on device
adb shell dpm set-device-owner com.edwinpm.mdm/.admin.MdmDeviceAdminReceiver
```

---

## FCM Command Reference

Send FCM **data messages** (not notification messages) to the device token:

| Command  | Effect |
|----------|--------|
| `LOCK`   | Shows kiosk overlay, DPM locks screen |
| `UNLOCK` | Dismisses kiosk overlay |
| `WIPE`   | Factory resets the device (IRREVERSIBLE) |
| `PING`   | Logs device alive status |

**Example FCM payload:**
```json
{
  "message": {
    "token": "DEVICE_FCM_TOKEN",
    "data": {
      "command": "LOCK",
      "reason": "Payment overdue - Day 30"
    }
  }
}
```

---

## Security Architecture

| Layer | Mechanism |
|-------|-----------|
| Admin Privileges | `DeviceAdminReceiver` — lock, wipe, password policy |
| Device Owner | DPM — uninstall block, kiosk lock-task, keyguard disable |
| Persistence | `START_STICKY` Foreground Service + WorkManager 15-min job |
| Boot Survival | `BOOT_COMPLETED` BroadcastReceiver |
| Admin Removal Detection | `onDisableRequested()` triggers immediate re-lock |
| Remote Control | FCM data messages (LOCK/UNLOCK/WIPE/PING) |
| Kiosk Overlay | `KioskLockActivity` with `startLockTask()` + key event blocking |

---

## Building

```bash
./gradlew assembleDebug    # Debug APK
./gradlew assembleRelease  # Release APK (requires signing config)
```

---

## Notes for AIDE / J Studio

- Ensure your AIDE version supports Gradle Kotlin DSL (`.gradle.kts`)
- If AIDE requires Groovy DSL, rename files to `.gradle` and convert syntax
- Minimum Java 11 required for compilation
- The `google-services.json` must be replaced before building

---

## ⚠️ Legal Notice

This MDM application is intended for legitimate device management of credit-financed devices where the user has been informed and has consented to remote management capabilities. Ensure compliance with local privacy laws and regulations before deployment.
