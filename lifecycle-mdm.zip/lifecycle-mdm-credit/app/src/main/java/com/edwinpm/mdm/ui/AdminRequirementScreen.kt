package com.edwinpm.mdm.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.edwinpm.mdm.R

/**
 * AdminRequirementScreen — shown when the app has NOT been provisioned as
 * Device Owner + Device Admin yet.
 *
 * The user CANNOT proceed to the registration flow until both are active.
 * This screen is purely informational — no "Continue" button.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminRequirementScreen(
    isAdmin: Boolean,
    isDeviceOwner: Boolean,
    onRetry: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Device Provisioning Required", fontWeight = FontWeight.Bold, fontSize = 17.sp) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF0F1923))
            )
        },
        containerColor = Color(0xFF0D1117)
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Spacer(Modifier.height(16.dp))

            Icon(
                painter = painterResource(R.drawable.ic_shield),
                contentDescription = null,
                tint = Color(0xFFEF4444),
                modifier = Modifier.size(72.dp)
            )

            Text(
                "This app must be installed as\nDevice Owner & Device Admin\nbefore it can manage devices.",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
                lineHeight = 26.sp
            )

            Text(
                "Complete both steps below, then tap Retry.",
                color = Color(0xFF9CA3AF),
                fontSize = 14.sp,
                textAlign = TextAlign.Center
            )

            // ── Step 1: Device Admin ──────────────────────────────────────────
            RequirementCard(
                step       = "1",
                title      = "Device Administrator",
                status     = if (isAdmin) "DONE" else "REQUIRED",
                statusOk   = isAdmin,
                description = "Grant Device Administrator privileges when the system prompts you."
            )

            // ── Step 2: Device Owner ──────────────────────────────────────────
            RequirementCard(
                step       = "2",
                title      = "Device Owner (ADB)",
                status     = if (isDeviceOwner) "DONE" else "REQUIRED",
                statusOk   = isDeviceOwner,
                description = "Connect the device via USB (with USB debugging enabled, no Google accounts added) and run:"
            )

            // ADB command block
            if (!isDeviceOwner) {
                Surface(
                    color = Color(0xFF060D16),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "adb shell dpm set-device-owner\n  com.edwinpm.mdm/.admin.MdmDeviceAdminReceiver",
                        color = Color(0xFF4ADE80),
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            Button(
                onClick = onRetry,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B82F6))
            ) {
                Text("Retry", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }

            Text(
                "After completing both steps, tap Retry to continue.",
                color = Color(0xFF4B5563),
                fontSize = 12.sp,
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun RequirementCard(
    step: String,
    title: String,
    status: String,
    statusOk: Boolean,
    description: String
) {
    val statusColor = if (statusOk) Color(0xFF22C55E) else Color(0xFFFBBF24)
    val bgColor     = if (statusOk) Color(0xFF0D2010) else Color(0xFF1A1505)

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = bgColor),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .background(statusColor.copy(alpha = 0.15f), RoundedCornerShape(50)),
                contentAlignment = Alignment.Center
            ) {
                Text(step, color = statusColor, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    Box(
                        modifier = Modifier
                            .background(statusColor.copy(alpha = 0.15f), RoundedCornerShape(20.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(status, color = statusColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Text(description, color = Color(0xFF9CA3AF), fontSize = 13.sp, lineHeight = 19.sp)
            }
        }
    }
}
