package com.edwinpm.mdm.admin

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.util.Log

/**
 * DeviceOwnerHelper centralizes all Device Policy Manager operations.
 *
 * IMPORTANT: Most methods here require Device Owner mode.
 * Set Device Owner via ADB (no accounts on device):
 *   adb shell dpm set-device-owner com.edwinpm.mdm/.admin.MdmDeviceAdminReceiver
 *
 * Device Owner grants:
 *   - Block factory reset
 *   - Block uninstall of this app
 *   - Enable true kiosk/lock-task mode (Back+Recent escape is blocked)
 *   - Disable keyguard
 *   - Set password policies
 */
object DeviceOwnerHelper {

    private const val TAG = "DeviceOwnerHelper"

    fun getAdminComponent(context: Context): ComponentName =
        ComponentName(context, MdmDeviceAdminReceiver::class.java)

    fun isDeviceAdmin(context: Context): Boolean =
        dpm(context).isAdminActive(getAdminComponent(context))

    fun isDeviceOwner(context: Context): Boolean =
        dpm(context).isDeviceOwnerApp(context.packageName)

    /**
     * Applies ALL Device Owner policies in one call.
     * Safe to call on every app start — silently skips if not Device Owner.
     * Call this from Application.onCreate() and from the watchdog service.
     */
    fun applyAllPolicies(context: Context) {
        if (!isDeviceOwner(context)) {
            Log.w(TAG, "applyAllPolicies: not Device Owner — skipping DO policies")
            return
        }
        Log.i(TAG, "Applying all Device Owner policies")
        blockUninstall(context)
        enableLockTaskMode(context)   // includes setLockTaskFeatures(NONE) — blocks Back+Recent escape
        disableKeyguard(context)
        blockFactoryReset(context)
    }

    /**
     * Locks the device screen immediately.
     * Requires Device Admin privileges.
     */
    fun lockDeviceNow(context: Context) {
        if (!isDeviceAdmin(context)) {
            Log.w(TAG, "lockDeviceNow: not device admin")
            return
        }
        try {
            dpm(context).lockNow()
            Log.i(TAG, "Device locked via DPM")
        } catch (e: SecurityException) {
            Log.e(TAG, "lockNow failed: ${e.message}")
        }
    }

    /**
     * Initiates a factory wipe. IRREVERSIBLE.
     */
    fun wipeDevice(context: Context, reason: String = "MDM remote wipe") {
        if (!isDeviceAdmin(context)) {
            Log.w(TAG, "wipeDevice: not device admin")
            return
        }
        try {
            Log.w(TAG, "INITIATING FACTORY WIPE — Reason: $reason")
            dpm(context).wipeData(0)
        } catch (e: SecurityException) {
            Log.e(TAG, "wipeData failed: ${e.message}")
        }
    }

    /**
     * Block uninstallation of this app (Device Owner only).
     */
    fun blockUninstall(context: Context) {
        if (!isDeviceOwner(context)) {
            Log.w(TAG, "blockUninstall: not device owner")
            return
        }
        try {
            dpm(context).setUninstallBlocked(
                getAdminComponent(context),
                context.packageName,
                true
            )
            Log.i(TAG, "Uninstall blocked for ${context.packageName}")
        } catch (e: SecurityException) {
            Log.e(TAG, "setUninstallBlocked failed: ${e.message}")
        }
    }

    /**
     * Enable true Device Owner lock-task (kiosk) mode.
     *
     * KEY FIX: setLockTaskFeatures(LOCK_TASK_FEATURE_NONE) eliminates the
     * Back+Recent simultaneous press escape. Without this call, startLockTask()
     * falls back to user-escapable screen pinning mode regardless of DO status.
     *
     * Device Owner only.
     */
    fun enableLockTaskMode(context: Context) {
        if (!isDeviceOwner(context)) {
            Log.w(TAG, "enableLockTaskMode: not device owner")
            return
        }
        val admin = getAdminComponent(context)
        val d = dpm(context)
        try {
            // Step 1: whitelist our package for lock task
            d.setLockTaskPackages(admin, arrayOf(context.packageName))
            Log.i(TAG, "Lock task packages set to: ${context.packageName}")

            // Step 2: Allow GLOBAL_ACTIONS only (power button menu — needed for shutdown/restart).
            // LOCK_TASK_FEATURE_NONE (0) would also block the power button menu, preventing the
            // user from turning off the device. We deliberately keep GLOBAL_ACTIONS enabled.
            // Back + Recents, status bar, notifications, and home are still fully blocked.
            d.setLockTaskFeatures(admin, DevicePolicyManager.LOCK_TASK_FEATURE_GLOBAL_ACTIONS)
            Log.i(TAG, "Lock task features set: GLOBAL_ACTIONS only (power button allowed, all escapes blocked)")
        } catch (e: SecurityException) {
            Log.e(TAG, "enableLockTaskMode failed: ${e.message}")
        }
    }

    /**
     * Disable keyguard/lock screen features (Device Admin required).
     */
    fun disableKeyguard(context: Context) {
        if (!isDeviceAdmin(context)) return
        try {
            dpm(context).setKeyguardDisabledFeatures(
                getAdminComponent(context),
                DevicePolicyManager.KEYGUARD_DISABLE_FEATURES_ALL
            )
            Log.i(TAG, "Keyguard disabled")
        } catch (e: SecurityException) {
            Log.e(TAG, "disableKeyguard failed: ${e.message}")
        }
    }

    /**
     * Block factory reset protection (Device Owner only).
     * Prevents user from performing a factory reset via Settings → General Management.
     */
    fun blockFactoryReset(context: Context) {
        if (!isDeviceOwner(context)) return
        try {
            // Restrict the user from performing factory reset
            val restrictions = android.os.Bundle().apply {
                putBoolean(android.os.UserManager.DISALLOW_FACTORY_RESET, true)
                putBoolean(android.os.UserManager.DISALLOW_SAFE_BOOT, true)
                putBoolean(android.os.UserManager.DISALLOW_ADD_USER, true)
                putBoolean(android.os.UserManager.DISALLOW_MOUNT_PHYSICAL_MEDIA, true)
            }
            val admin = getAdminComponent(context)
            val d = dpm(context)
            d.addUserRestriction(admin, android.os.UserManager.DISALLOW_FACTORY_RESET)
            d.addUserRestriction(admin, android.os.UserManager.DISALLOW_SAFE_BOOT)
            d.addUserRestriction(admin, android.os.UserManager.DISALLOW_ADD_USER)
            Log.i(TAG, "Factory reset / safe boot / add user blocked")
        } catch (e: SecurityException) {
            Log.e(TAG, "blockFactoryReset failed: ${e.message}")
        }
    }

    /**
     * Set minimum password length policy.
     */
    fun enforcePasswordPolicy(context: Context, minLength: Int = 6) {
        if (!isDeviceAdmin(context)) return
        try {
            dpm(context).setPasswordMinimumLength(getAdminComponent(context), minLength)
            Log.i(TAG, "Password policy set: min length $minLength")
        } catch (e: SecurityException) {
            Log.e(TAG, "setPasswordMinimumLength failed: ${e.message}")
        }
    }

    private fun dpm(context: Context): DevicePolicyManager =
        context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
}
