package com.edwinpm.mdm.ui

  import androidx.compose.foundation.layout.*
  import androidx.compose.material3.*
  import androidx.compose.runtime.*
  import androidx.compose.ui.Alignment
  import androidx.compose.ui.Modifier
  import androidx.compose.ui.graphics.Color
  import androidx.compose.ui.res.painterResource
  import androidx.compose.ui.text.font.FontWeight
  import androidx.compose.ui.text.style.TextAlign
  import androidx.compose.ui.unit.dp
  import androidx.compose.ui.unit.sp
  import com.edwinpm.mdm.R

  /**
   * PaymentScreen — payment options flow.
   *
   * Shows the outstanding balance and the next scheduled payment date.
   * Includes a "Simulate Payment" button that triggers [onSimulatePayment].
   */
  @OptIn(ExperimentalMaterial3Api::class)
  @Composable
  fun PaymentScreen(
      balance: String,
      currency: String,
      installmentAmount: String,
      nextPaymentDate: String,
      isProcessing: Boolean,
      onBack: () -> Unit,
      onSimulatePayment: () -> Unit
  ) {
      Scaffold(
          topBar = {
              TopAppBar(
                  title = { Text("Make a Payment", fontWeight = FontWeight.Bold, fontSize = 17.sp) },
                  navigationIcon = {
                      IconButton(onClick = onBack) {
                          Icon(
                              painter = painterResource(R.drawable.ic_shield),
                              contentDescription = "Back",
                              tint = Color(0xFF9CA3AF),
                              modifier = Modifier.size(22.dp)
                          )
                      }
                  },
                  colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF0F1923))
              )
          },
          containerColor = Color(0xFF0D1117)
      ) { padding ->
          Column(
              modifier = Modifier
                  .fillMaxSize()
                  .padding(padding)
                  .padding(32.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.Center
          ) {
              Icon(
                  painter = painterResource(R.drawable.ic_shield),
                  contentDescription = null,
                  tint = Color(0xFF374151),
                  modifier = Modifier.size(64.dp)
              )

              Spacer(Modifier.height(24.dp))

              Text(
                  "Payment Summary",
                  color = Color.White,
                  fontSize = 22.sp,
                  fontWeight = FontWeight.Bold
              )

              Spacer(Modifier.height(16.dp))

              // ── Balance card ──────────────────────────────────────────────────
              Card(
                  modifier = Modifier.fillMaxWidth(),
                  colors = CardDefaults.cardColors(containerColor = Color(0xFF161B22)),
                  shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp)
              ) {
                  Column(
                      modifier = Modifier.padding(20.dp),
                      verticalArrangement = Arrangement.spacedBy(10.dp)
                  ) {
                      PaymentInfoRow(label = "Outstanding Balance", value = "$currency $balance")
                      if (installmentAmount.isNotBlank() && installmentAmount != "0") {
                          PaymentInfoRow(label = "Payment Amount", value = "$currency $installmentAmount")
                      }
                      if (nextPaymentDate.isNotBlank()) {
                          PaymentInfoRow(label = "Next Payment Date", value = nextPaymentDate)
                      }
                  }
              }

              Spacer(Modifier.height(32.dp))

              // ── Simulate Payment button ───────────────────────────────────────
              Button(
                  onClick = onSimulatePayment,
                  enabled = !isProcessing && balance != "0" && balance.isNotBlank(),
                  colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                  modifier = Modifier
                      .fillMaxWidth()
                      .height(52.dp),
                  shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
              ) {
                  if (isProcessing) {
                      CircularProgressIndicator(
                          color = Color.White,
                          modifier = Modifier.size(20.dp),
                          strokeWidth = 2.dp
                      )
                      Spacer(Modifier.width(10.dp))
                      Text("Processing...", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                  } else {
                      Text("Simulate Payment", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                  }
              }

              Spacer(Modifier.height(16.dp))

              OutlinedButton(
                  onClick = onBack,
                  colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF9CA3AF)),
                  border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF374151)),
                  modifier = Modifier.fillMaxWidth().height(50.dp)
              ) {
                  Text("Go Back", fontWeight = FontWeight.Medium)
              }
          }
      }
  }

  @Composable
  private fun PaymentInfoRow(label: String, value: String) {
      Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
      ) {
          Text(label, color = Color(0xFF9CA3AF), fontSize = 14.sp)
          Text(value, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
      }
  }
  