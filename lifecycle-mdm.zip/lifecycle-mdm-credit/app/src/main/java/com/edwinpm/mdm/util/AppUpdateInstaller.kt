package com.edwinpm.mdm.util

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.os.Build
import android.util.Log
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

object AppUpdateInstaller {

    private const val TAG = "AppUpdateInstaller"
    const val ACTION_INSTALL_COMMIT = "com.edwinpm.mdm.ACTION_INSTALL_COMMIT"
    const val EXTRA_SESSION_ID = "extra_session_id"
    private val executor = Executors.newSingleThreadExecutor()

    fun installFromUrl(context: Context, apkUrl: String, expectedVersionCode: Long? = null) {
        val appContext = context.applicationContext
        executor.execute {
            try {
                if (expectedVersionCode != null && expectedVersionCode > 0 && currentVersionCode(appContext) >= expectedVersionCode) {
                    Log.i(TAG, "Skipping update because installed version is already current")
                    return@execute
                }

                val packageInstaller = appContext.packageManager.packageInstaller
                val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL).apply {
                    setAppPackageName(appContext.packageName)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
                    }
                }
                val sessionId = packageInstaller.createSession(params)
                val session = packageInstaller.openSession(sessionId)

                try {
                    val connection = URL(apkUrl).openConnection() as HttpURLConnection
                    connection.connectTimeout = 30000
                    connection.readTimeout = 120000
                    connection.instanceFollowRedirects = true
                    connection.connect()

                    if (connection.responseCode !in 200..299) {
                        throw IllegalStateException("APK download failed with HTTP ${connection.responseCode}")
                    }

                    val length = connection.contentLengthLong.takeIf { it > 0 } ?: -1L
                    connection.inputStream.use { input ->
                        session.openWrite("lifecycle-mdm-update.apk", 0, length).use { output ->
                            input.copyTo(output)
                            session.fsync(output)
                        }
                    }

                    val intent = Intent(appContext, AppUpdateInstallReceiver::class.java).apply {
                        action = ACTION_INSTALL_COMMIT
                        putExtra(EXTRA_SESSION_ID, sessionId)
                    }
                    val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    val pendingIntent = PendingIntent.getBroadcast(appContext, sessionId, intent, flags)
                    session.commit(pendingIntent.intentSender)
                    Log.i(TAG, "Submitted APK update install session $sessionId")
                } catch (e: Exception) {
                    session.abandon()
                    throw e
                } finally {
                    session.close()
                }
            } catch (e: Exception) {
                Log.e(TAG, "App update install failed: ${e.message}", e)
            }
        }
    }

    private fun currentVersionCode(context: Context): Long {
        val info = context.packageManager.getPackageInfo(context.packageName, 0)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            info.longVersionCode
        } else {
            @Suppress("DEPRECATION")
            info.versionCode.toLong()
        }
    }
}