package com.edwinpm.mdm.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * SetupWizardScreen — device & credit registration form.
 *
 * Called after the business is verified. IMEI and Contract ID are NOT collected
 * here — they are obtained/generated automatically by MainActivity before this
 * screen is shown.
 *
 * Step 1: Customer information (name, phone)
 * Step 2: Credit plan details (plan name, currency, total, paid, due date)
 * Step 3: Confirmation summary
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SetupWizardScreen(
    businessInfo: BusinessInfo,
    imei: String,
    contractId: String,
    onSetupComplete: (SetupData) -> Unit
) {
    var step by remember { mutableIntStateOf(1) }

    var ownerName    by remember { mutableStateOf("") }
    var ownerPhone   by remember { mutableStateOf("") }

    var planName     by remember { mutableStateOf("") }
    var planTotal    by remember { mutableStateOf("") }
    var planPaid     by remember { mutableStateOf("") }
    var planDueDate  by remember { mutableStateOf("") }
    var planCurrency by remember { mutableStateOf("USD") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Device Registration — Step $step of 3",
                        fontWeight = FontWeight.Bold, fontSize = 17.sp
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF0F1923))
            )
        },
        containerColor = Color(0xFF0D1117)
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp, vertical = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            LinearProgressIndicator(
                progress = { step / 3f },
                modifier = Modifier.fillMaxWidth().height(6.dp),
                color = Color(0xFF3B82F6),
                trackColor = Color(0xFF1E2A3A)
            )
            Spacer(Modifier.height(2.dp))

            // Business info header (read-only)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0F1B2D), RoundedCornerShape(10.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(Color(0xFF1E3A5F), RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        businessInfo.name.take(1).uppercase(),
                        color = Color(0xFF60A5FA), fontWeight = FontWeight.Bold, fontSize = 18.sp
                    )
                }
                Column {
                    Text(businessInfo.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("Verified business", color = Color(0xFF22C55E), fontSize = 12.sp)
                }
            }

            when (step) {

                // ── Step 1: Customer Info ────────────────────────────────────
                1 -> {
                    STitle("Customer Information")
                    SSub("Enter the details of the customer receiving this device.")

                    CField("Full Name *", ownerName, "e.g. Maria Garcia") { ownerName = it }
                    CField("Phone Number *", ownerPhone, "e.g. +52 55 1234 5678",
                        KeyboardType.Phone) { ownerPhone = it }

                    // Auto-generated info (read-only display)
                    Spacer(Modifier.height(4.dp))
                    InfoReadOnly("Contract ID (auto)", contractId)
                    InfoReadOnly("Device IMEI (auto)", imei.ifBlank { "Not available" })

                    NavBtns(
                        onNext = { if (ownerName.isNotBlank() && ownerPhone.isNotBlank()) step = 2 },
                        nextEnabled = ownerName.isNotBlank() && ownerPhone.isNotBlank()
                    )
                }

                // ── Step 2: Credit Plan ──────────────────────────────────────
                2 -> {
                    STitle("Credit Plan Details")
                    SSub("Enter the financial terms of the credit agreement.")

                    CField("Plan Name *", planName, "e.g. 18-Month Smartphone Plan") { planName = it }
                    CField("Currency", planCurrency, "USD / EUR / MXN") { planCurrency = it.uppercase() }
                    CField("Total Amount *", planTotal, "e.g. 1200.00", KeyboardType.Decimal) { planTotal = it }
                    CField("Initial Payment / Deposit", planPaid, "e.g. 200.00 (0 if none)", KeyboardType.Decimal) { planPaid = it }
                    CField("First Payment Due Date *", planDueDate, "YYYY-MM-DD  e.g. 2025-08-01") { planDueDate = it }

                    NavBtns(
                        onBack = { step = 1 },
                        onNext = {
                            if (planName.isNotBlank() && planTotal.isNotBlank() && planDueDate.isNotBlank())
                                step = 3
                        },
                        nextEnabled = planName.isNotBlank() && planTotal.isNotBlank() && planDueDate.isNotBlank()
                    )
                }

                // ── Step 3: Confirmation ─────────────────────────────────────
                3 -> {
                    STitle("Confirm & Activate")
                    SSub("Review everything and tap Activate to complete the registration.")

                    ConfirmRow("Business",     businessInfo.name)
                    ConfirmRow("Customer",     ownerName)
                    ConfirmRow("Phone",        ownerPhone)
                    ConfirmRow("Contract ID",  contractId)
                    ConfirmRow("IMEI",         imei.ifBlank { "N/A" })
                    ConfirmRow("Plan",         planName)
                    ConfirmRow("Currency",     planCurrency)
                    ConfirmRow("Total",        planTotal)
                    if (planPaid.isNotBlank() && planPaid != "0")
                        ConfirmRow("Deposit Paid", planPaid)
                    ConfirmRow("First Due",    planDueDate)

                    Spacer(Modifier.height(4.dp))

                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedButton(
                            onClick = { step = 2 },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFADB5BD)),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF374151))
                        ) { Text("Back") }

                        Button(
                            onClick = {
                                val total   = planTotal.toDoubleOrNull() ?: 0.0
                                val paid    = planPaid.toDoubleOrNull()  ?: 0.0
                                val balance = (total - paid).coerceAtLeast(0.0)
                                onSetupComplete(
                                    SetupData(
                                        ownerName     = ownerName.trim(),
                                        ownerPhone    = ownerPhone.trim(),
                                        contractId    = contractId,
                                        deviceImei    = imei,
                                        planName      = planName.trim(),
                                        planCurrency  = planCurrency.trim(),
                                        planTotal     = total,
                                        planPaid      = paid,
                                        planBalance   = balance,
                                        planDueDate   = planDueDate.trim(),
                                        planOverdue   = 0.0,
                                        providerName  = businessInfo.name,
                                        providerPhone = businessInfo.phone
                                    )
                                )
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A))
                        ) { Text("Activate Device", fontWeight = FontWeight.Bold) }
                    }
                }
            }
            Spacer(Modifier.height(32.dp))
        }
    }
}

// ── Helpers ─────────────────────────────────────────────────────────────────────

@Composable private fun STitle(t: String) =
    Text(t, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)

@Composable private fun SSub(t: String) =
    Text(t, color = Color(0xFF9CA3AF), fontSize = 13.sp, lineHeight = 19.sp)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CField(
    label: String, value: String, placeholder: String,
    keyboardType: KeyboardType = KeyboardType.Text, onValueChange: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(label, color = Color(0xFF9CA3AF), fontSize = 12.sp)
        OutlinedTextField(
            value = value, onValueChange = onValueChange, singleLine = true,
            placeholder = { Text(placeholder, color = Color(0xFF4B5563), fontSize = 13.sp) },
            keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Color(0xFF3B82F6), unfocusedBorderColor = Color(0xFF374151),
                focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Color(0xFF3B82F6)
            ),
            modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp)
        )
    }
}

@Composable
private fun InfoReadOnly(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF161B22), RoundedCornerShape(8.dp))
            .padding(horizontal = 14.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Color(0xFF6B7280), fontSize = 12.sp)
        Text(value, color = Color(0xFF9CA3AF), fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun ConfirmRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF161B22), RoundedCornerShape(8.dp))
            .padding(horizontal = 14.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Color(0xFF6B7280), fontSize = 13.sp, modifier = Modifier.weight(1f))
        Spacer(Modifier.width(8.dp))
        Text(value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium,
            textAlign = TextAlign.End, modifier = Modifier.weight(2f))
    }
}

@Composable
private fun NavBtns(onBack: (() -> Unit)? = null, onNext: () -> Unit, nextEnabled: Boolean = true) {
    Spacer(Modifier.height(4.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        if (onBack != null) {
            OutlinedButton(
                onClick = onBack, modifier = Modifier.weight(1f),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFADB5BD)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF374151))
            ) { Text("Back") }
        } else { Spacer(Modifier.weight(1f)) }
        Button(
            onClick = onNext, enabled = nextEnabled, modifier = Modifier.weight(1f),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B82F6))
        ) { Text("Next", fontWeight = FontWeight.Bold) }
    }
}

data class SetupData(
    val ownerName: String, val ownerPhone: String, val contractId: String, val deviceImei: String,
    val planName: String, val planCurrency: String, val planTotal: Double, val planPaid: Double,
    val planBalance: Double, val planDueDate: String, val planOverdue: Double,
    val providerName: String, val providerPhone: String
)
