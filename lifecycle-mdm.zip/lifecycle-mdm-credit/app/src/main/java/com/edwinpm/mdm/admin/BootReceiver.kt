package com.edwinpm.mdm.admin

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.edwinpm.mdm.service.MdmWatchdogService
import com.edwinpm.mdm.util.AutoStartHelper
import com.edwinpm.mdm.util.MdmPrefs
import com.edwinpm.mdm.worker.WatchdogWorker

/**
 * BootReceiver starts the MDM watchdog service and WorkManager job after device reboot.
 *
 * FIX (Issue 2):
 *   - Declared android:directBootAware="true" in the manifest so this receiver fires
 *     during LOCKED_BOOT_COMPLETED (Direct Boot phase), before CE storage is decrypted.
 *   - During LOCKED_BOOT_COMPLETED, only DE (device-encrypted) storage is available.
 *     We use isLockedDirectBoot() which reads from DE storage for the lock flag.
 *   - During regular BOOT_COMPLETED, both DE and CE storage are available.
 *
 * NOTE: On manufacturer-skinned Androids (Samsung, Xiaomi, OPPO, Huawei, Vivo, etc.),
 * a proprietary "Auto-start" permission must also be granted by the user. This permission
 * is separate from Android's standard permission system and is prompted from MainActivity
 * via AutoStartHelper on the first app launch after setup.
 */
class BootReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "BootReceiver"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != "android.intent.action.LOCKED_BOOT_COMPLETED" &&
            action != "android.intent.action.QUICKBOOT_POWERON"
        ) return

        Log.i(TAG, "Boot broadcast received: $action")

        val isDirectBoot = action == "android.intent.action.LOCKED_BOOT_COMPLETED"

        // Start the watchdog foreground service.
        // During Direct Boot, MdmWatchdogService must also be directBootAware (set in manifest).
        val serviceIntent = Intent(context, MdmWatchdogService::class.java)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
            Log.i(TAG, "MDM watchdog service started (directBoot=$isDirectBoot)")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start watchdog service at boot: ${e.message}")
        }

        if (!isDirectBoot) {
            try {
                WatchdogWorker.enqueue(context)
                Log.i(TAG, "WatchdogWorker enqueued at boot")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to enqueue WatchdogWorker at boot: ${e.message}")
            }

            DeviceOwnerHelper.applyAllPolicies(context)
        }

        // If device was locked before reboot, re-apply lock.
        // Use isLockedDirectBoot() which reads from device-protected (DE) storage — this is
        // readable even during LOCKED_BOOT_COMPLETED, before CE storage is decrypted.
        // isLocked() (CE storage) would always return false at this early boot stage.
        val prefs = MdmPrefs(context)
        val wasLocked = if (isDirectBoot) prefs.isLockedDirectBoot() else prefs.isLocked()
        if (wasLocked) {
            Log.i(TAG, "Device was locked before reboot — re-applying lock")
            MdmWatchdogService.sendCommand(context, MdmWatchdogService.CMD_LOCK)
        }
    }
}
