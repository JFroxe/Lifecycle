package com.edwinpm.mdm.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Full-screen loading indicator shown only while the automatic provisioning
 * verification is in progress. There is no user input on this screen.
 * On success the caller transitions directly to the Dashboard.
 * On failure the caller closes the app — this screen is never shown in error state.
 */
@Composable
fun ProvisioningScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            CircularProgressIndicator(
                color       = Color(0xFF3B82F6),
                modifier    = Modifier.size(64.dp),
                strokeWidth = 4.dp
            )

            Text(
                "Activating Device",
                color      = Color.White,
                fontSize   = 20.sp,
                fontWeight = FontWeight.Bold,
                textAlign  = TextAlign.Center
            )

            Text(
                "Please wait while we verify your device...",
                color     = Color(0xFF9CA3AF),
                fontSize  = 14.sp,
                textAlign = TextAlign.Center,
                lineHeight = 20.sp
            )
        }
    }
}
