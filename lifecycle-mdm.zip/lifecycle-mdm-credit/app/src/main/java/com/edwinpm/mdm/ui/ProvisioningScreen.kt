package com.edwinpm.mdm.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * ProvisioningScreen — manages the first-time device setup flow.
 *
 * States:
 *  ① [ProvisioningStep.Scan]     — QR scanner is shown; user scans the provisioning QR code.
 *  ② [ProvisioningStep.Verifying] — spinner shown while Firestore verification runs.
 *
 * When a valid QR code is scanned, [onQrScanned] is called with the three
 * provisioning IDs. The caller (MainActivity) then kicks off [verifyAndActivate]
 * and eventually calls [onActivated] or closes the app on failure.
 *
 * The [verifying] flag is driven by the caller: set it to true once the QR
 * has been scanned and verification has started.
 */
sealed class ProvisioningStep {
    object Scan      : ProvisioningStep()
    object Verifying : ProvisioningStep()
}

@Composable
fun ProvisioningScreen(
    verifying: Boolean = false,
    onQrScanned: (ProvisioningQrData) -> Unit
) {
    if (verifying) {
        VerifyingSpinner()
    } else {
        QrScannerScreen(onScanned = onQrScanned)
    }
}

/**
 * Full-screen loading indicator shown while Firestore verification is running.
 */
@Composable
private fun VerifyingSpinner() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            CircularProgressIndicator(
                color       = Color(0xFF3B82F6),
                modifier    = Modifier.size(64.dp),
                strokeWidth = 4.dp
            )

            Text(
                "Activating Device",
                color      = Color.White,
                fontSize   = 20.sp,
                fontWeight = FontWeight.Bold,
                textAlign  = TextAlign.Center
            )

            Text(
                "Please wait while we verify your device...",
                color      = Color(0xFF9CA3AF),
                fontSize   = 14.sp,
                textAlign  = TextAlign.Center,
                lineHeight = 20.sp
            )
        }
    }
}
