package com.edwinpm.mdm.admin

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import com.edwinpm.mdm.kiosk.KioskLockActivity
import com.edwinpm.mdm.util.MdmPrefs

class MdmDeviceAdminReceiver : DeviceAdminReceiver() {

    companion object {
        private const val TAG = "MdmDeviceAdminReceiver"

        const val EXTRA_BUSINESS_ID     = "businessId"
        const val EXTRA_ACTIVATION_KEY  = "activationKey"
        const val EXTRA_CONTRACT_NUMBER = "contractNumber"

        /**
         * Android places the QR PROVISIONING_ADMIN_EXTRAS_BUNDLE values inside
         * a nested Bundle under this key in the provisioning complete intent.
         */
        private const val PROVISIONING_ADMIN_EXTRAS_BUNDLE =
            "android.app.extra.PROVISIONING_ADMIN_EXTRAS_BUNDLE"
    }

    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        Log.i(TAG, "Device Admin ENABLED")
        MdmPrefs(context).setAdminEnabled(true)
    }

    override fun onProfileProvisioningComplete(context: Context, intent: Intent) {
        super.onProfileProvisioningComplete(context, intent)
        Log.i(TAG, "Profile provisioning complete — extracting QR extras")

        /*
         * The values set in PROVISIONING_ADMIN_EXTRAS_BUNDLE in the QR code are
         * delivered inside a nested Bundle with key PROVISIONING_ADMIN_EXTRAS_BUNDLE.
         * Fall back to the top-level extras for older API paths.
         */
        val adminBundle: Bundle =
            intent.getBundleExtra(PROVISIONING_ADMIN_EXTRAS_BUNDLE)
                ?: intent.extras
                ?: Bundle()

        val businessId     = adminBundle.getString(EXTRA_BUSINESS_ID,     "").orEmpty().trim()
        val activationKey  = adminBundle.getString(EXTRA_ACTIVATION_KEY,  "").orEmpty().trim()
        val contractNumber = adminBundle.getString(EXTRA_CONTRACT_NUMBER,  "").orEmpty().trim()

        Log.i(TAG, "QR extras — businessId='$businessId'  contractNumber='$contractNumber'")

        if (businessId.isBlank() || activationKey.isBlank() || contractNumber.isBlank()) {
            Log.e(TAG, "One or more QR extras are blank — provisioning data not saved")
            return
        }

        val prefs = MdmPrefs(context)
        prefs.setBusinessId(businessId)
        prefs.setActivationKey(activationKey)
        prefs.setContractNumber(contractNumber)
        prefs.markProvisioningDone()

        Log.i(TAG, "Provisioning extras saved successfully")
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        Log.w(TAG, "Device Admin DISABLED — attempting re-lock")
        MdmPrefs(context).setAdminEnabled(false)
        context.startActivity(
            Intent(context, KioskLockActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra(KioskLockActivity.EXTRA_REASON, "Admin disabled — device locked")
            }
        )
    }

    override fun onDisableRequested(context: Context, intent: Intent): CharSequence {
        Log.w(TAG, "Device Admin disable REQUESTED — alerting user")
        context.startActivity(
            Intent(context, KioskLockActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra(KioskLockActivity.EXTRA_REASON, "Security Alert: Admin removal blocked")
            }
        )
        return "WARNING: Disabling MDM will violate your device agreement."
    }

    override fun onPasswordChanged(context: Context, intent: Intent) {
        Log.i(TAG, "Device password changed")
    }

    override fun onPasswordFailed(context: Context, intent: Intent) {
        Log.w(TAG, "Device password FAILED attempt")
    }
}
