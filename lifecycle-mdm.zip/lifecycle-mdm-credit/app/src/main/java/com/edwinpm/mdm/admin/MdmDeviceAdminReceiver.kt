package com.edwinpm.mdm.admin

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.edwinpm.mdm.kiosk.KioskLockActivity
import com.edwinpm.mdm.util.MdmPrefs

/**
 * DeviceAdminReceiver handles Device Administrator lifecycle events.
 *
 * DEVICE OWNER MODE:
 * To set this app as Device Owner (prevents uninstallation and factory reset),
 * run the following ADB command on the device (USB debugging must be enabled,
 * no accounts added to the device):
 *
 *   adb shell dpm set-device-owner com.edwinpm.mdm/.admin.MdmDeviceAdminReceiver
 *
 * As Device Owner, you gain additional DPM policies:
 *   - dpm.setFactoryResetProtectionPolicy(adminComponent, policy) — block factory reset
 *   - dpm.setUninstallBlocked(adminComponent, packageName, true) — block uninstall
 *   - dpm.setLockTaskPackages(adminComponent, arrayOf(packageName)) — kiosk/lock-task mode
 *   - dpm.setKeyguardDisabledFeatures(adminComponent, ALL_FEATURES) — disable keyguard
 */
class MdmDeviceAdminReceiver : DeviceAdminReceiver() {

    companion object {
        private const val TAG = "MdmDeviceAdminReceiver"
    }

    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        Log.i(TAG, "Device Admin ENABLED")
        MdmPrefs(context).setAdminEnabled(true)
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        Log.w(TAG, "Device Admin DISABLED — attempting re-lock")
        MdmPrefs(context).setAdminEnabled(false)
        // When admin is forcibly disabled, immediately trigger lock overlay
        val lockIntent = Intent(context, KioskLockActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra(KioskLockActivity.EXTRA_REASON, "Admin disabled — device locked")
        }
        context.startActivity(lockIntent)
    }

    override fun onDisableRequested(context: Context, intent: Intent): CharSequence {
        Log.w(TAG, "Device Admin disable REQUESTED — alerting user")
        // Trigger immediate lock when user tries to disable admin
        val lockIntent = Intent(context, KioskLockActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra(KioskLockActivity.EXTRA_REASON, "Security Alert: Admin removal blocked")
        }
        context.startActivity(lockIntent)
        return "WARNING: Disabling MDM will violate your device agreement."
    }

    override fun onPasswordChanged(context: Context, intent: Intent) {
        Log.i(TAG, "Device password changed")
    }

    override fun onPasswordFailed(context: Context, intent: Intent) {
        Log.w(TAG, "Device password FAILED attempt")
    }
}
