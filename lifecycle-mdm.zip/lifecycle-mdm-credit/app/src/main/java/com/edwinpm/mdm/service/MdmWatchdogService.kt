package com.edwinpm.mdm.service

import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import com.edwinpm.mdm.LifecycleApp
import com.edwinpm.mdm.R
import com.edwinpm.mdm.admin.DeviceOwnerHelper
import com.edwinpm.mdm.kiosk.KioskLockActivity
import com.edwinpm.mdm.ui.MainActivity
import com.edwinpm.mdm.util.MdmPrefs
import com.edwinpm.mdm.worker.WatchdogWorker

/**
 * MdmWatchdogService — sticky foreground service.
 *
 * Responsibilities:
 *   1. Keeps the MDM agent alive with a persistent notification
 *   2. Re-applies Device Owner policies on every start
 *   3. Handles Lock / Unlock / Wipe commands from FCM or internal callers
 *   4. Passes credit-lock context (overdue amount, currency) to KioskLockActivity
 *   5. Auto-restarts via START_STICKY
 */
class MdmWatchdogService : LifecycleService() {

    companion object {
        private const val TAG = "MdmWatchdogService"

        const val CMD_LOCK   = "ACTION_LOCK"
        const val CMD_UNLOCK = "ACTION_UNLOCK"
        const val CMD_WIPE   = "ACTION_WIPE"

        const val EXTRA_OVERDUE_AMOUNT = "extra_overdue"
        const val EXTRA_CURRENCY       = "extra_currency"

        fun sendCommand(
            context: Context,
            command: String,
            reason: String         = "",
            overdueAmount: String  = "",
            currency: String       = ""
        ) {
            val intent = Intent(context, MdmWatchdogService::class.java).apply {
                action = command
                putExtra("reason",              reason)
                putExtra(EXTRA_OVERDUE_AMOUNT,  overdueAmount)
                putExtra(EXTRA_CURRENCY,        currency)
            }
            context.startForegroundService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "WatchdogService created")
        startForeground(LifecycleApp.NOTIFICATION_ID_WATCHDOG, buildWatchdogNotification())
        DeviceOwnerHelper.applyAllPolicies(this)
        WatchdogWorker.enqueue(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)

        val action        = intent?.action
        val reason        = intent?.getStringExtra("reason") ?: ""
        val overdueAmount = intent?.getStringExtra(EXTRA_OVERDUE_AMOUNT) ?: ""
        val currency      = intent?.getStringExtra(EXTRA_CURRENCY) ?: ""

        Log.i(TAG, "onStartCommand: action=$action, reason=$reason")

        when (action) {
            CMD_LOCK   -> handleLock(reason, overdueAmount, currency)
            CMD_UNLOCK -> handleUnlock(reason)
            CMD_WIPE   -> handleWipe(reason)
            else       -> {
                DeviceOwnerHelper.applyAllPolicies(this)
                if (MdmPrefs(this).isLocked()) {
                    val prefs = MdmPrefs(this)
                    handleLock(
                        "Re-enforcing lock after restart",
                        formatAmount(prefs.getPlanOverdueAmount()),
                        prefs.getPlanCurrency()
                    )
                }
            }
        }

        return START_STICKY
    }

    private fun handleLock(reason: String, overdueAmount: String, currency: String) {
        Log.w(TAG, "LOCK command — Reason: $reason")
        MdmPrefs(this).setLocked(true)
        DeviceOwnerHelper.applyAllPolicies(this)
        DeviceOwnerHelper.lockDeviceNow(this)

        val lockIntent = Intent(this, KioskLockActivity::class.java).apply {
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK  or
                Intent.FLAG_ACTIVITY_CLEAR_TOP or
                Intent.FLAG_ACTIVITY_SINGLE_TOP
            )
            putExtra(KioskLockActivity.EXTRA_REASON,         reason.ifEmpty { "Device locked by MDM" })
            putExtra(KioskLockActivity.EXTRA_OVERDUE_AMOUNT, overdueAmount)
            putExtra(KioskLockActivity.EXTRA_CURRENCY,       currency)
        }
        startActivity(lockIntent)
    }

    private fun handleUnlock(reason: String) {
        Log.i(TAG, "UNLOCK command — Reason: $reason")
        MdmPrefs(this).setLocked(false)

        val unlockBroadcast = Intent(KioskLockActivity.ACTION_UNLOCK)
        sendBroadcast(unlockBroadcast)

        val mainIntent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        startActivity(mainIntent)
    }

    private fun handleWipe(reason: String) {
        Log.w(TAG, "WIPE command — Reason: $reason")
        DeviceOwnerHelper.wipeDevice(this, reason)
    }

    private fun buildWatchdogNotification(): Notification {
        val contentIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, LifecycleApp.CHANNEL_WATCHDOG)
            .setContentTitle("Lifecycle MDM Active")
            .setContentText("Credit device management is running")
            .setSmallIcon(R.drawable.ic_shield)
            .setOngoing(true)
            .setContentIntent(contentIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.w(TAG, "WatchdogService destroyed — START_STICKY will restart it")
    }

    private fun formatAmount(v: Double): String =
        if (v == 0.0) "" else if (v == kotlin.math.floor(v)) "%.0f".format(v) else "%.2f".format(v)
}
