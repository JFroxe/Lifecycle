package com.edwinpm.mdm.util

import android.content.Context
import android.content.SharedPreferences

class MdmPrefs(context: Context) {

    companion object {
        private const val PREFS_NAME = "mdm_prefs"
        private const val KEY_LOCKED           = "is_locked"
        private const val KEY_ADMIN_ENABLED    = "admin_enabled"
        private const val KEY_FCM_TOKEN        = "fcm_token"
        private const val KEY_DEVICE_ID        = "device_id"
        private const val KEY_SETUP_DONE       = "setup_done"
        private const val KEY_PAYMENT_STATUS   = "payment_status"
        private const val KEY_PLAN_NAME        = "plan_name"
        private const val KEY_PLAN_TOTAL       = "plan_total_amount"
        private const val KEY_PLAN_PAID        = "plan_paid_amount"
        private const val KEY_PLAN_BALANCE     = "plan_balance_amount"
        private const val KEY_PLAN_DUE_DATE    = "plan_due_date"
        private const val KEY_PLAN_OVERDUE     = "plan_overdue_amount"
        private const val KEY_PLAN_CURRENCY    = "plan_currency"
        private const val KEY_OWNER_NAME       = "owner_name"
        private const val KEY_OWNER_PHONE      = "owner_phone"
        private const val KEY_OWNER_ID_NUMBER  = "owner_id_number"
        private const val KEY_CONTRACT_ID      = "contract_id"
        private const val KEY_IMEI             = "device_imei"
        private const val KEY_SERIAL_NUMBER    = "device_serial_number"
        private const val KEY_BUSINESS_ID      = "business_id"
        private const val KEY_BUSINESS_NAME    = "business_name"
        private const val KEY_BUSINESS_PHONE   = "business_phone"
        private const val KEY_BUSINESS_ADDRESS = "business_address"
        private const val KEY_ACTIVATION_KEY   = "activation_key"
        private const val KEY_CONTRACT_NUMBER  = "contract_number"
        private const val KEY_INSTALLMENT_VALUE = "installment_value"
        private const val KEY_PAYMENT_FREQUENCY = "payment_frequency"
        private const val KEY_PROVISIONING_DONE = "provisioning_extras_saved"
    }

    /** Regular credential-encrypted storage (available after user unlock). */
    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    /**
     * Device-protected storage (available immediately after boot, before unlock).
     * Used to persist provisioning IDs that arrive during initial provisioning
     * when the device may not yet be unlocked.
     */
    private val dePrefs: SharedPreferences =
        context.createDeviceProtectedStorageContext()
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    // ── Lock state (written to both storages so it survives direct boot) ───────

    fun isLocked(): Boolean = prefs.getBoolean(KEY_LOCKED, false)
    fun isLockedDirectBoot(): Boolean = dePrefs.getBoolean(KEY_LOCKED, false)
    fun setLocked(locked: Boolean) {
        prefs.edit().putBoolean(KEY_LOCKED, locked).apply()
        dePrefs.edit().putBoolean(KEY_LOCKED, locked).apply()
    }

    // ── Admin ─────────────────────────────────────────────────────────────────

    fun isAdminEnabled(): Boolean = prefs.getBoolean(KEY_ADMIN_ENABLED, false)
    fun setAdminEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_ADMIN_ENABLED, enabled).apply()
    }

    // ── FCM / Device identifiers ──────────────────────────────────────────────

    fun getFcmToken(): String? = prefs.getString(KEY_FCM_TOKEN, null)
    fun setFcmToken(token: String) { prefs.edit().putString(KEY_FCM_TOKEN, token).apply() }

    fun getDeviceId(): String? = prefs.getString(KEY_DEVICE_ID, null)
    fun setDeviceId(deviceId: String) { prefs.edit().putString(KEY_DEVICE_ID, deviceId).apply() }

    // ── Setup / provisioning flags ────────────────────────────────────────────

    fun isSetupDone(): Boolean = prefs.getBoolean(KEY_SETUP_DONE, false)
    fun markSetupDone() {
        prefs.edit().putBoolean(KEY_SETUP_DONE, true).apply()
        dePrefs.edit().putBoolean(KEY_SETUP_DONE, true).apply()
    }

    fun isProvisioningDone(): Boolean =
        prefs.getBoolean(KEY_PROVISIONING_DONE, false) ||
                dePrefs.getBoolean(KEY_PROVISIONING_DONE, false)

    fun markProvisioningDone() {
        prefs.edit().putBoolean(KEY_PROVISIONING_DONE, true).apply()
        dePrefs.edit().putBoolean(KEY_PROVISIONING_DONE, true).apply()
    }

    // ── Provisioning IDs (businessId, activationKey, contractNumber) ──────────
    //
    // These three values arrive during QR provisioning — possibly before the
    // device is unlocked.  We write them to BOTH storages and always try the
    // device-protected storage as a fallback when reading.

    fun getBusinessId(): String =
        prefs.getString(KEY_BUSINESS_ID, "").orEmpty().ifBlank {
            dePrefs.getString(KEY_BUSINESS_ID, "").orEmpty()
        }

    fun setBusinessId(v: String) {
        prefs.edit().putString(KEY_BUSINESS_ID, v).apply()
        dePrefs.edit().putString(KEY_BUSINESS_ID, v).apply()
    }

    fun getActivationKey(): String =
        prefs.getString(KEY_ACTIVATION_KEY, "").orEmpty().ifBlank {
            dePrefs.getString(KEY_ACTIVATION_KEY, "").orEmpty()
        }

    fun setActivationKey(v: String) {
        prefs.edit().putString(KEY_ACTIVATION_KEY, v).apply()
        dePrefs.edit().putString(KEY_ACTIVATION_KEY, v).apply()
    }

    fun getContractNumber(): String =
        prefs.getString(KEY_CONTRACT_NUMBER, "").orEmpty().ifBlank {
            dePrefs.getString(KEY_CONTRACT_NUMBER, "").orEmpty()
        }

    fun setContractNumber(v: String) {
        prefs.edit().putString(KEY_CONTRACT_NUMBER, v).apply()
        dePrefs.edit().putString(KEY_CONTRACT_NUMBER, v).apply()
    }

    // ── Payment / plan data ───────────────────────────────────────────────────

    fun getPaymentStatus(): String = prefs.getString(KEY_PAYMENT_STATUS, "active") ?: "active"
    fun setPaymentStatus(s: String) { prefs.edit().putString(KEY_PAYMENT_STATUS, s).apply() }

    fun getPlanName(): String = prefs.getString(KEY_PLAN_NAME, "") ?: ""
    fun setPlanName(v: String) { prefs.edit().putString(KEY_PLAN_NAME, v).apply() }

    fun getPlanTotalAmount(): Double = Double.fromBits(prefs.getLong(KEY_PLAN_TOTAL, 0L))
    fun setPlanTotalAmount(v: Double) { prefs.edit().putLong(KEY_PLAN_TOTAL, v.toBits()).apply() }

    fun getPlanPaidAmount(): Double = Double.fromBits(prefs.getLong(KEY_PLAN_PAID, 0L))
    fun setPlanPaidAmount(v: Double) { prefs.edit().putLong(KEY_PLAN_PAID, v.toBits()).apply() }

    fun getPlanBalance(): Double = Double.fromBits(prefs.getLong(KEY_PLAN_BALANCE, 0L))
    fun setPlanBalance(v: Double) { prefs.edit().putLong(KEY_PLAN_BALANCE, v.toBits()).apply() }

    fun getPlanDueDate(): String = prefs.getString(KEY_PLAN_DUE_DATE, "") ?: ""
    fun setPlanDueDate(d: String) { prefs.edit().putString(KEY_PLAN_DUE_DATE, d).apply() }

    fun getPlanOverdueAmount(): Double = Double.fromBits(prefs.getLong(KEY_PLAN_OVERDUE, 0L))
    fun setPlanOverdueAmount(v: Double) { prefs.edit().putLong(KEY_PLAN_OVERDUE, v.toBits()).apply() }

    fun getPlanCurrency(): String = prefs.getString(KEY_PLAN_CURRENCY, "USD") ?: "USD"
    fun setPlanCurrency(c: String) { prefs.edit().putString(KEY_PLAN_CURRENCY, c).apply() }

    fun getInstallmentValue(): Double = Double.fromBits(prefs.getLong(KEY_INSTALLMENT_VALUE, 0L))
    fun setInstallmentValue(v: Double) { prefs.edit().putLong(KEY_INSTALLMENT_VALUE, v.toBits()).apply() }

    fun getPaymentFrequency(): String = prefs.getString(KEY_PAYMENT_FREQUENCY, "") ?: ""
    fun setPaymentFrequency(v: String) { prefs.edit().putString(KEY_PAYMENT_FREQUENCY, v).apply() }

    // ── Owner / customer ──────────────────────────────────────────────────────

    fun getOwnerName(): String = prefs.getString(KEY_OWNER_NAME, "") ?: ""
    fun setOwnerName(v: String) { prefs.edit().putString(KEY_OWNER_NAME, v).apply() }

    fun getOwnerPhone(): String = prefs.getString(KEY_OWNER_PHONE, "") ?: ""
    fun setOwnerPhone(v: String) { prefs.edit().putString(KEY_OWNER_PHONE, v).apply() }

    fun getOwnerIdNumber(): String = prefs.getString(KEY_OWNER_ID_NUMBER, "") ?: ""
    fun setOwnerIdNumber(v: String) { prefs.edit().putString(KEY_OWNER_ID_NUMBER, v).apply() }

    // ── Device identifiers ────────────────────────────────────────────────────

    fun getContractId(): String = prefs.getString(KEY_CONTRACT_ID, "") ?: ""
    fun setContractId(v: String) { prefs.edit().putString(KEY_CONTRACT_ID, v).apply() }

    fun getDeviceImei(): String = prefs.getString(KEY_IMEI, "") ?: ""
    fun setDeviceImei(v: String) { prefs.edit().putString(KEY_IMEI, v).apply() }

    fun getSerialNumber(): String = prefs.getString(KEY_SERIAL_NUMBER, "") ?: ""
    fun setSerialNumber(v: String) { prefs.edit().putString(KEY_SERIAL_NUMBER, v).apply() }

    // ── Business info ─────────────────────────────────────────────────────────

    fun getBusinessName(): String = prefs.getString(KEY_BUSINESS_NAME, "") ?: ""
    fun setBusinessName(v: String) { prefs.edit().putString(KEY_BUSINESS_NAME, v).apply() }

    fun getBusinessPhone(): String = prefs.getString(KEY_BUSINESS_PHONE, "") ?: ""
    fun setBusinessPhone(v: String) { prefs.edit().putString(KEY_BUSINESS_PHONE, v).apply() }

    fun getBusinessAddress(): String = prefs.getString(KEY_BUSINESS_ADDRESS, "") ?: ""
    fun setBusinessAddress(v: String) { prefs.edit().putString(KEY_BUSINESS_ADDRESS, v).apply() }
}
