package com.edwinpm.mdm.util

import android.content.Context
import android.content.SharedPreferences

class MdmPrefs(context: Context) {

    companion object {
        private const val PREFS_NAME = "mdm_prefs"
        private const val KEY_LOCKED          = "is_locked"
        private const val KEY_ADMIN_ENABLED   = "admin_enabled"
        private const val KEY_FCM_TOKEN       = "fcm_token"
        private const val KEY_DEVICE_ID       = "device_id"
        private const val KEY_SETUP_DONE      = "setup_done"
        private const val KEY_PAYMENT_STATUS  = "payment_status"
        private const val KEY_PLAN_NAME       = "plan_name"
        private const val KEY_PLAN_TOTAL      = "plan_total_amount"
        private const val KEY_PLAN_PAID       = "plan_paid_amount"
        private const val KEY_PLAN_BALANCE    = "plan_balance_amount"
        private const val KEY_PLAN_DUE_DATE   = "plan_due_date"
        private const val KEY_PLAN_OVERDUE    = "plan_overdue_amount"
        private const val KEY_PLAN_CURRENCY   = "plan_currency"
        private const val KEY_OWNER_NAME      = "owner_name"
        private const val KEY_OWNER_PHONE     = "owner_phone"
        private const val KEY_CONTRACT_ID     = "contract_id"
        private const val KEY_IMEI            = "device_imei"
        private const val KEY_BUSINESS_ID     = "business_id"
        private const val KEY_BUSINESS_NAME   = "business_name"
        private const val KEY_BUSINESS_PHONE  = "business_phone"
        private const val KEY_BUSINESS_ADDRESS = "business_address"
    }

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val dePrefs: SharedPreferences =
        context.createDeviceProtectedStorageContext()
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun isLocked(): Boolean = prefs.getBoolean(KEY_LOCKED, false)
    fun isLockedDirectBoot(): Boolean = dePrefs.getBoolean(KEY_LOCKED, false)
    fun setLocked(locked: Boolean) {
        prefs.edit().putBoolean(KEY_LOCKED, locked).apply()
        dePrefs.edit().putBoolean(KEY_LOCKED, locked).apply()
    }

    fun isAdminEnabled(): Boolean = prefs.getBoolean(KEY_ADMIN_ENABLED, false)
    fun setAdminEnabled(enabled: Boolean) { prefs.edit().putBoolean(KEY_ADMIN_ENABLED, enabled).apply() }

    fun getFcmToken(): String? = prefs.getString(KEY_FCM_TOKEN, null)
    fun setFcmToken(token: String) { prefs.edit().putString(KEY_FCM_TOKEN, token).apply() }

    fun getDeviceId(): String? = prefs.getString(KEY_DEVICE_ID, null)
    fun setDeviceId(deviceId: String) { prefs.edit().putString(KEY_DEVICE_ID, deviceId).apply() }

    fun isSetupDone(): Boolean = prefs.getBoolean(KEY_SETUP_DONE, false)
    fun markSetupDone() { prefs.edit().putBoolean(KEY_SETUP_DONE, true).apply() }

    fun getPaymentStatus(): String = prefs.getString(KEY_PAYMENT_STATUS, "active") ?: "active"
    fun setPaymentStatus(s: String) { prefs.edit().putString(KEY_PAYMENT_STATUS, s).apply() }

    fun getPlanName(): String = prefs.getString(KEY_PLAN_NAME, "") ?: ""
    fun setPlanName(v: String) { prefs.edit().putString(KEY_PLAN_NAME, v).apply() }

    fun getPlanTotalAmount(): Double = Double.fromBits(prefs.getLong(KEY_PLAN_TOTAL, 0L))
    fun setPlanTotalAmount(v: Double) { prefs.edit().putLong(KEY_PLAN_TOTAL, v.toBits()).apply() }

    fun getPlanPaidAmount(): Double = Double.fromBits(prefs.getLong(KEY_PLAN_PAID, 0L))
    fun setPlanPaidAmount(v: Double) { prefs.edit().putLong(KEY_PLAN_PAID, v.toBits()).apply() }

    fun getPlanBalance(): Double = Double.fromBits(prefs.getLong(KEY_PLAN_BALANCE, 0L))
    fun setPlanBalance(v: Double) { prefs.edit().putLong(KEY_PLAN_BALANCE, v.toBits()).apply() }

    fun getPlanDueDate(): String = prefs.getString(KEY_PLAN_DUE_DATE, "") ?: ""
    fun setPlanDueDate(d: String) { prefs.edit().putString(KEY_PLAN_DUE_DATE, d).apply() }

    fun getPlanOverdueAmount(): Double = Double.fromBits(prefs.getLong(KEY_PLAN_OVERDUE, 0L))
    fun setPlanOverdueAmount(v: Double) { prefs.edit().putLong(KEY_PLAN_OVERDUE, v.toBits()).apply() }

    fun getPlanCurrency(): String = prefs.getString(KEY_PLAN_CURRENCY, "USD") ?: "USD"
    fun setPlanCurrency(c: String) { prefs.edit().putString(KEY_PLAN_CURRENCY, c).apply() }

    fun getOwnerName(): String = prefs.getString(KEY_OWNER_NAME, "") ?: ""
    fun setOwnerName(v: String) { prefs.edit().putString(KEY_OWNER_NAME, v).apply() }

    fun getOwnerPhone(): String = prefs.getString(KEY_OWNER_PHONE, "") ?: ""
    fun setOwnerPhone(v: String) { prefs.edit().putString(KEY_OWNER_PHONE, v).apply() }

    fun getContractId(): String = prefs.getString(KEY_CONTRACT_ID, "") ?: ""
    fun setContractId(v: String) { prefs.edit().putString(KEY_CONTRACT_ID, v).apply() }

    fun getDeviceImei(): String = prefs.getString(KEY_IMEI, "") ?: ""
    fun setDeviceImei(v: String) { prefs.edit().putString(KEY_IMEI, v).apply() }

    fun getBusinessId(): String = prefs.getString(KEY_BUSINESS_ID, "") ?: ""
    fun setBusinessId(v: String) { prefs.edit().putString(KEY_BUSINESS_ID, v).apply() }

    fun getBusinessName(): String = prefs.getString(KEY_BUSINESS_NAME, "") ?: ""
    fun setBusinessName(v: String) { prefs.edit().putString(KEY_BUSINESS_NAME, v).apply() }

    fun getBusinessPhone(): String = prefs.getString(KEY_BUSINESS_PHONE, "") ?: ""
    fun setBusinessPhone(v: String) { prefs.edit().putString(KEY_BUSINESS_PHONE, v).apply() }

    fun getBusinessAddress(): String = prefs.getString(KEY_BUSINESS_ADDRESS, "") ?: ""
    fun setBusinessAddress(v: String) { prefs.edit().putString(KEY_BUSINESS_ADDRESS, v).apply() }
}
