package com.edwinpm.mdm.util

import android.content.Context
import android.os.Build
import android.provider.Settings
import android.util.Log
import com.edwinpm.mdm.service.MdmWatchdogService
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import com.google.firebase.messaging.FirebaseMessaging

object DeviceRepository {

    private const val TAG          = "DeviceRepository"
    private const val COL_DEVICES  = "devices"
    private const val COL_BUSINESS = "business"
    private const val COL_KEYS     = "keys"

    fun getAndroidId(context: Context): String =
        Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
            ?.takeIf { it.isNotBlank() } ?: "unknown"

    fun getOrCreateDeviceId(context: Context): String {
        val prefs = MdmPrefs(context)
        prefs.getDeviceId()?.let { if (it.isNotBlank()) return it }
        val id = getAndroidId(context)
        prefs.setDeviceId(id)
        return id
    }

    data class ActivationResult(
        val success: Boolean,
        val closeApp: Boolean = false,
        val error: String = "",
        val customerName: String = "",
        val customerPhone: String = "",
        val customerIdNumber: String = "",
        val loanTotal: Double = 0.0,
        val installmentValue: Double = 0.0,
        val paymentFrequency: String = "",
        val planDueDate: String = "",
        val planCurrency: String = "USD",
        val planPaid: Double = 0.0,
        val planBalance: Double = 0.0,
        val paymentStatus: String = "active",
        val businessName: String = "",
        val businessPhone: String = "",
        val businessAddress: String = ""
    )

    /**
     * Full provisioning verification flow:
     *
     *  1. Check [businessId] exists in the `business` collection.
     *  2. Check [activationKey] exists in the `keys` collection AND its `status` != "true".
     *     - Key missing OR status == "true"  →  closeApp = true.
     *  3. Query `devices` where field `contractNumber` == [contractNumber].
     *  4. Write [imei], [serialNumber], [androidId] to that device document.
     *  5. Mark the key as used (status = "true").
     *  6. Return all customer & credit data from the device document.
     */
    fun verifyAndActivate(
        context: Context,
        businessId: String,
        activationKey: String,
        contractNumber: String,
        imei: String,
        serialNumber: String,
        androidId: String,
        onResult: (ActivationResult) -> Unit
    ) {
        val db = db()

        // ── Step 1: Verify business ───────────────────────────────────────────
        db.collection(COL_BUSINESS)
            .document(businessId.trim())
            .get()
            .addOnSuccessListener { bizDoc ->
                if (!bizDoc.exists()) {
                    Log.w(TAG, "Business not found: $businessId")
                    onResult(ActivationResult(false, closeApp = true, error = "Business not found"))
                    return@addOnSuccessListener
                }

                val bizName    = bizDoc.getString("businessName")    ?: bizDoc.getString("name")    ?: ""
                val bizPhone   = bizDoc.getString("businessPhone")   ?: bizDoc.getString("phone")   ?: ""
                val bizAddress = bizDoc.getString("businessAddress") ?: bizDoc.getString("address") ?: ""

                Log.i(TAG, "Business verified: $businessId")

                // ── Step 2: Verify activation key ─────────────────────────────
                db.collection(COL_KEYS)
                    .document(activationKey.trim())
                    .get()
                    .addOnSuccessListener { keyDoc ->
                        if (!keyDoc.exists()) {
                            Log.w(TAG, "Activation key not found: $activationKey")
                            onResult(ActivationResult(false, closeApp = true, error = "Activation key not found"))
                            return@addOnSuccessListener
                        }

                        val keyStatus = keyDoc.getString("status") ?: ""
                        if (keyStatus == "true") {
                            Log.w(TAG, "Activation key already used or invalid: $activationKey")
                            onResult(ActivationResult(false, closeApp = true, error = "Activation key is no longer valid"))
                            return@addOnSuccessListener
                        }

                        Log.i(TAG, "Activation key valid: $activationKey (status=$keyStatus)")

                        // ── Step 3: Find device document by contractNumber field ───
                        db.collection(COL_DEVICES)
                            .whereEqualTo("contractNumber", contractNumber.trim())
                            .limit(1)
                            .get()
                            .addOnSuccessListener { querySnapshot ->
                                if (querySnapshot.isEmpty) {
                                    Log.w(TAG, "No device document found for contract: $contractNumber")
                                    onResult(ActivationResult(false, closeApp = true, error = "Contract not found"))
                                    return@addOnSuccessListener
                                }

                                val devDoc   = querySnapshot.documents[0]
                                val devDocId = devDoc.id
                                val data     = devDoc.data ?: emptyMap()

                                val customerName     = data.strVal("customerName") ?: data.strVal("ownerName") ?: ""
                                val customerPhone    = data.strVal("customerPhone") ?: data.strVal("ownerPhone") ?: ""
                                val customerIdNumber = data.strVal("customerIdNumber") ?: data.strVal("idNumber") ?: ""
                                val loanTotal        = data.dblVal("loanTotal") ?: data.dblVal("planTotal") ?: 0.0
                                val installmentValue = data.dblVal("installmentValue") ?: data.dblVal("installment") ?: 0.0
                                val paymentFrequency = data.strVal("paymentFrequency") ?: "monthly"
                                val planDueDate      = data.strVal("planDueDate") ?: data.strVal("dueDate") ?: ""
                                val planCurrency     = data.strVal("planCurrency") ?: data.strVal("currency") ?: "USD"
                                val planPaid         = data.dblVal("planPaid") ?: 0.0
                                val planBalance      = data.dblVal("planBalance") ?: (loanTotal - planPaid).coerceAtLeast(0.0)
                                val paymentStatus    = data.strVal("paymentStatus") ?: "active"

                                Log.i(TAG, "Device document found: $devDocId for contract $contractNumber")

                                // ── Step 4: Write IMEI / SN / Android ID ─────────────
                                val deviceUpdate = hashMapOf<String, Any>(
                                    "imei"          to imei,
                                    "imei1"         to imei,
                                    "serialNumber"  to serialNumber,
                                    "androidId"     to androidId,
                                    "activatedAt"   to FieldValue.serverTimestamp(),
                                    "lastSeen"      to FieldValue.serverTimestamp()
                                )

                                db.collection(COL_DEVICES)
                                    .document(devDocId)
                                    .set(deviceUpdate, SetOptions.merge())
                                    .addOnSuccessListener {
                                        Log.i(TAG, "IMEI/SN/AndroidID written to device doc $devDocId")

                                        // ── Step 5: Mark key as used ──────────────────
                                        db.collection(COL_KEYS)
                                            .document(activationKey.trim())
                                            .update("status", "true")
                                            .addOnSuccessListener {
                                                Log.i(TAG, "Activation key marked as used")
                                            }
                                            .addOnFailureListener { e ->
                                                Log.w(TAG, "Could not mark key as used: ${e.message}")
                                            }

                                        // Sync FCM token in background
                                        FirebaseMessaging.getInstance().token
                                            .addOnSuccessListener { token ->
                                                MdmPrefs(context).setFcmToken(token)
                                                db.collection(COL_DEVICES).document(devDocId)
                                                    .set(mapOf("fcmToken" to token), SetOptions.merge())
                                            }

                                        onResult(ActivationResult(
                                            success          = true,
                                            customerName     = customerName,
                                            customerPhone    = customerPhone,
                                            customerIdNumber = customerIdNumber,
                                            loanTotal        = loanTotal,
                                            installmentValue = installmentValue,
                                            paymentFrequency = paymentFrequency,
                                            planDueDate      = planDueDate,
                                            planCurrency     = planCurrency,
                                            planPaid         = planPaid,
                                            planBalance      = planBalance,
                                            paymentStatus    = paymentStatus,
                                            businessName     = bizName,
                                            businessPhone    = bizPhone,
                                            businessAddress  = bizAddress
                                        ))
                                    }
                                    .addOnFailureListener { e ->
                                        Log.e(TAG, "Device update failed: ${e.message}")
                                        onResult(ActivationResult(false, closeApp = true, error = "Device registration failed: ${e.message}"))
                                    }
                            }
                            .addOnFailureListener { e ->
                                Log.e(TAG, "Contract query failed: ${e.message}")
                                onResult(ActivationResult(false, closeApp = true, error = "Contract query failed: ${e.message}"))
                            }
                    }
                    .addOnFailureListener { e ->
                        Log.e(TAG, "Key lookup failed: ${e.message}")
                        onResult(ActivationResult(false, closeApp = true, error = "Key verification failed: ${e.message}"))
                    }
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Business lookup failed: ${e.message}")
                onResult(ActivationResult(false, closeApp = true, error = "Business verification failed: ${e.message}"))
            }
    }

    fun registerDevice(context: Context) {
        val prefs = MdmPrefs(context)
        val contractNumber = prefs.getContractNumber()
        if (contractNumber.isBlank()) return

        FirebaseMessaging.getInstance().token
            .addOnSuccessListener { token ->
                prefs.setFcmToken(token)
                db().collection(COL_DEVICES)
                    .whereEqualTo("contractNumber", contractNumber)
                    .limit(1)
                    .get()
                    .addOnSuccessListener { qs ->
                        if (qs.isEmpty) return@addOnSuccessListener
                        val docId = qs.documents[0].id
                        db().collection(COL_DEVICES).document(docId)
                            .set(
                                mapOf(
                                    "fcmToken" to token,
                                    "lastSeen" to FieldValue.serverTimestamp()
                                ),
                                SetOptions.merge()
                            )
                            .addOnSuccessListener { Log.i(TAG, "Device heartbeat/token updated") }
                    }
            }
    }

    fun startRealtimeListener(
        context: Context,
        onUpdate: (paymentStatus: String) -> Unit
    ): ListenerRegistration = startDeviceDocumentListener(context, false, onUpdate)

    fun startCommandListener(
        context: Context,
        onStatusChanged: (paymentStatus: String) -> Unit
    ): ListenerRegistration = startDeviceDocumentListener(context, true, onStatusChanged)

    private fun startDeviceDocumentListener(
        context: Context,
        processCommands: Boolean,
        onUpdate: (paymentStatus: String) -> Unit
    ): ListenerRegistration {
        val prefs = MdmPrefs(context)
        val contractNumber = prefs.getContractNumber()

        if (contractNumber.isBlank()) {
            return db().collection(COL_DEVICES).document("_none")
                .addSnapshotListener { _, _ -> }
        }

        return db().collection(COL_DEVICES)
            .whereEqualTo("contractNumber", contractNumber)
            .limit(1)
            .addSnapshotListener { snapshots, error ->
                if (error != null) {
                    Log.e(TAG, "Realtime listener error: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshots == null || snapshots.isEmpty) return@addSnapshotListener

                val snapshot = snapshots.documents[0]
                val data = snapshot.data ?: emptyMap()
                val status = applyDeviceData(data, prefs)
                Log.i(TAG, "Firestore snapshot received — status=$status")

                if (processCommands && handleRemoteCommand(context, data, "Firestore")) {
                    db().collection(COL_DEVICES).document(snapshot.id)
                        .update(
                            hashMapOf<String, Any>(
                                "pendingCmd"     to FieldValue.delete(),
                                "pendingCommand" to FieldValue.delete(),
                                "cmd"            to FieldValue.delete(),
                                "command"        to FieldValue.delete(),
                                "action"         to FieldValue.delete(),
                                "type"           to FieldValue.delete()
                            )
                        )
                        .addOnSuccessListener { Log.i(TAG, "Command cleared") }
                }

                onUpdate(status)
            }
    }

    fun fetchAndApplyServerState(
        context: Context,
        deviceId: String = getOrCreateDeviceId(context),
        onResult: ((paymentStatus: String) -> Unit)? = null
    ) {
        val prefs = MdmPrefs(context)
        val contractNumber = prefs.getContractNumber()

        if (contractNumber.isBlank()) {
            onResult?.invoke("active")
            return
        }

        db().collection(COL_DEVICES)
            .whereEqualTo("contractNumber", contractNumber)
            .limit(1)
            .get()
            .addOnSuccessListener { qs ->
                if (qs.isEmpty) { onResult?.invoke("active"); return@addOnSuccessListener }
                val data = qs.documents[0].data ?: emptyMap()
                val status = applyDeviceData(data, prefs)
                onResult?.invoke(status)
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "fetchAndApplyServerState failed: ${e.message}")
                onResult?.invoke(prefs.getPaymentStatus())
            }
    }

    fun syncToken(context: Context, token: String) {
        val prefs = MdmPrefs(context)
        prefs.setFcmToken(token)
        val contractNumber = prefs.getContractNumber()
        if (contractNumber.isBlank()) return
        db().collection(COL_DEVICES)
            .whereEqualTo("contractNumber", contractNumber)
            .limit(1)
            .get()
            .addOnSuccessListener { qs ->
                if (qs.isEmpty) return@addOnSuccessListener
                db().collection(COL_DEVICES).document(qs.documents[0].id)
                    .set(
                        mapOf("fcmToken" to token, "lastSeen" to FieldValue.serverTimestamp()),
                        SetOptions.merge()
                    )
                    .addOnSuccessListener { Log.i(TAG, "FCM token synced") }
            }
    }

    fun updateHeartbeat(context: Context) {
        val prefs = MdmPrefs(context)
        val contractNumber = prefs.getContractNumber()
        if (contractNumber.isBlank()) return
        db().collection(COL_DEVICES)
            .whereEqualTo("contractNumber", contractNumber)
            .limit(1)
            .get()
            .addOnSuccessListener { qs ->
                if (qs.isEmpty) return@addOnSuccessListener
                db().collection(COL_DEVICES).document(qs.documents[0].id)
                    .set(mapOf("lastSeen" to FieldValue.serverTimestamp()), SetOptions.merge())
                    .addOnSuccessListener { Log.i(TAG, "Heartbeat updated") }
            }
    }

    fun checkPaymentDueDate(context: Context) {
        val prefs = MdmPrefs(context)
        if (!prefs.isSetupDone()) return
        val dueDate = prefs.getPlanDueDate()
        if (dueDate.isBlank()) return

        ServerTimeHelper.fetchServerTime { serverTime ->
            if (serverTime == null) {
                Log.w(TAG, "Could not fetch server time — skipping due date check")
                return@fetchServerTime
            }
            if (ServerTimeHelper.isPaymentOverdue(dueDate, serverTime)) {
                Log.w(TAG, "Payment overdue — dueDate=$dueDate serverTime=$serverTime")
                if (!prefs.isLocked()) {
                    val installment = prefs.getInstallmentValue()
                    val overdueAmt  = if (installment > 0) installment else prefs.getPlanBalance()
                    prefs.setPlanOverdueAmount(overdueAmt)
                    prefs.setPaymentStatus("suspended")

                    val contractNumber = prefs.getContractNumber()
                    if (contractNumber.isNotBlank()) {
                        db().collection(COL_DEVICES)
                            .whereEqualTo("contractNumber", contractNumber)
                            .limit(1)
                            .get()
                            .addOnSuccessListener { qs ->
                                if (qs.isEmpty) return@addOnSuccessListener
                                db().collection(COL_DEVICES).document(qs.documents[0].id)
                                    .set(
                                        mapOf("paymentStatus" to "suspended", "planOverdue" to overdueAmt),
                                        SetOptions.merge()
                                    )
                            }
                    }

                    MdmWatchdogService.sendCommand(
                        context,
                        MdmWatchdogService.CMD_LOCK,
                        "Payment overdue — device suspended",
                        formatAmount(overdueAmt),
                        prefs.getPlanCurrency()
                    )
                }
            } else {
                Log.i(TAG, "Payment on time — dueDate=$dueDate serverTime=$serverTime")
            }
        }
    }

    fun handleRemoteCommand(
        context: Context,
        data: Map<String, Any?>,
        source: String
    ): Boolean {
        val prefs = MdmPrefs(context)
        val commandData = commandPayload(data)
        val command = normalizeCommand(
            commandData.cmdVal("cmd")
                ?: commandData.cmdVal("command")
                ?: commandData.cmdVal("action")
                ?: commandData.cmdVal("type")
        ) ?: return false

        val reason        = commandData.strVal("reason") ?: "Remote MDM command"
        val overdueAmount = commandData.strVal("overdueAmount") ?: commandData.strVal("planOverdue") ?: ""
        val currency      = commandData.strVal("currency") ?: prefs.getPlanCurrency()

        Log.i(TAG, "Executing $source command: $command")
        when (command) {
            "LOCK" -> {
                overdueAmount.toDoubleOrNull()?.let { prefs.setPlanOverdueAmount(it) }
                MdmWatchdogService.sendCommand(context, MdmWatchdogService.CMD_LOCK, reason, overdueAmount, currency)
            }
            "UNLOCK" -> {
                MdmWatchdogService.sendCommand(context, MdmWatchdogService.CMD_UNLOCK, reason)
                prefs.setPlanOverdueAmount(0.0)
            }
            "WIPE", "WIPE_DEVICE", "FACTORY_RESET", "RESET_PHONE", "RESET" ->
                MdmWatchdogService.sendCommand(context, MdmWatchdogService.CMD_WIPE, reason)
            "PING" -> updateHeartbeat(context)
            "UPDATE_STATUS" -> applyDeviceData(commandData, prefs)
            "UPDATE_APP", "INSTALL_UPDATE", "APP_UPDATE", "INSTALL_APK" -> {
                val apkUrl = commandData.strVal("apkUrl")
                    ?: commandData.strVal("apkURL")
                    ?: commandData.strVal("downloadUrl")
                    ?: commandData.strVal("url")
                if (apkUrl.isNullOrBlank()) {
                    Log.e(TAG, "$source update command missing apkUrl")
                    return false
                }
                AppUpdateInstaller.installFromUrl(context, apkUrl, commandData.longVal("versionCode"))
            }
            else -> {
                Log.w(TAG, "Unknown $source command: $command")
                return false
            }
        }
        return true
    }

    private fun applyDeviceData(data: Map<String, Any?>, prefs: MdmPrefs): String {
        val status = data.strVal("paymentStatus") ?: prefs.getPaymentStatus()
        prefs.setPaymentStatus(status)
        data.strVal("planName")?.let { prefs.setPlanName(it) }
        data.dblVal("planTotal")?.let { prefs.setPlanTotalAmount(it) }
        data.dblVal("loanTotal")?.let { prefs.setPlanTotalAmount(it) }
        data.dblVal("planPaid")?.let { prefs.setPlanPaidAmount(it) }
        data.dblVal("planBalance")?.let { prefs.setPlanBalance(it) }
        data.strVal("planDueDate")?.let { prefs.setPlanDueDate(it) }
        data.strVal("dueDate")?.let { prefs.setPlanDueDate(it) }
        data.dblVal("planOverdue")?.let { prefs.setPlanOverdueAmount(it) }
        data.strVal("planCurrency")?.let { prefs.setPlanCurrency(it) }
        data.strVal("currency")?.let { prefs.setPlanCurrency(it) }
        data.dblVal("installmentValue")?.let { prefs.setInstallmentValue(it) }
        data.strVal("paymentFrequency")?.let { prefs.setPaymentFrequency(it) }
          data.strVal("registrationDate")?.let { prefs.setRegistrationDate(it) }
          data.strVal("nextPaymentDate")?.let { prefs.setNextPaymentDate(it) }
          data.strVal("imei1")?.let { prefs.setDeviceImei1(it) }
          data.strVal("imei")?.let { v -> if (prefs.getDeviceImei().isBlank()) prefs.setDeviceImei(v) }
          data.strVal("serialNumber")?.let { prefs.setSerialNumber(it) }
          data.strVal("customerName")?.let { prefs.setOwnerName(it) }
        data.strVal("ownerName")?.let { prefs.setOwnerName(it) }
        data.strVal("customerPhone")?.let { prefs.setOwnerPhone(it) }
        data.strVal("ownerPhone")?.let { prefs.setOwnerPhone(it) }
        data.strVal("customerIdNumber")?.let { prefs.setOwnerIdNumber(it) }
        data.strVal("idNumber")?.let { prefs.setOwnerIdNumber(it) }
        return status
    }

    @Suppress("UNCHECKED_CAST")
    private fun commandPayload(data: Map<String, Any?>): Map<String, Any?> {
        (data["pendingCmd"] as? Map<String, Any?>)?.let { return it }
        (data["pendingCommand"] as? Map<String, Any?>)?.let { return it }
        (data["command"] as? Map<String, Any?>)?.let { return it }
        (data["cmd"] as? Map<String, Any?>)?.let { return it }
        return data
    }

    private fun normalizeCommand(raw: String?): String? =
        raw?.trim()?.takeIf { it.isNotBlank() }
            ?.replace("-", "_")?.replace(" ", "_")?.uppercase()

    private fun Map<String, Any?>.cmdVal(key: String): String? =
        when (val v = this[key]) { is String -> v; is Number -> v.toString(); else -> null }

    private fun Map<String, Any?>.strVal(key: String): String? =
        this[key]?.toString()?.takeIf { it.isNotBlank() }

    private fun Map<String, Any?>.dblVal(key: String): Double? =
        when (val v = this[key]) { is Number -> v.toDouble(); is String -> v.toDoubleOrNull(); else -> null }

    private fun Map<String, Any?>.longVal(key: String): Long? =
        when (val v = this[key]) { is Number -> v.toLong(); is String -> v.toLongOrNull(); else -> null }

    private fun formatAmount(v: Double): String =
        if (v == 0.0) "" else if (v == kotlin.math.floor(v)) "%.0f".format(v) else "%.2f".format(v)

    /**
       * Fetches the current server time and computes the next payment date from the
       * device's registration date and payment frequency. Saves both to local prefs
       * and writes nextPaymentDate to the Firestore device document.
       *
       * This is called once on first activation and then again on each app resume
       * if the next payment date is not yet stored locally.
       */
      fun computeAndSaveNextPaymentDate(context: Context) {
          val prefs = MdmPrefs(context)
          val freq = prefs.getPaymentFrequency().ifBlank { "monthly" }

          ServerTimeHelper.fetchServerTime { serverDate ->
              if (serverDate == null) {
                  Log.w(TAG, "computeAndSaveNextPaymentDate: server time unavailable")
                  return@fetchServerTime
              }

              val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
              sdf.timeZone = java.util.TimeZone.getTimeZone("UTC")

              // Use stored registration date; if absent, use today as registration date
              val regDate = prefs.getRegistrationDate().ifBlank { sdf.format(serverDate) }
              prefs.setRegistrationDate(regDate)

              val nextDate = ServerTimeHelper.calculateNextPaymentDate(
                  registrationDate = regDate,
                  paymentFrequency = freq,
                  serverTime       = serverDate
              )
              prefs.setNextPaymentDate(nextDate)

              Log.i(TAG, "computeAndSaveNextPaymentDate: regDate=$regDate freq=$freq nextDate=$nextDate")

              val contractNumber = prefs.getContractNumber()
              if (contractNumber.isBlank()) return@fetchServerTime

              db().collection(COL_DEVICES)
                  .whereEqualTo("contractNumber", contractNumber)
                  .limit(1)
                  .get()
                  .addOnSuccessListener { qs ->
                      if (qs.isEmpty) return@addOnSuccessListener
                      db().collection(COL_DEVICES).document(qs.documents[0].id)
                          .set(
                              mapOf(
                                  "registrationDate" to regDate,
                                  "nextPaymentDate"  to nextDate
                              ),
                              SetOptions.merge()
                          )
                          .addOnSuccessListener { Log.i(TAG, "nextPaymentDate written to Firestore: $nextDate") }
                          .addOnFailureListener { e -> Log.e(TAG, "nextPaymentDate write failed: ${e.message}") }
                  }
                  .addOnFailureListener { e -> Log.e(TAG, "nextPaymentDate contract query failed: ${e.message}") }
          }
      }

      /**
       * Simulates a payment:
       *  - Subtracts [installmentAmount] from planBalance and adds it to planPaid in Firestore.
       *  - Updates nextPaymentDate by advancing from the current next payment date by one cycle.
       *  - If balance reaches zero, sets paymentStatus to "paid".
       *
       * This writes directly to Firestore so that admins can see the updated values.
       */
      fun simulatePayment(
          context: Context,
          installmentAmount: Double,
          nextPaymentDate: String,
          paymentFrequency: String,
          serverTime: java.util.Date,
          onResult: (success: Boolean, newBalance: Double, newNextPaymentDate: String) -> Unit
      ) {
          val prefs = MdmPrefs(context)
          val contractNumber = prefs.getContractNumber()
          if (contractNumber.isBlank()) {
              onResult(false, prefs.getPlanBalance(), nextPaymentDate)
              return
          }

          val currentBalance = prefs.getPlanBalance()
          val currentPaid    = prefs.getPlanPaidAmount()
          val payment        = installmentAmount.coerceAtMost(currentBalance).coerceAtLeast(0.0)
          val newBalance     = (currentBalance - payment).coerceAtLeast(0.0)
          val newPaid        = currentPaid + payment
          val newStatus      = if (newBalance <= 0.0) "paid" else prefs.getPaymentStatus().let {
              if (it == "suspended" || it == "overdue") "active" else it
          }
          val newNextPaymentDate = ServerTimeHelper.advanceNextPaymentDateAfterPayment(
              currentNextPaymentDate = nextPaymentDate,
              paymentFrequency       = paymentFrequency,
              serverTime             = serverTime
          )

          db().collection(COL_DEVICES)
              .whereEqualTo("contractNumber", contractNumber)
              .limit(1)
              .get()
              .addOnSuccessListener { qs ->
                  if (qs.isEmpty) {
                      onResult(false, currentBalance, nextPaymentDate)
                      return@addOnSuccessListener
                  }
                  val docId = qs.documents[0].id
                  val updates = hashMapOf<String, Any>(
                      "planBalance"     to newBalance,
                      "planPaid"        to newPaid,
                      "paymentStatus"   to newStatus,
                      "nextPaymentDate" to newNextPaymentDate,
                      "lastPaymentAt"   to FieldValue.serverTimestamp()
                  )
                  if (newBalance <= 0.0) {
                      updates["planOverdue"] = 0.0
                  }
                  db().collection(COL_DEVICES).document(docId)
                      .set(updates, SetOptions.merge())
                      .addOnSuccessListener {
                          prefs.setPlanBalance(newBalance)
                          prefs.setPlanPaidAmount(newPaid)
                          prefs.setPaymentStatus(newStatus)
                          prefs.setNextPaymentDate(newNextPaymentDate)
                          if (newBalance <= 0.0) prefs.setPlanOverdueAmount(0.0)
                          Log.i(TAG, "Payment simulated: payment=$payment newBalance=$newBalance nextDate=$newNextPaymentDate")
                          onResult(true, newBalance, newNextPaymentDate)
                      }
                      .addOnFailureListener { e ->
                          Log.e(TAG, "simulatePayment write failed: ${e.message}")
                          onResult(false, currentBalance, nextPaymentDate)
                      }
              }
              .addOnFailureListener { e ->
                  Log.e(TAG, "simulatePayment query failed: ${e.message}")
                  onResult(false, prefs.getPlanBalance(), nextPaymentDate)
              }
      }

      private fun db(): FirebaseFirestore = FirebaseFirestore.getInstance()
  }
