package com.edwinpm.mdm.util

import android.content.Context
import android.os.Build
import android.provider.Settings
import android.util.Log
import com.edwinpm.mdm.service.MdmWatchdogService
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import com.google.firebase.messaging.FirebaseMessaging

object DeviceRepository {

    private const val TAG          = "DeviceRepository"
    private const val COL_DEVICES  = "devices"
    private const val COL_BUSINESS = "business"

    // ─── Device ID ───────────────────────────────────────────────────────────────

    fun getOrCreateDeviceId(context: Context): String {
        val prefs = MdmPrefs(context)
        prefs.getDeviceId()?.let { if (it.isNotBlank()) return it }

        val androidId = Settings.Secure.getString(
            context.contentResolver, Settings.Secure.ANDROID_ID
        )?.takeIf { it.isNotBlank() } ?: "unknown"

        val model    = Build.MODEL.replace(" ", "_").replace(Regex("[^a-zA-Z0-9_\\-]"), "")
        val deviceId = "${androidId}_${model}".take(64)

        prefs.setDeviceId(deviceId)
        return deviceId
    }

    // ─── Business lookup ─────────────────────────────────────────────────────────

    fun verifyBusiness(
        businessId: String,
        onResult: (found: Boolean, name: String, phone: String, address: String) -> Unit
    ) {
        db().collection(COL_BUSINESS)
            .document(businessId.trim())
            .get()
            .addOnSuccessListener { doc ->
                if (doc.exists()) {
                    val name    = doc.getString("businessName")    ?: doc.getString("name")    ?: ""
                    val phone   = doc.getString("businessPhone")   ?: doc.getString("phone")   ?: ""
                    val address = doc.getString("businessAddress") ?: doc.getString("address") ?: ""
                    Log.i(TAG, "Business found: $businessId → $name")
                    onResult(true, name, phone, address)
                } else {
                    Log.w(TAG, "Business NOT found: $businessId")
                    onResult(false, "", "", "")
                }
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Business lookup failed: ${e.message}")
                onResult(false, "", "", "")
            }
    }

    // ─── Device registration ─────────────────────────────────────────────────────

    /**
     * Writes (or updates) the full device record in Firestore.
     * Safe to call on every launch — uses merge so it never overwrites
     * fields managed server-side (paymentStatus, planBalance, pendingCmd, etc.).
     */
    fun registerDevice(context: Context) {
        val deviceId = getOrCreateDeviceId(context)
        val prefs    = MdmPrefs(context)

        FirebaseMessaging.getInstance().token
            .addOnSuccessListener { token ->
                prefs.setFcmToken(token)

                val data = hashMapOf<String, Any>(
                    "deviceId"       to deviceId,
                    "fcmToken"       to token,
                    "deviceModel"    to "${Build.MANUFACTURER} ${Build.MODEL}",
                    "androidVersion" to Build.VERSION.RELEASE,
                    "sdkVersion"     to Build.VERSION.SDK_INT,
                    "imei"           to prefs.getDeviceImei(),
                    "contractId"     to prefs.getContractId(),
                    "ownerName"      to prefs.getOwnerName(),
                    "ownerPhone"     to prefs.getOwnerPhone(),
                    "businessId"     to prefs.getBusinessId(),
                    "businessName"   to prefs.getBusinessName(),
                    "paymentStatus"  to prefs.getPaymentStatus(),
                    "planName"       to prefs.getPlanName(),
                    "planTotal"      to prefs.getPlanTotalAmount(),
                    "planPaid"       to prefs.getPlanPaidAmount(),
                    "planBalance"    to prefs.getPlanBalance(),
                    "planDueDate"    to prefs.getPlanDueDate(),
                    "planOverdue"    to prefs.getPlanOverdueAmount(),
                    "planCurrency"   to prefs.getPlanCurrency(),
                    "registeredAt"   to FieldValue.serverTimestamp(),
                    "lastSeen"       to FieldValue.serverTimestamp()
                )

                db().collection(COL_DEVICES)
                    .document(deviceId)
                    .set(data, SetOptions.merge())
                    .addOnSuccessListener {
                        Log.i(TAG, "Device registered: $deviceId")
                    }
                    .addOnFailureListener { e ->
                        Log.e(TAG, "Registration failed: ${e.message}")
                    }
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "FCM token fetch failed: ${e.message}")
            }
    }

    // ─── Real-time listener ──────────────────────────────────────────────────────

    /**
     * Attaches a Firestore snapshot listener to this device's document.
     *
     * Every time the document changes on the server (payment status update,
     * plan changes, or a pendingCmd set by the admin), this fires immediately.
     *
     * pendingCmd structure in Firestore:
     *   {
     *     "pendingCmd": {
     *       "cmd": "lock",          ← lock | unlock | wipe | ping
     *       "reason": "Overdue",    ← optional
     *       "overdueAmount": "350", ← optional, used with lock
     *       "currency": "USD"       ← optional
     *     }
     *   }
     *
     * After processing a pendingCmd the device deletes the field so the
     * command is not executed again after a reconnect.
     *
     * @param onUpdate Called on the main thread whenever Firestore data changes.
     *   Receives the latest payment status so the caller can update UI state.
     * @return A [ListenerRegistration] — call .remove() in onPause/onDestroy.
     */
    fun startRealtimeListener(
        context: Context,
        onUpdate: (paymentStatus: String) -> Unit
    ): ListenerRegistration = startDeviceDocumentListener(context, false, onUpdate)

    fun startCommandListener(
        context: Context,
        onStatusChanged: (paymentStatus: String) -> Unit
    ): ListenerRegistration = startDeviceDocumentListener(context, true, onStatusChanged)

    private fun startDeviceDocumentListener(
        context: Context,
        processCommands: Boolean,
        onUpdate: (paymentStatus: String) -> Unit
    ): ListenerRegistration {
        val deviceId = getOrCreateDeviceId(context)
        val prefs    = MdmPrefs(context)

        return db().collection(COL_DEVICES)
            .document(deviceId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(TAG, "Realtime listener error: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot == null || !snapshot.exists()) return@addSnapshotListener

                val data = snapshot.data ?: emptyMap()
                val status = applyDeviceData(data, prefs)
                Log.i(TAG, "Firestore snapshot received — status=$status")

                if (processCommands && handleRemoteCommand(context, data, "Firestore")) {
                    db().collection(COL_DEVICES).document(deviceId)
                        .update(
                            hashMapOf<String, Any>(
                                "pendingCmd" to FieldValue.delete(),
                                "pendingCommand" to FieldValue.delete(),
                                "cmd" to FieldValue.delete(),
                                "command" to FieldValue.delete(),
                                "action" to FieldValue.delete(),
                                "type" to FieldValue.delete()
                            )
                        )
                        .addOnSuccessListener { Log.i(TAG, "Firestore command cleared") }
                        .addOnFailureListener { e -> Log.e(TAG, "Firestore command clear failed: ${e.message}") }
                }

                onUpdate(status)
            }
    }

    // ─── One-shot server read ────────────────────────────────────────────────────

    fun fetchAndApplyServerState(
        context: Context,
        deviceId: String = getOrCreateDeviceId(context),
        onResult: ((paymentStatus: String) -> Unit)? = null
    ) {
        db().collection(COL_DEVICES)
            .document(deviceId)
            .get()
            .addOnSuccessListener { doc ->
                if (!doc.exists()) { onResult?.invoke("active"); return@addOnSuccessListener }
                val prefs = MdmPrefs(context)
                val data = doc.data ?: emptyMap()
                val status = applyDeviceData(data, prefs)
                onResult?.invoke(status)
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "fetchAndApplyServerState failed: ${e.message}")
                onResult?.invoke(MdmPrefs(context).getPaymentStatus())
            }
    }

    // ─── Token sync & heartbeat ──────────────────────────────────────────────────

    fun syncToken(context: Context, token: String) {
        val deviceId = getOrCreateDeviceId(context)
        MdmPrefs(context).setFcmToken(token)
        db().collection(COL_DEVICES).document(deviceId)
            .set(
                mapOf("fcmToken" to token, "lastSeen" to FieldValue.serverTimestamp()),
                SetOptions.merge()
            )
            .addOnSuccessListener { Log.i(TAG, "FCM token synced") }
            .addOnFailureListener { e -> Log.e(TAG, "Token sync failed: ${e.message}") }
    }

    fun updateHeartbeat(context: Context) {
        val deviceId = getOrCreateDeviceId(context)
        db().collection(COL_DEVICES).document(deviceId)
            .set(mapOf("lastSeen" to FieldValue.serverTimestamp()), SetOptions.merge())
            .addOnSuccessListener { Log.i(TAG, "Heartbeat updated") }
            .addOnFailureListener { e -> Log.e(TAG, "Heartbeat failed: ${e.message}") }
    }

    fun handleRemoteCommand(
        context: Context,
        data: Map<String, Any?>,
        source: String
    ): Boolean {
        val prefs = MdmPrefs(context)
        val commandData = commandPayload(data)
        val command = normalizeCommand(
            commandData.commandValue("cmd")
                ?: commandData.commandValue("command")
                ?: commandData.commandValue("action")
                ?: commandData.commandValue("type")
        )
            ?: return false
        val reason = commandData.stringValue("reason") ?: "Remote MDM command"
        val overdueAmount = commandData.stringValue("overdueAmount")
            ?: commandData.stringValue("planOverdue")
            ?: ""
        val currency = commandData.stringValue("currency") ?: prefs.getPlanCurrency()

        Log.i(TAG, "Executing $source command: $command")
        when (command) {
            "LOCK" -> {
                overdueAmount.toDoubleOrNull()?.let { prefs.setPlanOverdueAmount(it) }
                MdmWatchdogService.sendCommand(
                    context,
                    MdmWatchdogService.CMD_LOCK,
                    reason,
                    overdueAmount,
                    currency
                )
            }
            "UNLOCK" -> {
                MdmWatchdogService.sendCommand(context, MdmWatchdogService.CMD_UNLOCK, reason)
                prefs.setPlanOverdueAmount(0.0)
            }
            "WIPE", "WIPE_DEVICE", "FACTORY_RESET", "RESET_PHONE", "RESET" -> {
                MdmWatchdogService.sendCommand(context, MdmWatchdogService.CMD_WIPE, reason)
            }
            "PING" -> updateHeartbeat(context)
            "UPDATE_STATUS" -> {
                applyDeviceData(commandData, prefs)
            }
            "UPDATE_APP", "INSTALL_UPDATE", "APP_UPDATE", "INSTALL_APK" -> {
                val apkUrl = commandData.stringValue("apkUrl")
                    ?: commandData.stringValue("apkURL")
                    ?: commandData.stringValue("downloadUrl")
                    ?: commandData.stringValue("url")
                if (apkUrl.isNullOrBlank()) {
                    Log.e(TAG, "$source update command missing apkUrl/downloadUrl/url")
                    return false
                }
                AppUpdateInstaller.installFromUrl(context, apkUrl, commandData.longValue("versionCode"))
            }
            else -> {
                Log.w(TAG, "Unknown $source command: $command")
                return false
            }
        }
        return true
    }

    private fun applyDeviceData(data: Map<String, Any?>, prefs: MdmPrefs): String {
        val status = data.stringValue("paymentStatus") ?: prefs.getPaymentStatus()
        prefs.setPaymentStatus(status)
        data.stringValue("planName")?.let { prefs.setPlanName(it) }
        data.doubleValue("planTotal")?.let { prefs.setPlanTotalAmount(it) }
        data.doubleValue("planPaid")?.let { prefs.setPlanPaidAmount(it) }
        data.doubleValue("planBalance")?.let { prefs.setPlanBalance(it) }
        data.stringValue("planDueDate")?.let { prefs.setPlanDueDate(it) }
        data.doubleValue("planOverdue")?.let { prefs.setPlanOverdueAmount(it) }
        data.stringValue("planCurrency")?.let { prefs.setPlanCurrency(it) }
        return status
    }

    @Suppress("UNCHECKED_CAST")
    private fun commandPayload(data: Map<String, Any?>): Map<String, Any?> {
        (data["pendingCmd"] as? Map<String, Any?>)?.let { return it }
        (data["pendingCommand"] as? Map<String, Any?>)?.let { return it }
        (data["command"] as? Map<String, Any?>)?.let { return it }
        (data["cmd"] as? Map<String, Any?>)?.let { return it }
        return data
    }

    private fun normalizeCommand(raw: String?): String? =
        raw?.trim()
            ?.takeIf { it.isNotBlank() }
            ?.replace("-", "_")
            ?.replace(" ", "_")
            ?.uppercase()

    private fun Map<String, Any?>.commandValue(key: String): String? =
        when (val value = this[key]) {
            is String -> value
            is Number -> value.toString()
            else -> null
        }

    private fun Map<String, Any?>.stringValue(key: String): String? =
        this[key]?.toString()?.takeIf { it.isNotBlank() }

    private fun Map<String, Any?>.doubleValue(key: String): Double? =
        when (val value = this[key]) {
            is Number -> value.toDouble()
            is String -> value.toDoubleOrNull()
            else -> null
        }

    private fun Map<String, Any?>.longValue(key: String): Long? =
        when (val value = this[key]) {
            is Number -> value.toLong()
            is String -> value.toLongOrNull()
            else -> null
        }

    private fun db(): FirebaseFirestore = FirebaseFirestore.getInstance()
}
