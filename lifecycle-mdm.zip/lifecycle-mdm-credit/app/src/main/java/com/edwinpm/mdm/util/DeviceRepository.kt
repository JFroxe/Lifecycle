package com.edwinpm.mdm.util

import android.content.Context
import android.os.Build
import android.provider.Settings
import android.util.Log
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.messaging.FirebaseMessaging

object DeviceRepository {

    private const val TAG              = "DeviceRepository"
    private const val COL_DEVICES      = "devices"
    private const val COL_BUSINESS     = "business"

    // ─── Device ID ──────────────────────────────────────────────────────────────

    fun getOrCreateDeviceId(context: Context): String {
        val prefs = MdmPrefs(context)
        prefs.getDeviceId()?.let { if (it.isNotBlank()) return it }

        val androidId = Settings.Secure.getString(
            context.contentResolver, Settings.Secure.ANDROID_ID
        )?.takeIf { it.isNotBlank() } ?: "unknown"

        val model = Build.MODEL.replace(" ", "_").replace(Regex("[^a-zA-Z0-9_\\-]"), "")
        val deviceId = "${androidId}_${model}".take(64)

        prefs.setDeviceId(deviceId)
        return deviceId
    }

    // ─── Business lookup ─────────────────────────────────────────────────────────

    /**
     * Looks up a business document in the "business" Firestore collection by its ID.
     * onResult is called with (found: Boolean, name: String, phone: String, address: String).
     */
    fun verifyBusiness(
        businessId: String,
        onResult: (found: Boolean, name: String, phone: String, address: String) -> Unit
    ) {
        db().collection(COL_BUSINESS)
            .document(businessId.trim())
            .get()
            .addOnSuccessListener { doc ->
                if (doc.exists()) {
                    val name    = doc.getString("businessName")    ?: doc.getString("name")    ?: ""
                    val phone   = doc.getString("businessPhone")   ?: doc.getString("phone")   ?: ""
                    val address = doc.getString("businessAddress") ?: doc.getString("address") ?: ""
                    Log.i(TAG, "Business found: $businessId → $name")
                    onResult(true, name, phone, address)
                } else {
                    Log.w(TAG, "Business NOT found: $businessId")
                    onResult(false, "", "", "")
                }
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Business lookup failed: ${e.message}")
                onResult(false, "", "", "")
            }
    }

    // ─── Device registration ─────────────────────────────────────────────────────

    fun registerDevice(context: Context) {
        val deviceId = getOrCreateDeviceId(context)
        val prefs    = MdmPrefs(context)

        FirebaseMessaging.getInstance().token
            .addOnSuccessListener { token ->
                prefs.setFcmToken(token)

                val data = hashMapOf<String, Any>(
                    "deviceId"        to deviceId,
                    "fcmToken"        to token,
                    "deviceModel"     to "${Build.MANUFACTURER} ${Build.MODEL}",
                    "androidVersion"  to Build.VERSION.RELEASE,
                    "sdkVersion"      to Build.VERSION.SDK_INT,
                    "imei"            to prefs.getDeviceImei(),
                    "contractId"      to prefs.getContractId(),
                    "businessId"      to prefs.getBusinessId(),
                    "businessName"    to prefs.getBusinessName(),
                    "paymentStatus"   to prefs.getPaymentStatus(),
                    "planName"        to prefs.getPlanName(),
                    "planTotal"       to prefs.getPlanTotalAmount(),
                    "planPaid"        to prefs.getPlanPaidAmount(),
                    "planBalance"     to prefs.getPlanBalance(),
                    "planDueDate"     to prefs.getPlanDueDate(),
                    "planOverdue"     to prefs.getPlanOverdueAmount(),
                    "planCurrency"    to prefs.getPlanCurrency(),
                    "ownerName"       to prefs.getOwnerName(),
                    "ownerPhone"      to prefs.getOwnerPhone(),
                    "registeredAt"    to FieldValue.serverTimestamp(),
                    "lastSeen"        to FieldValue.serverTimestamp()
                )

                db().collection(COL_DEVICES)
                    .document(deviceId)
                    .set(data, SetOptions.merge())
                    .addOnSuccessListener {
                        Log.i(TAG, "Device registered in Firestore: $deviceId")
                        fetchAndApplyServerState(context, deviceId)
                    }
                    .addOnFailureListener { e ->
                        Log.e(TAG, "Failed to register device: ${e.message}")
                    }
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Failed to get FCM token: ${e.message}")
                fetchAndApplyServerState(context, deviceId)
            }
    }

    fun fetchAndApplyServerState(
        context: Context,
        deviceId: String = getOrCreateDeviceId(context),
        onResult: ((paymentStatus: String) -> Unit)? = null
    ) {
        db().collection(COL_DEVICES)
            .document(deviceId)
            .get()
            .addOnSuccessListener { doc ->
                if (!doc.exists()) { onResult?.invoke("active"); return@addOnSuccessListener }
                val prefs = MdmPrefs(context)
                val status = doc.getString("paymentStatus") ?: "active"
                prefs.setPaymentStatus(status)
                doc.getString("planName")?.let        { prefs.setPlanName(it) }
                doc.getDouble("planTotal")?.let        { prefs.setPlanTotalAmount(it) }
                doc.getDouble("planPaid")?.let         { prefs.setPlanPaidAmount(it) }
                doc.getDouble("planBalance")?.let      { prefs.setPlanBalance(it) }
                doc.getString("planDueDate")?.let      { prefs.setPlanDueDate(it) }
                doc.getDouble("planOverdue")?.let      { prefs.setPlanOverdueAmount(it) }
                doc.getString("planCurrency")?.let     { prefs.setPlanCurrency(it) }
                onResult?.invoke(status)
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "fetchAndApplyServerState failed: ${e.message}")
                onResult?.invoke(MdmPrefs(context).getPaymentStatus())
            }
    }

    fun syncToken(context: Context, token: String) {
        val deviceId = getOrCreateDeviceId(context)
        MdmPrefs(context).setFcmToken(token)
        db().collection(COL_DEVICES).document(deviceId)
            .set(mapOf("fcmToken" to token, "lastSeen" to FieldValue.serverTimestamp()), SetOptions.merge())
            .addOnSuccessListener { Log.i(TAG, "FCM token synced") }
            .addOnFailureListener { e -> Log.e(TAG, "Token sync failed: ${e.message}") }
    }

    fun updateHeartbeat(context: Context) {
        val deviceId = getOrCreateDeviceId(context)
        db().collection(COL_DEVICES).document(deviceId)
            .set(mapOf("lastSeen" to FieldValue.serverTimestamp()), SetOptions.merge())
            .addOnSuccessListener { Log.i(TAG, "Heartbeat updated") }
            .addOnFailureListener { e -> Log.e(TAG, "Heartbeat failed: ${e.message}") }
    }

    private fun db(): FirebaseFirestore = FirebaseFirestore.getInstance()
}
