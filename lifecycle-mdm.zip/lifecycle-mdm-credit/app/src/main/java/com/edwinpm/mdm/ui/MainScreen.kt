package com.edwinpm.mdm.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.floor

/**
 * MainScreen — credit dashboard shown after device registration is complete.
 *
 * All values are passed as individual parameters (not MdmPrefs) so that
 * Compose re-renders immediately whenever the Firestore listener fires.
 *
 * Business ID is intentionally NOT displayed — it is private information
 * used only for internal lookup.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    paymentStatus: String,
    currency: String,
    balance: Double,
    paid: Double,
    total: Double,
    overdue: Double,
    dueDate: String,
    planName: String,
    ownerName: String,
    ownerPhone: String,
    contractId: String,
    imei: String,
    businessName: String,
    businessPhone: String,
    businessAddr: String,
    onPay: () -> Unit
) {
    val statusColor = when (paymentStatus.lowercase()) {
        "active"    -> Color(0xFF22C55E)
        "suspended" -> Color(0xFFFBBF24)
        "revoked"   -> Color(0xFFEF4444)
        else        -> Color(0xFF6B7280)
    }

    val progress = if (total > 0) (paid / total).toFloat().coerceIn(0f, 1f) else 0f

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Lifecycle MDM", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF0F1923))
            )
        },
        containerColor = Color(0xFF0D1117)
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {

            // ── Business / Contract Card ───────────────────────────────────────
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1B2D)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .background(Color(0xFF1E3A5F), RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                businessName.take(1).uppercase(),
                                color = Color(0xFF60A5FA),
                                fontWeight = FontWeight.Bold,
                                fontSize = 22.sp
                            )
                        }
                        Column {
                            Text(
                                businessName,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }
                    }

                    HorizontalDivider(color = Color(0xFF1E2A3A))

                    if (businessPhone.isNotBlank()) InfoLine("Phone",     businessPhone)
                    if (businessAddr.isNotBlank())  InfoLine("Address",   businessAddr)
                    if (contractId.isNotBlank())    InfoLine("Contract",  contractId)
                    if (imei.isNotBlank())          InfoLine("IMEI",      imei)
                    if (ownerName.isNotBlank())     InfoLine("Customer",  ownerName)
                    if (ownerPhone.isNotBlank())    InfoLine("Phone",     ownerPhone)
                }
            }

            // ── Payment Status Banner ─────────────────────────────────────────
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.horizontalGradient(
                            listOf(statusColor.copy(alpha = 0.12f), Color(0xFF0D1117))
                        ),
                        RoundedCornerShape(14.dp)
                    )
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(statusColor, RoundedCornerShape(50))
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "Payment Status: ",
                        color = Color(0xFF9CA3AF),
                        fontSize = 14.sp,
                        modifier = Modifier.weight(1f)
                    )
                    Box(
                        modifier = Modifier
                            .background(statusColor.copy(alpha = 0.15f), RoundedCornerShape(20.dp))
                            .padding(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Text(
                            paymentStatus.uppercase(),
                            color = statusColor,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            // ── Credit Plan Card ──────────────────────────────────────────────
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF161B22)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "Credit Plan",
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.sp,
                            modifier = Modifier.weight(1f)
                        )
                        if (planName.isNotBlank())
                            Text(planName, color = Color(0xFF4B5563), fontSize = 12.sp)
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Paid", color = Color(0xFF6B7280), fontSize = 12.sp)
                            Text(
                                "$currency ${fmtAmt(paid)} / ${fmtAmt(total)}",
                                color = Color(0xFF9CA3AF),
                                fontSize = 12.sp
                            )
                        }
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier  = Modifier.fillMaxWidth().height(8.dp),
                            color     = Color(0xFF22C55E),
                            trackColor = Color(0xFF1E2A3A)
                        )
                    }

                    HorizontalDivider(color = Color(0xFF1E2A3A))

                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        AmountChip(
                            "Remaining Balance",
                            "$currency ${fmtAmt(balance)}",
                            if (balance > 0) Color(0xFF3B82F6) else Color(0xFF22C55E),
                            Modifier.weight(1f)
                        )
                        AmountChip(
                            "Next Due Date",
                            dueDate.ifBlank { "—" },
                            Color(0xFF9CA3AF),
                            Modifier.weight(1f)
                        )
                    }

                    if (overdue > 0) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF2A0A0A), RoundedCornerShape(10.dp))
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Overdue Amount", color = Color(0xFF9CA3AF), fontSize = 12.sp)
                                Spacer(Modifier.height(2.dp))
                                Text(
                                    "$currency ${fmtAmt(overdue)}",
                                    color = Color(0xFFEF4444),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 24.sp
                                )
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(4.dp))

            // ── Pay Button ────────────────────────────────────────────────────
            Button(
                onClick  = onPay,
                modifier = Modifier.fillMaxWidth().height(56.dp),
                colors   = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                shape    = RoundedCornerShape(14.dp)
            ) {
                Text("Make a Payment", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }

            Spacer(Modifier.height(16.dp))
        }
    }
}

// ── Reusable composables ──────────────────────────────────────────────────────

@Composable
private fun InfoLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(
            label, color = Color(0xFF6B7280), fontSize = 13.sp,
            modifier = Modifier.weight(1f)
        )
        Text(value, color = Color(0xFFD1D5DB), fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun AmountChip(
    label: String, value: String, valueColor: Color, modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .background(Color(0xFF0D1117), RoundedCornerShape(10.dp))
            .padding(horizontal = 10.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(label, color = Color(0xFF6B7280), fontSize = 11.sp)
        Spacer(Modifier.height(3.dp))
        Text(value, color = valueColor, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

private fun fmtAmt(v: Double): String =
    if (v == floor(v)) "%.0f".format(v) else "%.2f".format(v)
