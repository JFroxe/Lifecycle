package com.edwinpm.mdm.ui

import android.Manifest
import android.content.pm.PackageManager
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import org.json.JSONObject
import java.util.concurrent.Executors

private const val TAG = "QrScannerScreen"

/**
 * Data extracted from the provisioning QR code.
 */
data class ProvisioningQrData(
    val businessId: String,
    val activationKey: String,
    val contractNumber: String
)

/**
 * Full-screen QR code scanner shown on first launch (before setup is done).
 * The user points the camera at the provisioning QR code; once decoded the
 * [onScanned] callback is invoked with the three required IDs.
 *
 * Supported QR payload formats:
 *  - JSON: {"businessId":"…","activationKey":"…","contractNumber":"…"}
 *  - Pipe-delimited: "<businessId>|<activationKey>|<contractNumber>"
 */
@Composable
fun QrScannerScreen(
    onScanned: (ProvisioningQrData) -> Unit
) {
    val context       = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED
        )
    }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var scanDone     by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> hasCameraPermission = granted }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0D1117)),
        contentAlignment = Alignment.Center
    ) {
        if (!hasCameraPermission) {
            NoCameraPermissionContent(
                onRequest = { permissionLauncher.launch(Manifest.permission.CAMERA) }
            )
            return@Box
        }

        val cameraExecutor = remember { Executors.newSingleThreadExecutor() }
        val scanner        = remember { BarcodeScanning.getClient() }

        AndroidView(
            factory = { ctx ->
                val previewView = PreviewView(ctx)
                val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                cameraProviderFuture.addListener({
                    val cameraProvider = cameraProviderFuture.get()

                    val preview = Preview.Builder().build().also {
                        it.setSurfaceProvider(previewView.surfaceProvider)
                    }

                    val imageAnalysis = ImageAnalysis.Builder()
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build()

                    imageAnalysis.setAnalyzer(cameraExecutor) { imageProxy ->
                        if (scanDone) {
                            imageProxy.close()
                            return@setAnalyzer
                        }

                        @androidx.camera.core.ExperimentalGetImage
                        val mediaImage = imageProxy.image
                        if (mediaImage != null) {
                            val image = InputImage.fromMediaImage(
                                mediaImage,
                                imageProxy.imageInfo.rotationDegrees
                            )
                            scanner.process(image)
                                .addOnSuccessListener { barcodes ->
                                    for (barcode in barcodes) {
                                        if (barcode.format != Barcode.FORMAT_QR_CODE) continue
                                        val raw = barcode.rawValue ?: continue
                                        Log.d(TAG, "QR raw value: $raw")
                                        val data = parseQrPayload(raw)
                                        if (data != null) {
                                            scanDone = true
                                            onScanned(data)
                                            break
                                        } else {
                                            Log.w(TAG, "QR payload not recognized: $raw")
                                        }
                                    }
                                }
                                .addOnFailureListener { e ->
                                    Log.e(TAG, "Barcode scan failed: ${e.message}")
                                }
                                .addOnCompleteListener { imageProxy.close() }
                        } else {
                            imageProxy.close()
                        }
                    }

                    try {
                        cameraProvider.unbindAll()
                        cameraProvider.bindToLifecycle(
                            lifecycleOwner,
                            CameraSelector.DEFAULT_BACK_CAMERA,
                            preview,
                            imageAnalysis
                        )
                    } catch (e: Exception) {
                        Log.e(TAG, "Camera binding failed: ${e.message}")
                    }
                }, ContextCompat.getMainExecutor(ctx))
                previewView
            },
            modifier = Modifier.fillMaxSize()
        )

        ScannerOverlay(errorMessage)
    }
}

@Composable
private fun ScannerOverlay(errorMessage: String?) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Spacer(Modifier.height(48.dp))

        Text(
            "Scan Provisioning QR Code",
            color      = Color.White,
            fontSize   = 20.sp,
            fontWeight = FontWeight.Bold,
            textAlign  = TextAlign.Center,
            modifier   = Modifier
                .background(Color(0xCC0D1117), RoundedCornerShape(12.dp))
                .padding(horizontal = 20.dp, vertical = 12.dp)
        )

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.padding(bottom = 48.dp)
        ) {
            if (errorMessage != null) {
                Text(
                    errorMessage,
                    color      = Color(0xFFEF4444),
                    fontSize   = 13.sp,
                    textAlign  = TextAlign.Center,
                    modifier   = Modifier
                        .background(Color(0xCC0D1117), RoundedCornerShape(10.dp))
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
            Text(
                "Point the camera at the QR code provided by your dealer to activate this device.",
                color     = Color(0xFFD1D5DB),
                fontSize  = 13.sp,
                textAlign = TextAlign.Center,
                modifier  = Modifier
                    .background(Color(0xCC0D1117), RoundedCornerShape(10.dp))
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            )
        }
    }
}

@Composable
private fun NoCameraPermissionContent(onRequest: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(20.dp),
        modifier = Modifier.padding(32.dp)
    ) {
        Text(
            "Camera Permission Required",
            color      = Color.White,
            fontSize   = 18.sp,
            fontWeight = FontWeight.Bold,
            textAlign  = TextAlign.Center
        )
        Text(
            "This app needs camera access to scan the provisioning QR code and activate your device.",
            color     = Color(0xFF9CA3AF),
            fontSize  = 14.sp,
            textAlign = TextAlign.Center
        )
        Button(
            onClick = onRequest,
            colors  = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B82F6)),
            shape   = RoundedCornerShape(12.dp)
        ) {
            Text("Grant Camera Permission", fontWeight = FontWeight.Bold)
        }
    }
}

/**
 * Parses the QR code payload.
 *
 * Supported formats:
 *  1. JSON:          {"businessId":"…","activationKey":"…","contractNumber":"…"}
 *  2. Pipe-delimited: <businessId>|<activationKey>|<contractNumber>
 *
 * Returns null if the payload cannot be parsed or any required field is blank.
 */
fun parseQrPayload(raw: String): ProvisioningQrData? {
    val trimmed = raw.trim()

    // Try JSON first
    if (trimmed.startsWith("{")) {
        return try {
            val json           = JSONObject(trimmed)
            val businessId     = json.optString("businessId").trim()
            val activationKey  = json.optString("activationKey").trim()
            val contractNumber = json.optString("contractNumber").trim()
            if (businessId.isBlank() || activationKey.isBlank() || contractNumber.isBlank()) null
            else ProvisioningQrData(businessId, activationKey, contractNumber)
        } catch (e: Exception) {
            Log.w(TAG, "JSON parse failed: ${e.message}")
            null
        }
    }

    // Try pipe-delimited
    val parts = trimmed.split("|")
    if (parts.size >= 3) {
        val businessId     = parts[0].trim()
        val activationKey  = parts[1].trim()
        val contractNumber = parts[2].trim()
        if (businessId.isNotBlank() && activationKey.isNotBlank() && contractNumber.isNotBlank()) {
            return ProvisioningQrData(businessId, activationKey, contractNumber)
        }
    }

    return null
}
