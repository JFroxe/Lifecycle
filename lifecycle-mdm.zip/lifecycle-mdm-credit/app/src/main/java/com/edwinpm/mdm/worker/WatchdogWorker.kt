package com.edwinpm.mdm.worker

import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.work.*
import com.edwinpm.mdm.admin.DeviceOwnerHelper
import com.edwinpm.mdm.service.MdmWatchdogService
import com.edwinpm.mdm.util.DeviceRepository
import com.edwinpm.mdm.util.MdmPrefs
import java.util.concurrent.TimeUnit

/**
 * WatchdogWorker — runs every 15 minutes via WorkManager.
 *
 * Tasks:
 *   1. Re-apply all Device Owner policies
 *   2. Ensure the foreground watchdog service is alive
 *   3. Fetch paymentStatus from Firestore and lock if overdue, unlock if active
 *   4. Update lastSeen heartbeat in Firestore
 *   5. Re-enforce lock screen if device is supposed to be locked
 */
class WatchdogWorker(context: Context, params: WorkerParameters) : Worker(context, params) {

    companion object {
        private const val TAG       = "WatchdogWorker"
        private const val WORK_NAME = "MdmWatchdogWork"

        fun enqueue(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()

            val request = PeriodicWorkRequestBuilder<WatchdogWorker>(15, TimeUnit.MINUTES)
                .setConstraints(constraints)
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
            Log.i(TAG, "WatchdogWorker enqueued (15-min interval)")
        }
    }

    override fun doWork(): Result {
        Log.i(TAG, "WatchdogWorker running")
        val prefs = MdmPrefs(applicationContext)

        // Re-apply Device Owner policies
        DeviceOwnerHelper.applyAllPolicies(applicationContext)

        // Keep watchdog service alive
        try {
            applicationContext.startForegroundService(
                Intent(applicationContext, MdmWatchdogService::class.java)
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to restart watchdog service: ${e.message}")
        }

        // Re-enforce lock if currently locked (will be overridden below if server says active)
        if (prefs.isLocked()) {
            Log.w(TAG, "Device is locally locked — will verify with server before re-enforcing")
        }

        // Heartbeat
        DeviceRepository.updateHeartbeat(applicationContext)

        // Fetch authoritative server state and act on it
        DeviceRepository.fetchAndApplyServerState(applicationContext) { status ->
            val currentlyLocked = MdmPrefs(applicationContext).isLocked()

            if (status == "active") {
                if (currentlyLocked) {
                    // FIX: Server says active but device is still locked — unlock it.
                    Log.i(TAG, "WatchdogWorker: server=active but locally locked — unlocking")
                    MdmWatchdogService.sendCommand(
                        applicationContext,
                        MdmWatchdogService.CMD_UNLOCK,
                        "Payment received — device unlocked"
                    )
                }
            } else {
                // Server says not active
                if (!currentlyLocked) {
                    Log.w(TAG, "WatchdogWorker: paymentStatus=$status — triggering lock")
                    val reason = when (status.lowercase()) {
                        "suspended" -> "Payment overdue — device suspended"
                        "revoked"   -> "Contract revoked — contact your provider"
                        else        -> "Device locked by MDM"
                    }
                    MdmWatchdogService.sendCommand(
                        applicationContext,
                        MdmWatchdogService.CMD_LOCK,
                        reason,
                        formatAmount(MdmPrefs(applicationContext).getPlanOverdueAmount()),
                        MdmPrefs(applicationContext).getPlanCurrency()
                    )
                } else {
                    // Already locked and server still says overdue — re-enforce the lock screen
                    Log.w(TAG, "WatchdogWorker: still overdue — re-enforcing lock")
                    val reason = when (status.lowercase()) {
                        "suspended" -> "Payment overdue — device suspended"
                        "revoked"   -> "Contract revoked — contact your provider"
                        else        -> "Device locked by MDM"
                    }
                    MdmWatchdogService.sendCommand(
                        applicationContext,
                        MdmWatchdogService.CMD_LOCK,
                        reason,
                        formatAmount(MdmPrefs(applicationContext).getPlanOverdueAmount()),
                        MdmPrefs(applicationContext).getPlanCurrency()
                    )
                }
            }
        }

        return Result.success()
    }

    private fun formatAmount(v: Double): String =
        if (v == 0.0) "" else if (v == kotlin.math.floor(v)) "%.0f".format(v) else "%.2f".format(v)
}
