package com.edwinpm.mdm.worker

import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.work.*
import com.edwinpm.mdm.admin.DeviceOwnerHelper
import com.edwinpm.mdm.service.MdmWatchdogService
import com.edwinpm.mdm.util.DeviceRepository
import com.edwinpm.mdm.util.MdmPrefs
import java.util.concurrent.TimeUnit

/**
 * WatchdogWorker — runs every 15 minutes via WorkManager.
 *
 * Tasks:
 *   1. Re-apply all Device Owner policies
 *   2. Ensure the foreground watchdog service is alive
 *   3. Fetch paymentStatus from Firestore and lock if overdue
 *   4. Update lastSeen heartbeat in Firestore
 *   5. Re-enforce lock screen if device is supposed to be locked
 */
class WatchdogWorker(context: Context, params: WorkerParameters) : Worker(context, params) {

    companion object {
        private const val TAG       = "WatchdogWorker"
        private const val WORK_NAME = "MdmWatchdogWork"

        fun enqueue(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()

            val request = PeriodicWorkRequestBuilder<WatchdogWorker>(15, TimeUnit.MINUTES)
                .setConstraints(constraints)
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
            Log.i(TAG, "WatchdogWorker enqueued (15-min interval)")
        }
    }

    override fun doWork(): Result {
        Log.i(TAG, "WatchdogWorker running")
        val prefs = MdmPrefs(applicationContext)

        // Re-apply Device Owner policies
        DeviceOwnerHelper.applyAllPolicies(applicationContext)

        // Keep watchdog service alive
        try {
            applicationContext.startForegroundService(
                Intent(applicationContext, MdmWatchdogService::class.java)
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to restart watchdog service: ${e.message}")
        }

        // Re-enforce lock if currently locked
        if (prefs.isLocked()) {
            Log.w(TAG, "Device is locked — re-enforcing via service command")
            MdmWatchdogService.sendCommand(
                applicationContext,
                MdmWatchdogService.CMD_LOCK,
                "Watchdog lock enforcement",
                formatAmount(prefs.getPlanOverdueAmount()),
                prefs.getPlanCurrency()
            )
        }

        // Heartbeat + check payment status from server
        DeviceRepository.updateHeartbeat(applicationContext)

        // Fetch and enforce server paymentStatus
        DeviceRepository.fetchAndApplyServerState(applicationContext) { status ->
            if (status != "active" && !prefs.isLocked()) {
                Log.w(TAG, "WatchdogWorker: paymentStatus=$status — triggering lock")
                val reason = when (status.lowercase()) {
                    "suspended" -> "Payment overdue — device suspended"
                    "revoked"   -> "Contract revoked — contact your provider"
                    else        -> "Device locked by MDM"
                }
                MdmWatchdogService.sendCommand(
                    applicationContext,
                    MdmWatchdogService.CMD_LOCK,
                    reason,
                    formatAmount(prefs.getPlanOverdueAmount()),
                    prefs.getPlanCurrency()
                )
            }
        }

        return Result.success()
    }

    private fun formatAmount(v: Double): String =
        if (v == 0.0) "" else if (v == kotlin.math.floor(v)) "%.0f".format(v) else "%.2f".format(v)
}
