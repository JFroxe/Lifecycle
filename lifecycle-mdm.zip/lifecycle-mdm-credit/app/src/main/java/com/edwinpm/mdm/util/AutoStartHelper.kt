package com.edwinpm.mdm.util

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.util.Log

object AutoStartHelper {

    private const val TAG = "AutoStartHelper"
    private const val PREF_AUTO_START_PROMPTED = "auto_start_prompted"

    fun shouldPrompt(context: Context): Boolean {
        val prefs = context.getSharedPreferences("mdm_prefs", Context.MODE_PRIVATE)
        val alreadyPrompted = prefs.getBoolean(PREF_AUTO_START_PROMPTED, false)
        if (alreadyPrompted) return false
        return isAutoStartPermissionRequired()
    }

    fun markPrompted(context: Context) {
        context.getSharedPreferences("mdm_prefs", Context.MODE_PRIVATE)
            .edit().putBoolean(PREF_AUTO_START_PROMPTED, true).apply()
    }

    fun isAutoStartPermissionRequired(): Boolean {
        val manufacturer = Build.MANUFACTURER.lowercase()
        return manufacturer.contains("xiaomi")  ||
               manufacturer.contains("oppo")    ||
               manufacturer.contains("vivo")    ||
               manufacturer.contains("huawei")  ||
               manufacturer.contains("honor")   ||
               manufacturer.contains("letv")    ||
               manufacturer.contains("zte")     ||
               manufacturer.contains("meizu")   ||
               manufacturer.contains("samsung") ||
               manufacturer.contains("oneplus") ||
               manufacturer.contains("realme")  ||
               manufacturer.contains("asus")    ||
               manufacturer.contains("lenovo")
    }

    fun ensureBatteryOptimizationExempt(context: Context): Boolean {
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        val pkg = context.packageName
        if (pm.isIgnoringBatteryOptimizations(pkg)) {
            Log.i(TAG, "Already exempt from battery optimization")
            return true
        }
        return try {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:$pkg")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Log.i(TAG, "Requested battery optimization exemption")
            true
        } catch (e: Exception) {
            Log.w(TAG, "Failed to request battery optimization exemption: ${e.message}")
            false
        }
    }

    fun isBatteryOptimizationExempt(context: Context): Boolean {
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(context.packageName)
    }

    fun openAutoStartSettings(context: Context): Boolean {
        val intents = buildIntentsForManufacturer()
        for (intent in intents) {
            if (isIntentResolvable(context, intent)) {
                return try {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                    Log.i(TAG, "Opened auto-start settings: ${intent.component ?: intent.action}")
                    true
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to open intent ${intent.component}: ${e.message}")
                    false
                }
            }
        }
        Log.w(TAG, "No auto-start settings screen found for ${Build.MANUFACTURER}")
        return false
    }

    fun applyAllAutoStartProtections(context: Context) {
        ensureBatteryOptimizationExempt(context)
        if (isAutoStartPermissionRequired() && shouldPrompt(context)) {
            markPrompted(context)
            openAutoStartSettings(context)
        }
    }

    private fun buildIntentsForManufacturer(): List<Intent> {
        val pkg = "com.edwinpm.mdm"
        val mfr = Build.MANUFACTURER.lowercase()

        return when {
            mfr.contains("xiaomi") || mfr.contains("redmi") -> listOf(
                Intent().apply {
                    component = ComponentName(
                        "com.miui.securitycenter",
                        "com.miui.permcenter.autostart.AutoStartManagementActivity"
                    )
                },
                Intent().apply {
                    action = "miui.intent.action.APP_PERM_EDITOR"
                    setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.AppPermissionsEditorActivity")
                    putExtra("extra_pkgname", pkg)
                }
            )
            mfr.contains("oppo") || mfr.contains("realme") -> listOf(
                Intent().apply {
                    component = ComponentName(
                        "com.coloros.safecenter",
                        "com.coloros.safecenter.startupapp.StartupAppListActivity"
                    )
                },
                Intent().apply {
                    component = ComponentName(
                        "com.oppo.safe",
                        "com.oppo.safe.permission.startup.StartupAppListActivity"
                    )
                }
            )
            mfr.contains("vivo") -> listOf(
                Intent().apply {
                    component = ComponentName(
                        "com.vivo.permissionmanager",
                        "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"
                    )
                },
                Intent().apply {
                    component = ComponentName(
                        "com.iqoo.secure",
                        "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity"
                    )
                }
            )
            mfr.contains("huawei") || mfr.contains("honor") -> listOf(
                Intent().apply {
                    component = ComponentName(
                        "com.huawei.systemmanager",
                        "com.huawei.systemmanager.optimize.process.ProtectActivity"
                    )
                },
                Intent().apply {
                    component = ComponentName(
                        "com.huawei.systemmanager",
                        "com.huawei.systemmanager.appcontrol.activity.StartupAppControlActivity"
                    )
                }
            )
            mfr.contains("samsung") -> listOf(
                Intent().apply {
                    component = ComponentName(
                        "com.samsung.android.lool",
                        "com.samsung.android.sm.battery.ui.BatteryActivity"
                    )
                },
                Intent().apply {
                    action = "android.settings.APPLICATION_DETAILS_SETTINGS"
                    data = Uri.parse("package:$pkg")
                }
            )
            mfr.contains("oneplus") -> listOf(
                Intent().apply {
                    component = ComponentName(
                        "com.oneplus.security",
                        "com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity"
                    )
                }
            )
            mfr.contains("letv") || mfr.contains("leeco") -> listOf(
                Intent().apply {
                    component = ComponentName(
                        "com.letv.android.letvsafe",
                        "com.letv.android.letvsafe.AutobootManageActivity"
                    )
                }
            )
            mfr.contains("zte") -> listOf(
                Intent().apply {
                    component = ComponentName(
                        "com.zte.heartyservice",
                        "com.zte.heartyservice.autorun.AutoRunListActivity"
                    )
                }
            )
            mfr.contains("meizu") -> listOf(
                Intent().apply {
                    component = ComponentName(
                        "com.meizu.safe",
                        "com.meizu.safe.permission.SmartPermissionActivity"
                    )
                }
            )
            else -> listOf(
                Intent().apply {
                    action = Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS
                    data = Uri.parse("package:$pkg")
                }
            )
        }
    }

    private fun isIntentResolvable(context: Context, intent: Intent): Boolean {
        return try {
            val resolveInfo = context.packageManager.resolveActivity(
                intent,
                PackageManager.MATCH_DEFAULT_ONLY
            )
            resolveInfo != null
        } catch (e: Exception) {
            false
        }
    }
}
