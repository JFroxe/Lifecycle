package com.edwinpm.mdm.util

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log

/**
 * AutoStartHelper — prompts the user to grant the manufacturer-specific "Auto-start"
 * permission that exists on Samsung, Xiaomi (MIUI), OPPO (ColorOS), Vivo (FuntouchOS),
 * Huawei (EMUI), OnePlus (OxygenOS), and other heavily-skinned Androids.
 *
 * PROBLEM: On these devices, apps are not allowed to start on boot or run in the
 * background unless the user explicitly enables "Auto-start" or "Background launch"
 * in a proprietary settings screen. This is not part of Android's standard permission
 * system — it cannot be granted silently, even as Device Owner.
 *
 * SOLUTION: Detect the manufacturer, open the correct settings screen, and guide the
 * user to enable auto-start. This should be called once after the setup wizard finishes.
 *
 * Usage:
 *   if (AutoStartHelper.isAutoStartPermissionRequired(context)) {
 *       AutoStartHelper.openAutoStartSettings(context)
 *   }
 */
object AutoStartHelper {

    private const val TAG = "AutoStartHelper"
    private const val PREF_AUTO_START_PROMPTED = "auto_start_prompted"

    /**
     * Returns true if we're on a manufacturer that requires a manual auto-start grant
     * AND we haven't prompted the user yet.
     */
    fun shouldPrompt(context: Context): Boolean {
        val prefs = context.getSharedPreferences("mdm_prefs", Context.MODE_PRIVATE)
        val alreadyPrompted = prefs.getBoolean(PREF_AUTO_START_PROMPTED, false)
        if (alreadyPrompted) return false
        return isAutoStartPermissionRequired()
    }

    /**
     * Mark that we've already prompted (so we don't show it on every launch).
     */
    fun markPrompted(context: Context) {
        context.getSharedPreferences("mdm_prefs", Context.MODE_PRIVATE)
            .edit().putBoolean(PREF_AUTO_START_PROMPTED, true).apply()
    }

    /**
     * Returns true if the current device manufacturer requires a manual auto-start grant.
     */
    fun isAutoStartPermissionRequired(): Boolean {
        val manufacturer = Build.MANUFACTURER.lowercase()
        return manufacturer.contains("xiaomi")  ||
               manufacturer.contains("oppo")    ||
               manufacturer.contains("vivo")    ||
               manufacturer.contains("huawei")  ||
               manufacturer.contains("honor")   ||
               manufacturer.contains("letv")    ||
               manufacturer.contains("zte")     ||
               manufacturer.contains("meizu")   ||
               manufacturer.contains("samsung") ||
               manufacturer.contains("oneplus") ||
               manufacturer.contains("realme")  ||
               manufacturer.contains("asus")    ||
               manufacturer.contains("lenovo")
    }

    /**
     * Opens the manufacturer-specific auto-start / background launch settings screen.
     * Returns true if the settings screen was found and opened, false otherwise.
     */
    fun openAutoStartSettings(context: Context): Boolean {
        val intents = buildIntentsForManufacturer()
        for (intent in intents) {
            if (isIntentResolvable(context, intent)) {
                return try {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                    Log.i(TAG, "Opened auto-start settings: ${intent.component ?: intent.action}")
                    true
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to open intent ${intent.component}: ${e.message}")
                    false
                }
            }
        }
        Log.w(TAG, "No auto-start settings screen found for ${Build.MANUFACTURER}")
        return false
    }

    private fun buildIntentsForManufacturer(): List<Intent> {
        val pkg = "com.edwinpm.mdm"
        val mfr = Build.MANUFACTURER.lowercase()

        return when {
            mfr.contains("xiaomi") || mfr.contains("redmi") -> listOf(
                Intent().apply {
                    component = ComponentName(
                        "com.miui.securitycenter",
                        "com.miui.permcenter.autostart.AutoStartManagementActivity"
                    )
                },
                Intent().apply {
                    action = "miui.intent.action.APP_PERM_EDITOR"
                    setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.AppPermissionsEditorActivity")
                    putExtra("extra_pkgname", pkg)
                }
            )
            mfr.contains("oppo") || mfr.contains("realme") -> listOf(
                Intent().apply {
                    component = ComponentName(
                        "com.coloros.safecenter",
                        "com.coloros.safecenter.startupapp.StartupAppListActivity"
                    )
                },
                Intent().apply {
                    component = ComponentName(
                        "com.oppo.safe",
                        "com.oppo.safe.permission.startup.StartupAppListActivity"
                    )
                }
            )
            mfr.contains("vivo") -> listOf(
                Intent().apply {
                    component = ComponentName(
                        "com.vivo.permissionmanager",
                        "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"
                    )
                },
                Intent().apply {
                    component = ComponentName(
                        "com.iqoo.secure",
                        "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity"
                    )
                }
            )
            mfr.contains("huawei") || mfr.contains("honor") -> listOf(
                Intent().apply {
                    component = ComponentName(
                        "com.huawei.systemmanager",
                        "com.huawei.systemmanager.optimize.process.ProtectActivity"
                    )
                },
                Intent().apply {
                    component = ComponentName(
                        "com.huawei.systemmanager",
                        "com.huawei.systemmanager.appcontrol.activity.StartupAppControlActivity"
                    )
                }
            )
            mfr.contains("samsung") -> listOf(
                Intent().apply {
                    // Samsung: Device Care → Battery → Background usage limits → Never sleeping apps
                    component = ComponentName(
                        "com.samsung.android.lool",
                        "com.samsung.android.sm.battery.ui.BatteryActivity"
                    )
                },
                Intent().apply {
                    action = "android.settings.APPLICATION_DETAILS_SETTINGS"
                    data = android.net.Uri.parse("package:$pkg")
                }
            )
            mfr.contains("oneplus") -> listOf(
                Intent().apply {
                    component = ComponentName(
                        "com.oneplus.security",
                        "com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity"
                    )
                }
            )
            mfr.contains("letv") || mfr.contains("leeco") -> listOf(
                Intent().apply {
                    component = ComponentName(
                        "com.letv.android.letvsafe",
                        "com.letv.android.letvsafe.AutobootManageActivity"
                    )
                }
            )
            mfr.contains("zte") -> listOf(
                Intent().apply {
                    component = ComponentName(
                        "com.zte.heartyservice",
                        "com.zte.heartyservice.autorun.AutoRunListActivity"
                    )
                }
            )
            mfr.contains("meizu") -> listOf(
                Intent().apply {
                    component = ComponentName(
                        "com.meizu.safe",
                        "com.meizu.safe.permission.SmartPermissionActivity"
                    )
                }
            )
            else -> listOf(
                // Fallback: open the app's battery optimization settings where the user
                // can set it to "Unrestricted" — available on all stock Android 6+
                Intent().apply {
                    action = "android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"
                    data = android.net.Uri.parse("package:$pkg")
                }
            )
        }
    }

    private fun isIntentResolvable(context: Context, intent: Intent): Boolean {
        return try {
            val resolveInfo = context.packageManager.resolveActivity(
                intent,
                PackageManager.MATCH_DEFAULT_ONLY
            )
            resolveInfo != null
        } catch (e: Exception) {
            false
        }
    }
}
