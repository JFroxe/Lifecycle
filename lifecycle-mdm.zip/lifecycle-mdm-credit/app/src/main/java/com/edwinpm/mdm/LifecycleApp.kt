package com.edwinpm.mdm

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import com.edwinpm.mdm.admin.DeviceOwnerHelper
import com.edwinpm.mdm.service.MdmWatchdogService
import com.edwinpm.mdm.worker.WatchdogWorker

class LifecycleApp : Application() {

    companion object {
        const val CHANNEL_WATCHDOG = "channel_watchdog"
        const val CHANNEL_LOCK = "channel_lock"
        const val NOTIFICATION_ID_WATCHDOG = 1001
        const val NOTIFICATION_ID_LOCK = 1002
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()

        // Apply all Device Owner policies every time the app process starts.
        // This is the primary enforcement point — ensures uninstall block,
        // lock task packages, and LOCK_TASK_FEATURE_NONE are always active,
        // even after a force-stop or device reboot.
        DeviceOwnerHelper.applyAllPolicies(this)

        // Ensure the persistent watchdog service is running
        startForegroundService(Intent(this, MdmWatchdogService::class.java))

        // Ensure the periodic WorkManager job is scheduled
        WatchdogWorker.enqueue(this)
    }

    private fun createNotificationChannels() {
        val watchdogChannel = NotificationChannel(
            CHANNEL_WATCHDOG,
            "MDM Watchdog Service",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Keeps the MDM agent active in the background"
            setShowBadge(false)
        }

        val lockChannel = NotificationChannel(
            CHANNEL_LOCK,
            "Device Lock",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Notifies when device is locked by MDM"
        }

        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannels(listOf(watchdogChannel, lockChannel))
    }
}
