package com.edwinpm.mdm.ui

data class BusinessInfo(
    val id: String,
    val name: String,
    val phone: String,
    val address: String
)
