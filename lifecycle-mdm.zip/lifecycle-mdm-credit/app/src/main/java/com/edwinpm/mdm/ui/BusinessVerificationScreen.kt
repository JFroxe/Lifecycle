package com.edwinpm.mdm.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.edwinpm.mdm.R

data class BusinessInfo(
    val id: String,
    val name: String,
    val phone: String,
    val address: String
)

/**
 * BusinessVerificationScreen — the first step after admin/owner confirmation.
 *
 * The operator enters their Business ID. The app looks it up in the Firestore
 * "business" collection. If found, the business details are passed back and the
 * registration wizard opens. If not found, an error is shown.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BusinessVerificationScreen(
    onVerify: (businessId: String, onResult: (found: Boolean, name: String, phone: String, address: String) -> Unit) -> Unit,
    onVerified: (BusinessInfo) -> Unit
) {
    var businessId  by remember { mutableStateOf("") }
    var isLoading   by remember { mutableStateOf(false) }
    var errorMsg    by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Business Verification", fontWeight = FontWeight.Bold, fontSize = 17.sp) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF0F1923))
            )
        },
        containerColor = Color(0xFF0D1117)
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {

            Icon(
                painter = painterResource(R.drawable.ic_shield),
                contentDescription = null,
                tint = Color(0xFF3B82F6),
                modifier = Modifier.size(64.dp)
            )

            Spacer(Modifier.height(24.dp))

            Text(
                "Enter your Business ID",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(8.dp))

            Text(
                "This ID is provided by Lifecycle Credit to authorized vendors and distributors.",
                color = Color(0xFF9CA3AF),
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
                lineHeight = 20.sp
            )

            Spacer(Modifier.height(32.dp))

            OutlinedTextField(
                value = businessId,
                onValueChange = { businessId = it; errorMsg = "" },
                placeholder = { Text("e.g. BIZ-001", color = Color(0xFF4B5563)) },
                label = { Text("Business ID", color = Color(0xFF6B7280)) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor   = Color(0xFF3B82F6),
                    unfocusedBorderColor = Color(0xFF374151),
                    focusedTextColor     = Color.White,
                    unfocusedTextColor   = Color.White,
                    cursorColor          = Color(0xFF3B82F6)
                ),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                isError = errorMsg.isNotBlank()
            )

            if (errorMsg.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(errorMsg, color = Color(0xFFEF4444), fontSize = 13.sp, textAlign = TextAlign.Center)
            }

            Spacer(Modifier.height(24.dp))

            Button(
                onClick = {
                    if (businessId.isBlank()) {
                        errorMsg = "Please enter your Business ID."
                        return@Button
                    }
                    isLoading = true
                    errorMsg  = ""
                    onVerify(businessId.trim()) { found, name, phone, address ->
                        isLoading = false
                        if (found) {
                            onVerified(BusinessInfo(id = businessId.trim(), name = name, phone = phone, address = address))
                        } else {
                            errorMsg = "Business ID not found. Please check the ID and try again."
                        }
                    }
                },
                enabled = !isLoading && businessId.isNotBlank(),
                modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B82F6)),
                shape = RoundedCornerShape(12.dp)
            ) {
                if (isLoading) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                } else {
                    Text("Verify Business ID", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }
        }
    }
}
