package com.edwinpm.mdm.fcm

import android.util.Log
import com.edwinpm.mdm.util.DeviceRepository
import com.edwinpm.mdm.util.MdmPrefs
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/**
 * MdmFcmService — handles real-time FCM push commands from the MDM backend.
 *
 * ── FCM Payload Format ────────────────────────────────────────────────────────
 * Send DATA messages (not notification messages) with these payloads:
 *
 *   Lock device (payment overdue):
 *     { "cmd": "lock", "reason": "Payment overdue", "overdueAmount": "350.00", "currency": "USD" }
 *
 *   Unlock device (payment received):
 *     { "cmd": "unlock", "reason": "Payment received — thank you" }
 *
 *   Update payment status only (no lock):
 *     { "cmd": "update_status", "paymentStatus": "active", "planBalance": "850.00", "planPaid": "350.00" }
 *
 *   Factory wipe:
 *     { "cmd": "wipe", "reason": "Contract terminated" }
 *
 *   Ping (health check):
 *     { "cmd": "ping" }
 *
 * ── Send via FCM REST API ─────────────────────────────────────────────────────
 * POST https://fcm.googleapis.com/v1/projects/{PROJECT_ID}/messages:send
 * Authorization: Bearer {ACCESS_TOKEN}
 * {
 *   "message": {
 *     "token": "{DEVICE_FCM_TOKEN}",
 *     "data": { "cmd": "lock", "reason": "Payment overdue", "overdueAmount": "350.00", "currency": "USD" }
 *   }
 * }
 */
class MdmFcmService : FirebaseMessagingService() {

    companion object {
        private const val TAG = "MdmFcmService"

        const val CMD_LOCK = "LOCK"
        const val CMD_UNLOCK = "UNLOCK"
        const val CMD_WIPE = "WIPE"
        const val CMD_PING = "PING"
        const val CMD_UPDATE_STATUS = "UPDATE_STATUS"
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.i(TAG, "FCM token refreshed")
        MdmPrefs(applicationContext).setFcmToken(token)
        DeviceRepository.syncToken(applicationContext, token)
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        Log.i(TAG, "FCM message received from: ${remoteMessage.from}")

        val data = remoteMessage.data
        if (data.isEmpty()) {
            Log.w(TAG, "FCM message has no data payload — ignoring")
            return
        }

        if (!DeviceRepository.handleRemoteCommand(applicationContext, data, "FCM")) {
            Log.w(TAG, "FCM message did not contain a supported command")
        }
    }
}
