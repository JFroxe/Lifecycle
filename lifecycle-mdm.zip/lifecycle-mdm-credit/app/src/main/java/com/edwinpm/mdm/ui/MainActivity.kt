package com.edwinpm.mdm.ui

import android.annotation.SuppressLint
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.telephony.TelephonyManager
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.edwinpm.mdm.admin.DeviceOwnerHelper
import com.edwinpm.mdm.admin.MdmDeviceAdminReceiver
import com.edwinpm.mdm.kiosk.KioskLockActivity
import com.edwinpm.mdm.service.MdmWatchdogService
import com.edwinpm.mdm.ui.theme.LifecycleTheme
import com.edwinpm.mdm.util.AutoStartHelper
import com.edwinpm.mdm.util.DeviceRepository
import com.edwinpm.mdm.util.MdmPrefs
import com.edwinpm.mdm.worker.WatchdogWorker
import com.google.firebase.firestore.ListenerRegistration

/**
 * MainActivity — orchestrates the full launch flow:
 *
 *  ① Device not Admin + Owner  → AdminRequirementScreen
 *  ② Setup not done            → ProvisioningScreen
 *                                 Phase A: QR scanner — user scans the provisioning QR code.
 *                                 Phase B: Verifying spinner — Firestore verification in progress.
 *                                 IDs (businessId / activationKey / contractNumber) come from
 *                                 the scanned QR code, NOT from the Android QR provisioning flow.
 *                                 On failure → app closes.
 *  ③ Setup done + locked       → KioskLockActivity
 *  ④ Setup done + unlocked     → MainScreen (credit dashboard)
 */
class MainActivity : ComponentActivity() {

    companion object {
        private const val TAG = "MainActivity"
    }

    private sealed class Screen {
        object AdminRequired : Screen()
        object Provisioning  : Screen()
        object Dashboard     : Screen()
        object Payment       : Screen()
    }

    private var screen by mutableStateOf<Screen>(Screen.AdminRequired)

    /** True once the QR has been scanned and Firestore verification has started. */
    private var verifying by mutableStateOf(false)

    private var paymentStatus by mutableStateOf("active")
    private var currency      by mutableStateOf("USD")
    private var balance       by mutableStateOf(0.0)
    private var paid          by mutableStateOf(0.0)
    private var total         by mutableStateOf(0.0)
    private var overdue       by mutableStateOf(0.0)
    private var dueDate       by mutableStateOf("")
    private var planName      by mutableStateOf("")
    private var ownerName     by mutableStateOf("")
    private var ownerPhone    by mutableStateOf("")
    private var contractId    by mutableStateOf("")
    private var imei          by mutableStateOf("")
    private var businessName  by mutableStateOf("")
    private var businessPhone by mutableStateOf("")
    private var businessAddr        by mutableStateOf("")
    private var nextPaymentDate     by mutableStateOf("")
    private var isProcessingPayment by mutableStateOf(false)

    private var firestoreListener: ListenerRegistration? = null

    private val requestAdminLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { _ -> reEvaluateScreen() }

    // ── Lifecycle ──────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val prefs = MdmPrefs(this)

        if (prefs.isLocked()) {
            DeviceRepository.fetchAndApplyServerState(this) { serverStatus ->
                if (serverStatus != "active") {
                    startKioskActivity(
                        reason        = "Device locked by MDM",
                        overdueAmount = fmtAmt(MdmPrefs(this).getPlanOverdueAmount()),
                        currency      = MdmPrefs(this).getPlanCurrency()
                    )
                    finish()
                } else {
                    Log.i(TAG, "Server active — clearing stale local lock flag")
                    MdmPrefs(this).setLocked(false)
                    continueOnCreate()
                }
            }
            return
        }

        continueOnCreate()
    }

    private fun continueOnCreate() {
        val prefs = MdmPrefs(this)

        startForegroundService(Intent(this, MdmWatchdogService::class.java))
        WatchdogWorker.enqueue(this)

        screen = resolveScreen(prefs)
        loadStateFromPrefs(prefs)

        setContent {
            LifecycleTheme {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF0D1117))
                ) {
                    when (screen) {

                        Screen.AdminRequired -> AdminRequirementScreen(
                            isAdmin       = DeviceOwnerHelper.isDeviceAdmin(this@MainActivity),
                            isDeviceOwner = DeviceOwnerHelper.isDeviceOwner(this@MainActivity),
                            onRetry       = { reEvaluateScreen() }
                        )

                        Screen.Provisioning -> ProvisioningScreen(
                            verifying   = verifying,
                            onQrScanned = { qrData -> handleQrScanned(qrData) }
                        )

                        Screen.Dashboard -> MainScreen(
                            paymentStatus = paymentStatus,
                            currency      = currency,
                            balance       = balance,
                            paid          = paid,
                            total         = total,
                            overdue       = overdue,
                            dueDate       = nextPaymentDate.ifBlank { dueDate },
                            planName      = planName,
                            ownerName     = ownerName,
                            ownerPhone    = ownerPhone,
                            contractId    = contractId,
                            imei          = imei,
                            businessName  = businessName,
                            businessPhone = businessPhone,
                            businessAddr  = businessAddr,
                            onPay         = { screen = Screen.Payment }
                        )

                        Screen.Payment -> {
                            val p = MdmPrefs(this@MainActivity)
                            PaymentScreen(
                                balance           = fmtAmt(p.getPlanBalance()),
                                currency          = p.getPlanCurrency(),
                                installmentAmount = fmtAmt(p.getInstallmentValue()),
                                nextPaymentDate   = nextPaymentDate.ifBlank { p.getNextPaymentDate() },
                                isProcessing      = isProcessingPayment,
                                onBack            = { screen = Screen.Dashboard },
                                onSimulatePayment = { handleSimulatePayment() }
                            )
                        }
                    }
                }
            }
        }

        if (!DeviceOwnerHelper.isDeviceAdmin(this)) {
            requestDeviceAdmin()
        } else {
            DeviceOwnerHelper.applyAllPolicies(this)
        }
    }

    override fun onResume() {
        super.onResume()
        val prefs = MdmPrefs(this)

        if (prefs.isLocked()) {
            startKioskActivity(
                "Device locked by MDM",
                fmtAmt(prefs.getPlanOverdueAmount()),
                prefs.getPlanCurrency()
            )
            return
        }

        if (screen is Screen.AdminRequired) {
            reEvaluateScreen()
            return
        }

        if (screen is Screen.Dashboard && prefs.isSetupDone()) {
            startFirestoreListener()
              DeviceRepository.checkPaymentDueDate(this)

              // If nextPaymentDate is not yet computed, derive it now from server time
              val p2 = MdmPrefs(this)
              if (p2.getNextPaymentDate().isBlank() && p2.getRegistrationDate().isNotBlank()) {
                  DeviceRepository.computeAndSaveNextPaymentDate(this)
              } else if (p2.getNextPaymentDate().isNotBlank()) {
                  nextPaymentDate = p2.getNextPaymentDate()
              }

              if (!AutoStartHelper.isBatteryOptimizationExempt(this)) {
                AutoStartHelper.ensureBatteryOptimizationExempt(this)
            }
            if (AutoStartHelper.shouldPrompt(this)) {
                AutoStartHelper.markPrompted(this)
                AutoStartHelper.openAutoStartSettings(this)
            }
        }
    }

    override fun onPause() {
        super.onPause()
        stopFirestoreListener()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopFirestoreListener()
    }

    // ── QR-based provisioning ─────────────────────────────────────────────────

    private fun handleQrScanned(qrData: ProvisioningQrData) {
        Log.i(TAG, "QR scanned — businessId=${qrData.businessId} contractNumber=${qrData.contractNumber}")

        val prefs = MdmPrefs(this)
        prefs.setBusinessId(qrData.businessId)
        prefs.setActivationKey(qrData.activationKey)
        prefs.setContractNumber(qrData.contractNumber)
        prefs.markProvisioningDone()

        verifying = true
        startAutoActivation()
    }

    private fun startAutoActivation() {
        val prefs          = MdmPrefs(this)
        val businessId     = prefs.getBusinessId()
        val activationKey  = prefs.getActivationKey()
        val contractNumber = prefs.getContractNumber()

        if (businessId.isBlank() || activationKey.isBlank() || contractNumber.isBlank()) {
            Log.e(TAG, "Missing provisioning data — businessId=$businessId contractNumber=$contractNumber")
            finishAndRemoveTask()
            return
        }

        val deviceImei    = readImei()
        val deviceSn      = readSerialNumber()
        val deviceAndroid = DeviceRepository.getAndroidId(this)

        DeviceRepository.verifyAndActivate(
            context        = this,
            businessId     = businessId,
            activationKey  = activationKey,
            contractNumber = contractNumber,
            imei           = deviceImei,
            serialNumber   = deviceSn,
            androidId      = deviceAndroid
        ) { result ->
            runOnUiThread {
                if (!result.success) {
                    Log.e(TAG, "Activation failed: ${result.error}")
                    finishAndRemoveTask()
                    return@runOnUiThread
                }

                val p = MdmPrefs(this)
                p.setOwnerName(result.customerName)
                p.setOwnerPhone(result.customerPhone)
                p.setOwnerIdNumber(result.customerIdNumber)
                p.setContractId(contractNumber)
                p.setDeviceImei(deviceImei)
                p.setSerialNumber(deviceSn)
                p.setPlanTotalAmount(result.loanTotal)
                p.setInstallmentValue(result.installmentValue)
                p.setPaymentFrequency(result.paymentFrequency)
                p.setPlanDueDate(result.planDueDate)
                p.setPlanCurrency(result.planCurrency)
                p.setPlanPaidAmount(result.planPaid)
                p.setPlanBalance(result.planBalance)
                p.setPlanOverdueAmount(0.0)
                p.setPaymentStatus(result.paymentStatus)
                p.setBusinessName(result.businessName)
                p.setBusinessPhone(result.businessPhone)
                p.setBusinessAddress(result.businessAddress)
                p.markSetupDone()

                  // Fetch server time to compute and store registration date + next payment date
                  com.edwinpm.mdm.util.DeviceRepository.computeAndSaveNextPaymentDate(this@MainActivity)
                      .let { /* runs asynchronously; nextPaymentDate state updated via listener */ }

                  Log.i(TAG, "Activation complete — contract=$contractNumber")
                  loadStateFromPrefs(p)
                  AutoStartHelper.applyAllAutoStartProtections(this)
                  verifying = false
                  screen    = Screen.Dashboard
            }
        }
    }

    // ── Firestore real-time listener ──────────────────────────────────────────

    private fun startFirestoreListener() {
        if (firestoreListener != null) return
        Log.i(TAG, "Starting Firestore real-time listener")
        firestoreListener = DeviceRepository.startRealtimeListener(this) { newStatus ->
            val prefs = MdmPrefs(this)
            paymentStatus = newStatus
            currency      = prefs.getPlanCurrency()
            balance       = prefs.getPlanBalance()
            paid          = prefs.getPlanPaidAmount()
            total         = prefs.getPlanTotalAmount()
            overdue       = prefs.getPlanOverdueAmount()
            dueDate         = prefs.getPlanDueDate()
            planName        = prefs.getPlanName()
            nextPaymentDate = prefs.getNextPaymentDate()

            if (newStatus == "active") {
                if (prefs.isLocked()) {
                    MdmWatchdogService.sendCommand(
                        this, MdmWatchdogService.CMD_UNLOCK, "Payment received — device unlocked"
                    )
                }
            } else {
                val reason = when (newStatus.lowercase()) {
                    "suspended" -> "Payment overdue — device suspended"
                    "revoked"   -> "Contract revoked — contact your provider"
                    else        -> "Device locked by MDM"
                }
                MdmWatchdogService.sendCommand(
                    this, MdmWatchdogService.CMD_LOCK, reason,
                    fmtAmt(prefs.getPlanOverdueAmount()), prefs.getPlanCurrency()
                )
            }
        }
    }

    private fun stopFirestoreListener() {
        firestoreListener?.remove()
        firestoreListener = null
    }

    // ── Payment simulation ───────────────────────────────────────────────────────

      private fun handleSimulatePayment() {
          val prefs = MdmPrefs(this)
          val installment = prefs.getInstallmentValue()
          val frequency   = prefs.getPaymentFrequency()
          val curNextDate = nextPaymentDate.ifBlank { prefs.getNextPaymentDate() }
          isProcessingPayment = true

          com.edwinpm.mdm.util.ServerTimeHelper.fetchServerTime { serverDate ->
              val srvTime = serverDate ?: java.util.Date()
              com.edwinpm.mdm.util.DeviceRepository.simulatePayment(
                  context            = this,
                  installmentAmount  = installment,
                  nextPaymentDate    = curNextDate,
                  paymentFrequency   = frequency,
                  serverTime         = srvTime
              ) { success, newBal, newNextDate ->
                  runOnUiThread {
                      isProcessingPayment = false
                      if (success) {
                          balance         = newBal
                          nextPaymentDate = newNextDate
                          paid            = prefs.getPlanPaidAmount()
                          paymentStatus   = prefs.getPaymentStatus()
                          overdue         = prefs.getPlanOverdueAmount()
                      }
                  }
              }
          }
      }

      // ── Helpers ───────────────────────────────────────────────────────────────

    private fun loadStateFromPrefs(prefs: MdmPrefs) {
        paymentStatus = prefs.getPaymentStatus()
        currency      = prefs.getPlanCurrency()
        balance       = prefs.getPlanBalance()
        paid          = prefs.getPlanPaidAmount()
        total         = prefs.getPlanTotalAmount()
        overdue       = prefs.getPlanOverdueAmount()
        dueDate       = prefs.getPlanDueDate()
        planName      = prefs.getPlanName()
        ownerName     = prefs.getOwnerName()
        ownerPhone    = prefs.getOwnerPhone()
        contractId    = prefs.getContractNumber()
        imei          = prefs.getDeviceImei()
        businessName  = prefs.getBusinessName()
        businessPhone = prefs.getBusinessPhone()
        businessAddr    = prefs.getBusinessAddress()
        nextPaymentDate = prefs.getNextPaymentDate().ifBlank { prefs.getPlanDueDate() }
    }

    private fun resolveScreen(prefs: MdmPrefs): Screen {
        val isAdmin = DeviceOwnerHelper.isDeviceAdmin(this)
        val isOwner = DeviceOwnerHelper.isDeviceOwner(this)
        return when {
            !isAdmin || !isOwner -> Screen.AdminRequired
            !prefs.isSetupDone() -> Screen.Provisioning
            else                 -> Screen.Dashboard
        }
    }

    private fun reEvaluateScreen() {
        if (DeviceOwnerHelper.isDeviceAdmin(this)) DeviceOwnerHelper.applyAllPolicies(this)
        val newScreen = resolveScreen(MdmPrefs(this))
        screen = newScreen
        if (newScreen is Screen.Provisioning) {
            val prefs = MdmPrefs(this)
            if (prefs.getBusinessId().isNotBlank() &&
                prefs.getActivationKey().isNotBlank() &&
                prefs.getContractNumber().isNotBlank()
            ) {
                verifying = true
                startAutoActivation()
            }
        }
    }

    private fun requestDeviceAdmin() {
        val adminComponent = ComponentName(this, MdmDeviceAdminReceiver::class.java)
        requestAdminLauncher.launch(
            Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
                putExtra(
                    DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                    "Lifecycle MDM requires Device Administrator privileges to manage this credit-financed device."
                )
            }
        )
    }

    /**
     * Reads the device IMEI.
     *
     * Device Owner apps are granted special system-level access to TelephonyManager.getImei()
     * by the Android framework — READ_PHONE_STATE + Device Owner status is sufficient on all
     * Android versions, including Android 10+. The try-catch handles graceful fallback if the
     * device has no cellular (e.g. Wi-Fi-only tablet).
     */
    @SuppressLint("MissingPermission", "HardwareIds")
    private fun readImei(): String {
        var result = ""
        try {
            val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            val raw: String? = tm.getImei(0) ?: tm.deviceId
            if (!raw.isNullOrBlank()) result = raw
        } catch (e: Exception) {
            Log.w(TAG, "IMEI read failed: ${e.message}")
        }
        return result
    }

    /**
     * Reads the device serial number.
     *
     * Build.getSerial() requires READ_PHONE_STATE (granted to this Device Owner app).
     * Falls back to the deprecated Build.SERIAL for older Android versions.
     */
    @SuppressLint("MissingPermission", "HardwareIds")
    private fun readSerialNumber(): String {
        var result = ""
        try {
            val serial: String = Build.getSerial()
            if (serial.isNotBlank() && serial != Build.UNKNOWN) result = serial
        } catch (e: Exception) {
            try {
                @Suppress("DEPRECATION")
                val serial: String = Build.SERIAL
                if (serial.isNotBlank() && serial != Build.UNKNOWN) result = serial
            } catch (e2: Exception) {
                Log.w(TAG, "Serial read failed: ${e2.message}")
            }
        }
        return result
    }

    private fun startKioskActivity(reason: String, overdueAmount: String = "", currency: String = "") {
        startActivity(Intent(this, KioskLockActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra(KioskLockActivity.EXTRA_REASON,         reason)
            putExtra(KioskLockActivity.EXTRA_OVERDUE_AMOUNT, overdueAmount)
            putExtra(KioskLockActivity.EXTRA_CURRENCY,       currency)
        })
    }

    private fun fmtAmt(v: Double): String =
        if (v == 0.0) "" else if (v == kotlin.math.floor(v)) "%.0f".format(v) else "%.2f".format(v)
}
