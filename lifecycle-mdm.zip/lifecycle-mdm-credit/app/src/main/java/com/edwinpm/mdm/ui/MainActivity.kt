package com.edwinpm.mdm.ui

import android.annotation.SuppressLint
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.telephony.TelephonyManager
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import com.edwinpm.mdm.admin.DeviceOwnerHelper
import com.edwinpm.mdm.admin.MdmDeviceAdminReceiver
import com.edwinpm.mdm.kiosk.KioskLockActivity
import com.edwinpm.mdm.service.MdmWatchdogService
import com.edwinpm.mdm.ui.theme.LifecycleTheme
import com.edwinpm.mdm.util.DeviceRepository
import com.edwinpm.mdm.util.MdmPrefs
import com.edwinpm.mdm.worker.WatchdogWorker
import com.google.firebase.firestore.ListenerRegistration
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Random

/**
 * MainActivity — orchestrates the full launch flow:
 *
 *   ① Device not Admin + Owner  → AdminRequirementScreen
 *   ② Setup not done            → BusinessVerificationScreen → SetupWizardScreen
 *   ③ Setup done + locked       → KioskLockActivity
 *   ④ Setup done + unlocked     → MainScreen (credit dashboard)
 *
 * A Firestore real-time listener is attached while the dashboard is visible.
 * Any change to the device document (paymentStatus, planBalance, pendingCmd)
 * is reflected immediately in the UI without restarting the app.
 */
class MainActivity : ComponentActivity() {

    companion object {
        private const val TAG = "MainActivity"
    }

    // ── Navigation ─────────────────────────────────────────────────────────────
    private sealed class Screen {
        object AdminRequired : Screen()
        object BusinessVerify : Screen()
        data class Setup(val biz: BusinessInfo, val imei: String, val contractId: String) : Screen()
        object Dashboard : Screen()
        object Payment : Screen()
    }

    private var screen by mutableStateOf<Screen>(Screen.AdminRequired)

    // ── Dashboard state (live — driven by Firestore listener) ──────────────────
    private var paymentStatus by mutableStateOf("active")
    private var currency      by mutableStateOf("USD")
    private var balance       by mutableStateOf(0.0)
    private var paid          by mutableStateOf(0.0)
    private var total         by mutableStateOf(0.0)
    private var overdue       by mutableStateOf(0.0)
    private var dueDate       by mutableStateOf("")
    private var planName      by mutableStateOf("")
    private var ownerName     by mutableStateOf("")
    private var ownerPhone    by mutableStateOf("")
    private var contractId    by mutableStateOf("")
    private var imei          by mutableStateOf("")
    private var businessName  by mutableStateOf("")
    private var businessPhone by mutableStateOf("")
    private var businessAddr  by mutableStateOf("")

    private var firestoreListener: ListenerRegistration? = null

    private val requestAdminLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { _ -> reEvaluateScreen() }

    // ── Lifecycle ──────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val prefs = MdmPrefs(this)

        if (prefs.isLocked()) {
            startKioskActivity(
                reason        = "Device locked by MDM",
                overdueAmount = fmtAmt(prefs.getPlanOverdueAmount()),
                currency      = prefs.getPlanCurrency()
            )
            finish()
            return
        }

        startForegroundService(Intent(this, MdmWatchdogService::class.java))
        WatchdogWorker.enqueue(this)

        screen = resolveScreen(prefs)
        loadStateFromPrefs(prefs)

        setContent {
            LifecycleTheme {
                when (val s = screen) {

                    is Screen.AdminRequired -> AdminRequirementScreen(
                        isAdmin       = DeviceOwnerHelper.isDeviceAdmin(this),
                        isDeviceOwner = DeviceOwnerHelper.isDeviceOwner(this),
                        onRetry       = { reEvaluateScreen() }
                    )

                    is Screen.BusinessVerify -> BusinessVerificationScreen(
                        onVerify   = { id, cb ->
                            DeviceRepository.verifyBusiness(id) { found, name, phone, address ->
                                cb(found, name, phone, address)
                            }
                        },
                        onVerified = { biz ->
                            val p2       = MdmPrefs(this)
                            val deviceImei  = readImei()
                            val contract    = generateContractId()
                            p2.setBusinessId(biz.id)
                            p2.setBusinessName(biz.name)
                            p2.setBusinessPhone(biz.phone)
                            p2.setBusinessAddress(biz.address)
                            screen = Screen.Setup(biz, deviceImei, contract)
                        }
                    )

                    is Screen.Setup -> SetupWizardScreen(
                        businessInfo    = s.biz,
                        imei            = s.imei,
                        contractId      = s.contractId,
                        onSetupComplete = { data ->
                            saveSetupData(data)
                            DeviceRepository.registerDevice(this)
                            loadStateFromPrefs(MdmPrefs(this))
                            screen = Screen.Dashboard
                        }
                    )

                    is Screen.Dashboard -> MainScreen(
                        paymentStatus = paymentStatus,
                        currency      = currency,
                        balance       = balance,
                        paid          = paid,
                        total         = total,
                        overdue       = overdue,
                        dueDate       = dueDate,
                        planName      = planName,
                        ownerName     = ownerName,
                        ownerPhone    = ownerPhone,
                        contractId    = contractId,
                        imei          = imei,
                        businessName  = businessName,
                        businessPhone = businessPhone,
                        businessAddr  = businessAddr,
                        onPay         = { screen = Screen.Payment }
                    )

                    is Screen.Payment -> {
                        val p2 = MdmPrefs(this)
                        PaymentScreen(
                            balance  = fmtAmt(p2.getPlanBalance()),
                            currency = p2.getPlanCurrency(),
                            onBack   = { screen = Screen.Dashboard }
                        )
                    }
                }
            }
        }

        if (!DeviceOwnerHelper.isDeviceAdmin(this)) {
            requestDeviceAdmin()
        } else {
            DeviceOwnerHelper.applyAllPolicies(this)
        }
    }

    override fun onResume() {
        super.onResume()
        val prefs = MdmPrefs(this)

        if (prefs.isLocked()) {
            startKioskActivity("Device locked by MDM",
                fmtAmt(prefs.getPlanOverdueAmount()), prefs.getPlanCurrency())
            return
        }

        if (screen is Screen.AdminRequired) {
            reEvaluateScreen()
            return
        }

        // Attach real-time Firestore listener whenever the dashboard is visible
        if (screen is Screen.Dashboard && prefs.isSetupDone()) {
            startFirestoreListener()
        }
    }

    override fun onPause() {
        super.onPause()
        stopFirestoreListener()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopFirestoreListener()
    }

    // ── Firestore real-time listener ──────────────────────────────────────────

    private fun startFirestoreListener() {
        if (firestoreListener != null) return  // already listening
        Log.i(TAG, "Starting Firestore real-time listener")
        firestoreListener = DeviceRepository.startRealtimeListener(this) { newStatus ->
            // This runs on the main thread — updating these triggers Compose recomposition
            val prefs = MdmPrefs(this)
            paymentStatus = newStatus
            currency      = prefs.getPlanCurrency()
            balance       = prefs.getPlanBalance()
            paid          = prefs.getPlanPaidAmount()
            total         = prefs.getPlanTotalAmount()
            overdue       = prefs.getPlanOverdueAmount()
            dueDate       = prefs.getPlanDueDate()
            planName      = prefs.getPlanName()

            // Lock the device if payment lapses
            if (newStatus != "active") {
                val reason = when (newStatus.lowercase()) {
                    "suspended" -> "Payment overdue — device suspended"
                    "revoked"   -> "Contract revoked — contact your provider"
                    else        -> "Device locked by MDM"
                }
                MdmWatchdogService.sendCommand(
                    this, MdmWatchdogService.CMD_LOCK, reason,
                    fmtAmt(prefs.getPlanOverdueAmount()), prefs.getPlanCurrency()
                )
            }
        }
    }

    private fun stopFirestoreListener() {
        firestoreListener?.remove()
        firestoreListener = null
        Log.i(TAG, "Firestore listener stopped")
    }

    // ── Helpers ────────────────────────────────────────────────────────────────

    /** Populate all state variables from locally-cached prefs (shown immediately). */
    private fun loadStateFromPrefs(prefs: MdmPrefs) {
        paymentStatus = prefs.getPaymentStatus()
        currency      = prefs.getPlanCurrency()
        balance       = prefs.getPlanBalance()
        paid          = prefs.getPlanPaidAmount()
        total         = prefs.getPlanTotalAmount()
        overdue       = prefs.getPlanOverdueAmount()
        dueDate       = prefs.getPlanDueDate()
        planName      = prefs.getPlanName()
        ownerName     = prefs.getOwnerName()
        ownerPhone    = prefs.getOwnerPhone()
        contractId    = prefs.getContractId()
        imei          = prefs.getDeviceImei()
        businessName  = prefs.getBusinessName()
        businessPhone = prefs.getBusinessPhone()
        businessAddr  = prefs.getBusinessAddress()
    }

    private fun resolveScreen(prefs: MdmPrefs): Screen {
        val isAdmin = DeviceOwnerHelper.isDeviceAdmin(this)
        val isOwner = DeviceOwnerHelper.isDeviceOwner(this)
        return when {
            !isAdmin || !isOwner -> Screen.AdminRequired
            !prefs.isSetupDone() -> Screen.BusinessVerify
            else                 -> Screen.Dashboard
        }
    }

    private fun reEvaluateScreen() {
        if (DeviceOwnerHelper.isDeviceAdmin(this)) DeviceOwnerHelper.applyAllPolicies(this)
        screen = resolveScreen(MdmPrefs(this))
    }

    private fun requestDeviceAdmin() {
        val adminComponent = ComponentName(this, MdmDeviceAdminReceiver::class.java)
        requestAdminLauncher.launch(
            Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
                putExtra(
                    DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                    "Lifecycle MDM requires Device Administrator privileges to manage this credit-financed device."
                )
            }
        )
    }

    @SuppressLint("MissingPermission")
    private fun readImei(): String {
        return try {
            val tm = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
            val i  = tm.getImei(0)
            if (!i.isNullOrBlank()) i else tm.deviceId ?: ""
        } catch (e: Exception) {
            Log.w(TAG, "Could not read IMEI: ${e.message}")
            ""
        }
    }

    private fun generateContractId(): String {
        val year = SimpleDateFormat("yyyy", Locale.US).format(Date())
        val rand = (100000 + Random().nextInt(900000)).toString()
        return "LC-$year-$rand"
    }

    private fun saveSetupData(data: SetupData) {
        val prefs = MdmPrefs(this)
        prefs.setOwnerName(data.ownerName)
        prefs.setOwnerPhone(data.ownerPhone)
        prefs.setContractId(data.contractId)
        prefs.setDeviceImei(data.deviceImei)
        prefs.setPlanName(data.planName)
        prefs.setPlanCurrency(data.planCurrency)
        prefs.setPlanTotalAmount(data.planTotal)
        prefs.setPlanPaidAmount(data.planPaid)
        prefs.setPlanBalance(data.planBalance)
        prefs.setPlanDueDate(data.planDueDate)
        prefs.setPlanOverdueAmount(data.planOverdue)
        prefs.setPaymentStatus("active")
        prefs.markSetupDone()
        Log.i(TAG, "Setup saved — contract=${data.contractId}")
    }

    private fun startKioskActivity(reason: String, overdueAmount: String = "", currency: String = "") {
        startActivity(Intent(this, KioskLockActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra(KioskLockActivity.EXTRA_REASON,         reason)
            putExtra(KioskLockActivity.EXTRA_OVERDUE_AMOUNT, overdueAmount)
            putExtra(KioskLockActivity.EXTRA_CURRENCY,       currency)
        })
    }

    private fun fmtAmt(v: Double): String =
        if (v == 0.0) "" else if (v == kotlin.math.floor(v)) "%.0f".format(v) else "%.2f".format(v)
}
