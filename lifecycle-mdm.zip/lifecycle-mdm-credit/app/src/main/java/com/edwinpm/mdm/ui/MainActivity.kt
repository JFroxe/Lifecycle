package com.edwinpm.mdm.ui

import android.annotation.SuppressLint
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.telephony.TelephonyManager
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import com.edwinpm.mdm.admin.DeviceOwnerHelper
import com.edwinpm.mdm.admin.MdmDeviceAdminReceiver
import com.edwinpm.mdm.kiosk.KioskLockActivity
import com.edwinpm.mdm.service.MdmWatchdogService
import com.edwinpm.mdm.ui.theme.LifecycleTheme
import com.edwinpm.mdm.util.DeviceRepository
import com.edwinpm.mdm.util.MdmPrefs
import com.edwinpm.mdm.worker.WatchdogWorker
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Random

/**
 * MainActivity — orchestrates the full launch flow:
 *
 *   ① Device not Admin + Owner → AdminRequirementScreen (no way forward)
 *   ② Setup not done → BusinessVerificationScreen → SetupWizardScreen
 *   ③ Setup done + locked → KioskLockActivity
 *   ④ Setup done + unlocked → MainScreen (credit dashboard) / PaymentScreen
 *
 * IMEI is read automatically (slot 0). Contract ID is auto-generated once.
 */
class MainActivity : ComponentActivity() {

    companion object {
        private const val TAG = "MainActivity"
    }

    // Navigation state
    private sealed class Screen {
        object AdminRequired      : Screen()
        object BusinessVerify     : Screen()
        data class Setup(val biz: BusinessInfo, val imei: String, val contractId: String) : Screen()
        object Dashboard          : Screen()
        object Payment            : Screen()
    }

    private var screen by mutableStateOf<Screen>(Screen.AdminRequired)

    private val requestAdminLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { _ -> reEvaluateScreen() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val prefs = MdmPrefs(this)

        // If locked, go straight to kiosk
        if (prefs.isLocked()) {
            startKioskActivity(reason = "Device locked by MDM",
                overdueAmount = fmtAmt(prefs.getPlanOverdueAmount()),
                currency      = prefs.getPlanCurrency())
            finish()
            return
        }

        // Start background services (silently — user doesn't see these)
        startForegroundService(Intent(this, MdmWatchdogService::class.java))
        WatchdogWorker.enqueue(this)

        screen = resolveScreen(prefs)

        setContent {
            LifecycleTheme {
                when (val s = screen) {

                    // ① Not provisioned
                    is Screen.AdminRequired -> AdminRequirementScreen(
                        isAdmin       = DeviceOwnerHelper.isDeviceAdmin(this),
                        isDeviceOwner = DeviceOwnerHelper.isDeviceOwner(this),
                        onRetry       = { reEvaluateScreen() }
                    )

                    // ② Business verification
                    is Screen.BusinessVerify -> BusinessVerificationScreen(
                        onVerify   = { id, cb ->
                            DeviceRepository.verifyBusiness(id) { found, name, phone, address ->
                                cb(found, name, phone, address)
                            }
                        },
                        onVerified = { biz ->
                            val prefs2  = MdmPrefs(this)
                            val imei     = readImei()
                            val contract = generateContractId()
                            // Save business info now
                            prefs2.setBusinessId(biz.id)
                            prefs2.setBusinessName(biz.name)
                            prefs2.setBusinessPhone(biz.phone)
                            prefs2.setBusinessAddress(biz.address)
                            screen = Screen.Setup(biz, imei, contract)
                        }
                    )

                    // ③ Registration wizard
                    is Screen.Setup -> SetupWizardScreen(
                        businessInfo = s.biz,
                        imei         = s.imei,
                        contractId   = s.contractId,
                        onSetupComplete = { data ->
                            saveSetupData(data)
                            DeviceRepository.registerDevice(this)
                            screen = Screen.Dashboard
                        }
                    )

                    // ④ Credit dashboard
                    is Screen.Dashboard -> MainScreen(
                        prefs  = MdmPrefs(this),
                        onPay  = { screen = Screen.Payment }
                    )

                    // ⑤ Payment flow
                    is Screen.Payment -> {
                        val prefs2 = MdmPrefs(this)
                        PaymentScreen(
                            balance  = fmtAmt(prefs2.getPlanBalance()),
                            currency = prefs2.getPlanCurrency(),
                            onBack   = { screen = Screen.Dashboard }
                        )
                    }
                }
            }
        }

        // Auto-request admin if not yet granted (won't interrupt if already granted)
        if (!DeviceOwnerHelper.isDeviceAdmin(this)) {
            requestDeviceAdmin()
        } else {
            DeviceOwnerHelper.applyAllPolicies(this)
        }
    }

    override fun onResume() {
        super.onResume()
        val prefs = MdmPrefs(this)

        // Re-check lock state first
        if (prefs.isLocked()) {
            startKioskActivity("Device locked by MDM",
                fmtAmt(prefs.getPlanOverdueAmount()), prefs.getPlanCurrency())
            return
        }

        // Only recheck admin status if on the requirement screen
        if (screen is Screen.AdminRequired) {
            reEvaluateScreen()
            return
        }

        // If on the dashboard, silently check payment status from server
        if (screen is Screen.Dashboard && prefs.isSetupDone()) {
            checkPaymentStatusFromServer(prefs)
        }
    }

    // ── Helpers ────────────────────────────────────────────────────────────────

    private fun resolveScreen(prefs: MdmPrefs): Screen {
        val isAdmin  = DeviceOwnerHelper.isDeviceAdmin(this)
        val isOwner  = DeviceOwnerHelper.isDeviceOwner(this)
        return when {
            !isAdmin || !isOwner  -> Screen.AdminRequired
            !prefs.isSetupDone()  -> Screen.BusinessVerify
            else                  -> Screen.Dashboard
        }
    }

    private fun reEvaluateScreen() {
        if (DeviceOwnerHelper.isDeviceAdmin(this)) {
            DeviceOwnerHelper.applyAllPolicies(this)
        }
        screen = resolveScreen(MdmPrefs(this))
    }

    private fun requestDeviceAdmin() {
        val adminComponent = ComponentName(this, MdmDeviceAdminReceiver::class.java)
        requestAdminLauncher.launch(
            Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
                putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                    "Lifecycle MDM requires Device Administrator privileges to manage this credit-financed device.")
            }
        )
    }

    @SuppressLint("MissingPermission")
    private fun readImei(): String {
        return try {
            val tm = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
            // getImei(0) = first SIM slot. Requires READ_PHONE_STATE.
            // As Device Owner, this is granted implicitly.
            val imei = tm.getImei(0)
            if (!imei.isNullOrBlank()) imei else tm.deviceId ?: ""
        } catch (e: Exception) {
            Log.w(TAG, "Could not read IMEI: ${e.message}")
            ""
        }
    }

    private fun generateContractId(): String {
        val year  = SimpleDateFormat("yyyy", Locale.US).format(Date())
        val rand  = (100000 + Random().nextInt(900000)).toString()
        return "LC-$year-$rand"
    }

    private fun saveSetupData(data: SetupData) {
        val prefs = MdmPrefs(this)
        prefs.setOwnerName(data.ownerName)
        prefs.setOwnerPhone(data.ownerPhone)
        prefs.setContractId(data.contractId)
        prefs.setDeviceImei(data.deviceImei)
        prefs.setPlanName(data.planName)
        prefs.setPlanCurrency(data.planCurrency)
        prefs.setPlanTotalAmount(data.planTotal)
        prefs.setPlanPaidAmount(data.planPaid)
        prefs.setPlanBalance(data.planBalance)
        prefs.setPlanDueDate(data.planDueDate)
        prefs.setPlanOverdueAmount(data.planOverdue)
        prefs.setPaymentStatus("active")
        // Provider info comes from business document
        prefs.markSetupDone()
        Log.i(TAG, "Setup saved — contract=${data.contractId}, owner=${data.ownerName}")
    }

    private fun checkPaymentStatusFromServer(prefs: MdmPrefs) {
        val deviceId = DeviceRepository.getOrCreateDeviceId(this)
        DeviceRepository.fetchAndApplyServerState(this, deviceId) { status ->
            if (status != "active") {
                val reason = when (status.lowercase()) {
                    "suspended" -> "Payment overdue — device suspended"
                    "revoked"   -> "Contract revoked — contact your provider"
                    else        -> "Device locked by MDM"
                }
                MdmWatchdogService.sendCommand(this, MdmWatchdogService.CMD_LOCK, reason,
                    fmtAmt(prefs.getPlanOverdueAmount()), prefs.getPlanCurrency())
            }
        }
    }

    private fun startKioskActivity(reason: String, overdueAmount: String = "", currency: String = "") {
        startActivity(Intent(this, KioskLockActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra(KioskLockActivity.EXTRA_REASON,         reason)
            putExtra(KioskLockActivity.EXTRA_OVERDUE_AMOUNT, overdueAmount)
            putExtra(KioskLockActivity.EXTRA_CURRENCY,       currency)
        })
    }

    private fun fmtAmt(v: Double): String =
        if (v == 0.0) "" else if (v == kotlin.math.floor(v)) "%.0f".format(v) else "%.2f".format(v)
}
