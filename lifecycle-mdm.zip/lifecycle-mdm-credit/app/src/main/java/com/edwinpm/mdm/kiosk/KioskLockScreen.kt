package com.edwinpm.mdm.kiosk

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.edwinpm.mdm.R

/**
 * KioskLockScreen — Full-screen credit-lock overlay shown when the device is locked
 * due to a missed payment or MDM command.
 *
 * Displays:
 *  • Lock reason (e.g. "Payment overdue")
 *  • Outstanding balance and due date (if provided via extras)
 *  • Provider name and support phone number
 *  • App branding
 */
@Composable
fun KioskLockScreen(
    lockReason: String,
    providerName: String  = "Lifecycle Credit",
    providerPhone: String = "",
    overdueAmount: String = "",
    currency: String      = ""
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF080C10)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 32.dp, vertical = 48.dp)
        ) {

            // Lock icon
            Icon(
                painter = painterResource(id = R.drawable.ic_lock),
                contentDescription = "Locked",
                tint = Color(0xFFEF4444),
                modifier = Modifier.size(80.dp)
            )

            Spacer(Modifier.height(24.dp))

            // Title
            Text(
                text = "DEVICE LOCKED",
                color = Color.White,
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center,
                letterSpacing = 2.sp
            )

            Spacer(Modifier.height(16.dp))

            // Reason
            Text(
                text = lockReason,
                color = Color(0xFFADB5BD),
                fontSize = 16.sp,
                textAlign = TextAlign.Center,
                lineHeight = 24.sp
            )

            // Outstanding amount card (shown when overdue > 0)
            if (overdueAmount.isNotBlank()) {
                Spacer(Modifier.height(28.dp))
                Box(
                    modifier = Modifier
                        .background(Color(0xFF1A0A0A), RoundedCornerShape(14.dp))
                        .padding(horizontal = 28.dp, vertical = 18.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            "Outstanding Balance",
                            color = Color(0xFF9CA3AF),
                            fontSize = 13.sp
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "${currency.ifBlank { "" }} $overdueAmount".trim(),
                            color = Color(0xFFEF4444),
                            fontSize = 30.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(Modifier.height(36.dp))

            // Provider info
            Box(
                modifier = Modifier
                    .background(Color(0xFF0F1923), RoundedCornerShape(12.dp))
                    .padding(horizontal = 24.dp, vertical = 16.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        "To unlock this device, contact your provider:",
                        color = Color(0xFF6B7280),
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        providerName,
                        color = Color.White,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center
                    )
                    if (providerPhone.isNotBlank()) {
                        Spacer(Modifier.height(6.dp))
                        Text(
                            providerPhone,
                            color = Color(0xFF60A5FA),
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            Spacer(Modifier.height(48.dp))

            // Branding footer
            Icon(
                painter = painterResource(id = R.drawable.ic_shield),
                contentDescription = "MDM Shield",
                tint = Color(0xFF1F2937),
                modifier = Modifier.size(36.dp)
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Lifecycle MDM v2.0",
                color = Color(0xFF374151),
                fontSize = 12.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}
