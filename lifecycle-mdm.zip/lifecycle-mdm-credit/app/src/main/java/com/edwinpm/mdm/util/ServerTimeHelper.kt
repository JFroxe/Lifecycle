package com.edwinpm.mdm.util

  import android.util.Log
  import com.google.firebase.firestore.FieldValue
  import com.google.firebase.firestore.FirebaseFirestore
  import org.json.JSONObject
  import java.net.HttpURLConnection
  import java.net.URL
  import java.text.SimpleDateFormat
  import java.util.Calendar
  import java.util.Date
  import java.util.Locale
  import java.util.TimeZone
  import kotlin.concurrent.thread

  object ServerTimeHelper {

      private const val TAG = "ServerTimeHelper"
      private const val WORLD_TIME_API = "https://worldtimeapi.org/api/timezone/Etc/UTC"

      fun fetchServerTime(onResult: (Date?) -> Unit) {
          thread {
              val date = fetchFromWorldTimeApi() ?: fetchFromFirestore()
              onResult(date)
          }
      }

      private fun fetchFromWorldTimeApi(): Date? {
          return try {
              val url = URL(WORLD_TIME_API)
              val conn = url.openConnection() as HttpURLConnection
              conn.connectTimeout = 10_000
              conn.readTimeout = 10_000
              conn.requestMethod = "GET"

              if (conn.responseCode == 200) {
                  val body = conn.inputStream.bufferedReader().readText()
                  conn.disconnect()
                  val json = JSONObject(body)
                  val utcDatetime = json.getString("utc_datetime")
                  val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US)
                  sdf.timeZone = TimeZone.getTimeZone("UTC")
                  val cleaned = utcDatetime.substringBefore("+").substringBefore(".")
                  val parsed = sdf.parse(cleaned)
                  Log.i(TAG, "WorldTimeAPI time: $parsed")
                  parsed
              } else {
                  conn.disconnect()
                  Log.w(TAG, "WorldTimeAPI returned ${conn.responseCode}")
                  null
              }
          } catch (e: Exception) {
              Log.e(TAG, "WorldTimeAPI failed: ${e.message}")
              null
          }
      }

      private fun fetchFromFirestore(): Date? {
          return try {
              val db = FirebaseFirestore.getInstance()
              val docRef = db.collection("_server_time").document("probe")
              val latch = java.util.concurrent.CountDownLatch(1)
              var result: Date? = null

              docRef.set(mapOf("t" to FieldValue.serverTimestamp()))
                  .addOnSuccessListener {
                      docRef.get()
                          .addOnSuccessListener { doc ->
                              result = doc.getTimestamp("t")?.toDate()
                              Log.i(TAG, "Firestore server time: $result")
                              docRef.delete()
                              latch.countDown()
                          }
                          .addOnFailureListener { e ->
                              Log.e(TAG, "Firestore time read failed: ${e.message}")
                              latch.countDown()
                          }
                  }
                  .addOnFailureListener { e ->
                      Log.e(TAG, "Firestore time write failed: ${e.message}")
                      latch.countDown()
                  }

              latch.await(15, java.util.concurrent.TimeUnit.SECONDS)
              result
          } catch (e: Exception) {
              Log.e(TAG, "Firestore time fetch failed: ${e.message}")
              null
          }
      }

      /**
       * Advances [currentDueDate] by one payment cycle (based on [paymentFrequency]).
       * This is the raw single-step advance — use [calculateNextPaymentDate] to find
       * the first due date that is still in the future relative to [serverTime].
       */
      fun calculateNextDueDate(currentDueDate: String, paymentFrequency: String): String {
          val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
          sdf.timeZone = TimeZone.getTimeZone("UTC")

          val dueDate = try { sdf.parse(currentDueDate) } catch (_: Exception) { return currentDueDate }
              ?: return currentDueDate

          val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
          cal.time = dueDate
          advanceByFrequency(cal, paymentFrequency)
          return sdf.format(cal.time)
      }

      /**
       * Calculates the next payment date given:
       * - [registrationDate]: the date the device was registered (yyyy-MM-dd, UTC)
       * - [paymentFrequency]: payment cycle ("daily", "weekly", "biweekly", "monthly", etc.)
       * - [serverTime]: the current network date/time (UTC)
       *
       * Logic:
       *   Start from [registrationDate], keep adding one payment cycle until the date
       *   is strictly in the future relative to [serverTime].
       *
       *   If [registrationDate] is blank or invalid, falls back to [serverTime] + one cycle.
       *
       * Returns the next due date as yyyy-MM-dd (UTC).
       */
      fun calculateNextPaymentDate(
          registrationDate: String,
          paymentFrequency: String,
          serverTime: Date
      ): String {
          val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
          sdf.timeZone = TimeZone.getTimeZone("UTC")

          val startDate: Date = if (registrationDate.isNotBlank()) {
              try { sdf.parse(registrationDate) ?: serverTime } catch (_: Exception) { serverTime }
          } else {
              serverTime
          }

          val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
          cal.time = startDate

          // Normalise serverTime to start-of-day for a fair comparison
          val serverCal = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
          serverCal.time = serverTime
          serverCal.set(Calendar.HOUR_OF_DAY, 0)
          serverCal.set(Calendar.MINUTE, 0)
          serverCal.set(Calendar.SECOND, 0)
          serverCal.set(Calendar.MILLISECOND, 0)

          // If startDate is already in the future (same day or later), that is the first due date.
          // Otherwise keep advancing until we land strictly after today.
          if (!cal.after(serverCal)) {
              // Advance at least once so the very first payment is in the future.
              advanceByFrequency(cal, paymentFrequency)
              while (!cal.after(serverCal)) {
                  advanceByFrequency(cal, paymentFrequency)
              }
          }

          return sdf.format(cal.time)
      }

      /**
       * After a payment is made, advance [currentNextPaymentDate] by one cycle.
       *
       * The rule: preserve however many days are left until [currentNextPaymentDate]
       * relative to [serverTime], then add the full payment cycle on top.
       * If the due date has already passed (overdue case), start the next cycle
       * from [serverTime] instead.
       *
       * Example: payment frequency = 30 days, due date is 4 days from now.
       *   → new due date = today + 4 days + 30 days = today + 34 days.
       */
      fun advanceNextPaymentDateAfterPayment(
          currentNextPaymentDate: String,
          paymentFrequency: String,
          serverTime: Date
      ): String {
          val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
          sdf.timeZone = TimeZone.getTimeZone("UTC")

          val dueCal = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
          val parsedDue = try { sdf.parse(currentNextPaymentDate) } catch (_: Exception) { null }

          val serverCal = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
          serverCal.time = serverTime
          serverCal.set(Calendar.HOUR_OF_DAY, 0)
          serverCal.set(Calendar.MINUTE, 0)
          serverCal.set(Calendar.SECOND, 0)
          serverCal.set(Calendar.MILLISECOND, 0)

          if (parsedDue != null) {
              dueCal.time = parsedDue
              dueCal.set(Calendar.HOUR_OF_DAY, 0)
              dueCal.set(Calendar.MINUTE, 0)
              dueCal.set(Calendar.SECOND, 0)
              dueCal.set(Calendar.MILLISECOND, 0)

              // Start from whichever is further in the future (due date or today)
              val baseForward = if (dueCal.after(serverCal)) dueCal else serverCal
              val base = baseForward.clone() as Calendar
              advanceByFrequency(base, paymentFrequency)
              return sdf.format(base.time)
          } else {
              // Fallback: advance from today by one cycle
              val base = serverCal.clone() as Calendar
              advanceByFrequency(base, paymentFrequency)
              return sdf.format(base.time)
          }
      }

      private fun advanceByFrequency(cal: Calendar, paymentFrequency: String) {
          when (paymentFrequency.lowercase().trim()) {
              "daily"     -> cal.add(Calendar.DAY_OF_MONTH, 1)
              "weekly"    -> cal.add(Calendar.WEEK_OF_YEAR, 1)
              "biweekly"  -> cal.add(Calendar.WEEK_OF_YEAR, 2)
              "monthly"   -> cal.add(Calendar.MONTH, 1)
              "bimonthly" -> cal.add(Calendar.MONTH, 2)
              "quarterly" -> cal.add(Calendar.MONTH, 3)
              "yearly"    -> cal.add(Calendar.YEAR, 1)
              else        -> cal.add(Calendar.MONTH, 1)
          }
      }

      fun isPaymentOverdue(dueDate: String, serverTime: Date): Boolean {
          val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
          sdf.timeZone = TimeZone.getTimeZone("UTC")

          val due = try { sdf.parse(dueDate) } catch (_: Exception) { return false }
              ?: return false

          val dueCal = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
          dueCal.time = due
          dueCal.set(Calendar.HOUR_OF_DAY, 23)
          dueCal.set(Calendar.MINUTE, 59)
          dueCal.set(Calendar.SECOND, 59)

          return serverTime.after(dueCal.time)
      }
  }
  