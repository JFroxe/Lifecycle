package com.edwinpm.mdm.util

import android.util.Log
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.concurrent.thread

object ServerTimeHelper {

    private const val TAG = "ServerTimeHelper"
    private const val WORLD_TIME_API = "https://worldtimeapi.org/api/timezone/Etc/UTC"

    fun fetchServerTime(onResult: (Date?) -> Unit) {
        thread {
            val date = fetchFromWorldTimeApi() ?: fetchFromFirestore()
            onResult(date)
        }
    }

    private fun fetchFromWorldTimeApi(): Date? {
        return try {
            val url = URL(WORLD_TIME_API)
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 10_000
            conn.readTimeout = 10_000
            conn.requestMethod = "GET"

            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().readText()
                conn.disconnect()
                val json = JSONObject(body)
                val utcDatetime = json.getString("utc_datetime")
                val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US)
                sdf.timeZone = TimeZone.getTimeZone("UTC")
                val cleaned = utcDatetime.substringBefore("+").substringBefore(".")
                val parsed = sdf.parse(cleaned)
                Log.i(TAG, "WorldTimeAPI time: $parsed")
                parsed
            } else {
                conn.disconnect()
                Log.w(TAG, "WorldTimeAPI returned ${conn.responseCode}")
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "WorldTimeAPI failed: ${e.message}")
            null
        }
    }

    private fun fetchFromFirestore(): Date? {
        return try {
            val db = FirebaseFirestore.getInstance()
            val docRef = db.collection("_server_time").document("probe")
            val latch = java.util.concurrent.CountDownLatch(1)
            var result: Date? = null

            docRef.set(mapOf("t" to FieldValue.serverTimestamp()))
                .addOnSuccessListener {
                    docRef.get()
                        .addOnSuccessListener { doc ->
                            result = doc.getTimestamp("t")?.toDate()
                            Log.i(TAG, "Firestore server time: $result")
                            docRef.delete()
                            latch.countDown()
                        }
                        .addOnFailureListener { e ->
                            Log.e(TAG, "Firestore time read failed: ${e.message}")
                            latch.countDown()
                        }
                }
                .addOnFailureListener { e ->
                    Log.e(TAG, "Firestore time write failed: ${e.message}")
                    latch.countDown()
                }

            latch.await(15, java.util.concurrent.TimeUnit.SECONDS)
            result
        } catch (e: Exception) {
            Log.e(TAG, "Firestore time fetch failed: ${e.message}")
            null
        }
    }

    fun calculateNextDueDate(currentDueDate: String, paymentFrequency: String): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        sdf.timeZone = TimeZone.getTimeZone("UTC")

        val dueDate = try { sdf.parse(currentDueDate) } catch (_: Exception) { return currentDueDate }
            ?: return currentDueDate

        val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
        cal.time = dueDate

        when (paymentFrequency.lowercase().trim()) {
            "daily"     -> cal.add(Calendar.DAY_OF_MONTH, 1)
            "weekly"    -> cal.add(Calendar.WEEK_OF_YEAR, 1)
            "biweekly"  -> cal.add(Calendar.WEEK_OF_YEAR, 2)
            "monthly"   -> cal.add(Calendar.MONTH, 1)
            "bimonthly" -> cal.add(Calendar.MONTH, 2)
            "quarterly" -> cal.add(Calendar.MONTH, 3)
            "yearly"    -> cal.add(Calendar.YEAR, 1)
            else        -> cal.add(Calendar.MONTH, 1)
        }

        return sdf.format(cal.time)
    }

    fun isPaymentOverdue(dueDate: String, serverTime: Date): Boolean {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        sdf.timeZone = TimeZone.getTimeZone("UTC")

        val due = try { sdf.parse(dueDate) } catch (_: Exception) { return false }
            ?: return false

        val dueCal = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
        dueCal.time = due
        dueCal.set(Calendar.HOUR_OF_DAY, 23)
        dueCal.set(Calendar.MINUTE, 59)
        dueCal.set(Calendar.SECOND, 59)

        return serverTime.after(dueCal.time)
    }
}
