# Lifecycle MDM ProGuard Rules

# Keep Device Admin Receiver
-keep class com.edwinpm.mdm.admin.MdmDeviceAdminReceiver { *; }

# Keep Boot Receiver
-keep class com.edwinpm.mdm.admin.BootReceiver { *; }

# Keep FCM Service
-keep class com.edwinpm.mdm.fcm.MdmFcmService { *; }

# Keep Watchdog Service
-keep class com.edwinpm.mdm.service.MdmWatchdogService { *; }

# Keep WorkManager Worker
-keep class com.edwinpm.mdm.worker.WatchdogWorker { *; }

# Keep all Activities
-keep class com.edwinpm.mdm.ui.** { *; }
-keep class com.edwinpm.mdm.kiosk.** { *; }

# Firebase Messaging
-keep class com.google.firebase.** { *; }
-keep class com.google.android.gms.** { *; }

# WorkManager
-keep class androidx.work.** { *; }

# Kotlin
-keep class kotlin.** { *; }
-keepclassmembers class ** {
    @kotlin.jvm.JvmStatic *;
}
