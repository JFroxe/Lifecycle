# Lifecycle MDM — Credit Lock Edition

**Package:** `com.edwinpm.mdm`
**Android SDK:** 26+ (Target: 35)
**Language:** Kotlin + Jetpack Compose
**Build System:** Gradle Kotlin DSL (.gradle.kts)

---

## What This Does

Lifecycle MDM is a **mobile MDM (Mobile Device Management) application for credit-financed devices**.

It manages devices that were sold on a credit/installment plan and enforces payment compliance:

- **First-launch setup wizard** — collects owner info, contract ID, credit plan details, and provider contact
- **Payment status enforcement** — locks the device remotely when a payment is overdue
- **Kiosk lock screen** — unescapable overlay showing the outstanding balance, provider name, and support phone
- **Remote commands via Firebase Cloud Messaging** — lock, unlock, update payment status, factory wipe
- **Persistent watchdog** — survives reboots, Doze mode, and force-stops; re-checks payment status every 15 minutes
- **Firestore sync** — device registration, heartbeat, and credit plan state all live in the cloud

---

## Project Structure

```
lifecycle-mdm-project/
├── app/
│   ├── build.gradle.kts
│   ├── google-services.json           ← REPLACE with your Firebase config
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/edwinpm/mdm/
│       │   ├── LifecycleApp.kt                ← Application class + notification channels
│       │   ├── admin/
│       │   │   ├── MdmDeviceAdminReceiver.kt  ← Device Admin lifecycle callbacks
│       │   │   ├── DeviceOwnerHelper.kt        ← DPM operations (lock/wipe/kiosk)
│       │   │   └── BootReceiver.kt             ← Auto-start on device boot
│       │   ├── fcm/
│       │   │   └── MdmFcmService.kt            ← Firebase push commands (lock/unlock/update)
│       │   ├── kiosk/
│       │   │   ├── KioskLockActivity.kt        ← Full-screen unescapable lock overlay
│       │   │   └── KioskLockScreen.kt          ← Compose UI for lock screen (shows balance + provider)
│       │   ├── service/
│       │   │   └── MdmWatchdogService.kt       ← Sticky foreground service
│       │   ├── worker/
│       │   │   └── WatchdogWorker.kt           ← 15-min periodic job (heartbeat + payment check)
│       │   ├── ui/
│       │   │   ├── MainActivity.kt             ← Entry point, setup wizard routing
│       │   │   ├── SetupWizardScreen.kt        ← 4-step first-run credit plan setup
│       │   │   ├── MainScreen.kt               ← MDM credit dashboard
│       │   │   └── theme/
│       │   │       ├── Theme.kt
│       │   │       └── Type.kt
│       │   └── util/
│       │       ├── MdmPrefs.kt                 ← SharedPreferences wrapper (MDM + credit fields)
│       │       └── DeviceRepository.kt         ← Firestore sync + payment status polling
│       └── res/
│           ├── drawable/
│           │   ├── ic_shield.xml
│           │   └── ic_lock.xml
│           ├── xml/
│           │   └── device_admin_policies.xml
│           └── values/
│               ├── strings.xml
│               └── themes.xml
├── gradle/
│   ├── libs.versions.toml
│   └── wrapper/gradle-wrapper.properties
├── build.gradle.kts
└── settings.gradle.kts
```

---

## Setup Instructions

### 1. Open in Android Studio

Open the `lifecycle-mdm-project` folder in Android Studio (Electric Eel or newer).

### 2. Set Up Firebase

1. Go to [Firebase Console](https://console.firebase.google.com)
2. Create a project (or use an existing one)
3. Add Android app with package name: `com.edwinpm.mdm`
4. Download `google-services.json` and replace `app/google-services.json`
5. Enable **Firebase Cloud Messaging** and **Firestore** in your project
6. In Firestore, create a collection called `devices` (documents are auto-created at first launch)

### 3. First Launch — Setup Wizard

On first launch the app shows a 4-step setup wizard:

| Step | Data Collected |
|------|---------------|
| 1 | Owner name, phone, contract ID, IMEI |
| 2 | Plan name, currency, total amount, amount paid, due date |
| 3 | Provider name, support phone number |
| 4 | Confirmation summary |

After saving, the device is registered in Firestore and the admin rights prompt is shown.

### 4. Activate Device Admin

After the setup wizard, the app automatically prompts the user to grant Device Administrator privileges.

### 5. Set as Device Owner (Recommended)

For maximum protection (true kiosk mode, uninstall block, factory reset block):

```bash
# Requirements: USB debugging enabled, NO Google accounts added to device yet
adb shell dpm set-device-owner com.edwinpm.mdm/.admin.MdmDeviceAdminReceiver
```

---

## Firestore Document Structure

Each device creates a document at `devices/{deviceId}`:

```json
{
  "deviceId": "abc123_Pixel_8",
  "fcmToken": "...",
  "deviceModel": "Google Pixel 8",
  "androidVersion": "14",
  "sdkVersion": 34,
  "imei": "353123456789012",
  "paymentStatus": "active",
  "planName": "24-month Smartphone Plan",
  "planTotal": 1200.00,
  "planPaid": 200.00,
  "planBalance": 1000.00,
  "planDueDate": "2025-07-01",
  "planOverdue": 0.00,
  "planCurrency": "USD",
  "ownerName": "John Smith",
  "ownerPhone": "+1 555 000 1234",
  "contractId": "LC-2025-00123",
  "providerName": "Lifecycle Credit",
  "providerPhone": "+1 800 555 0100",
  "registeredAt": "<Timestamp>",
  "lastSeen": "<Timestamp>"
}
```

To lock a device, change `paymentStatus` to `"suspended"` in Firestore **or** send an FCM command.

---

## FCM Command Reference

Send **data messages** (not notification messages) to the device FCM token:

| Command         | Effect |
|-----------------|--------|
| `lock`          | Shows kiosk overlay, locks device. Supports `overdueAmount` + `currency` extras. |
| `unlock`        | Dismisses kiosk, restores normal operation. Clears overdue amount. |
| `update_status` | Updates payment fields without locking (use when payment received). |
| `wipe`          | Factory resets the device (IRREVERSIBLE). |
| `ping`          | Health check — updates heartbeat in Firestore. |

### Example payloads

**Lock device (overdue):**
```json
{
  "message": {
    "token": "DEVICE_FCM_TOKEN",
    "data": {
      "cmd": "lock",
      "reason": "Payment overdue — 30 days past due",
      "overdueAmount": "350.00",
      "currency": "USD"
    }
  }
}
```

**Unlock after payment:**
```json
{
  "message": {
    "token": "DEVICE_FCM_TOKEN",
    "data": {
      "cmd": "unlock",
      "reason": "Payment received — thank you"
    }
  }
}
```

**Update payment status without locking:**
```json
{
  "message": {
    "token": "DEVICE_FCM_TOKEN",
    "data": {
      "cmd": "update_status",
      "paymentStatus": "active",
      "planPaid": "400.00",
      "planBalance": "800.00",
      "planDueDate": "2025-08-01"
    }
  }
}
```

---

## Payment Enforcement Logic

```
App launch / every 15 min (WatchdogWorker)
  → Fetch paymentStatus from Firestore
  → If "suspended" or "revoked" AND not already locked:
      → Send LOCK command to WatchdogService
      → Show KioskLockScreen with overdue amount + provider contact

FCM "lock" command received:
  → Same lock flow above

FCM "unlock" command received:
  → Clear lock flag
  → Broadcast ACTION_UNLOCK to dismiss KioskLockActivity
  → Return to main dashboard
```

---

## Security Architecture

| Layer | Mechanism |
|-------|-----------|
| Credit enforcement | Firestore `paymentStatus` checked on every launch + every 15 min |
| Real-time commands | FCM data messages (lock/unlock/update_status/wipe) |
| Admin Privileges | `DeviceAdminReceiver` — lock, wipe, password policy |
| Device Owner | DPM — uninstall block, true kiosk lock-task, keyguard disable |
| Persistence | `START_STICKY` Foreground Service + WorkManager 15-min job |
| Boot Survival | `BOOT_COMPLETED` + `LOCKED_BOOT_COMPLETED` BroadcastReceiver |
| Admin Removal Detection | `onDisableRequested()` triggers immediate re-lock |
| Kiosk Overlay | `KioskLockActivity` with `startLockTask()` + 5-layer escape prevention |

---

## Building

```bash
./gradlew assembleDebug    # Debug APK
./gradlew assembleRelease  # Release APK (requires signing config)
```

---

## Notes for AIDE / J Studio

- Ensure your AIDE version supports Gradle Kotlin DSL (`.gradle.kts`)
- Minimum Java 11 required for compilation
- Replace `google-services.json` before building

---

## Legal Notice

This MDM application is intended for legitimate management of credit-financed devices where the user has been informed and has consented to remote management capabilities. Ensure compliance with local privacy laws and regulations before deployment.
